import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {documentAssetsEsbuild} from './document-assets.mjs';

const require=createRequire(import.meta.url);
const canvas=require(require.resolve('@napi-rs/canvas',{paths:[require.resolve('pdfjs-dist/package.json')]}));
Object.assign(globalThis,{DOMMatrix:canvas.DOMMatrix,ImageData:canvas.ImageData,Path2D:canvas.Path2D});
globalThis.OffscreenCanvas=class{constructor(width,height){const result=canvas.createCanvas(width,height);result.convertToBlob=async({type='image/png',quality=.8}={})=>new Blob([await result.encode(type==='image/jpeg'?'jpeg':'png',Math.round(quality*100))],{type});return result;}};
globalThis.createImageBitmap=async blob=>{const image=await canvas.loadImage(Buffer.from(await blob.arrayBuffer()));image.close=()=>{};return image;};
const fixtures=await fs.access('tests/pdf-math-fixtures/expected-all.json').then(()=>path.resolve('tests/pdf-math-fixtures')).catch(()=>path.resolve('../pdf-math-test-assets'));
await fs.mkdir('.test-build/pdf-math',{recursive:true});
await build({entryPoints:['lib/pdf-reader.ts','lib/pdf-visuals.ts'],outdir:'.test-build/pdf-math',outExtension:{'.js':'.mjs'},platform:'node',format:'esm',bundle:true,packages:'external',plugins:[documentAssetsEsbuild()],logLevel:'silent'});
const {readPdf}=await import(pathToFileURL(path.resolve('.test-build/pdf-math/pdf-reader.mjs')).href);
const {planPdfVisualRegions}=await import(pathToFileURL(path.resolve('.test-build/pdf-math/pdf-visuals.mjs')).href);
const expected=JSON.parse(await fs.readFile(path.join(fixtures,'expected-all.json'),'utf8'));
const report=[];
for(const fixture of expected){
  const bytes=await fs.readFile(path.join(fixtures,fixture.file));
  try{
    const result=await readPdf(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength));
    const images=result.blocks.flatMap(block=>(block.visuals||[]).map(image=>({image,block})));
    assert.ok(result.requiresReview,'PDF math must remain unconfirmed');
    assert.ok(result.sourcePages.length,'original pages must be available for manual correction');
    const auto=fixture.questions.every(question=>question.expectedAutoAttach);
    if(auto){
      const expectedCount=fixture.questions.reduce((sum,question)=>sum+question.stemFragments.length+Object.values(question.optionFragments).reduce((total,parts)=>total+parts.length,0),0);
      assert.equal(images.length,expectedCount,`whole-field image count; warnings: ${result.warnings.join(' | ')}`);
      assert.ok(images.every(({block})=>!/^(?:参考答案|答案|answer|solution)/i.test(block.text)),'answer blocks must never own practice images');
      for(let index=0;index<images.length;index++){
        const {image}=images[index];assert.ok(image.src.startsWith('data:image/png;base64,'));
        const decoded=await canvas.loadImage(Buffer.from(image.src.split(',')[1],'base64'));
        assert.ok(decoded.width>300&&decoded.height>20,'crop must preserve readable original content');
        if([0,1,2,5,6,11].includes(index))await fs.writeFile(path.join('.test-build/pdf-math',fixture.file+`.crop-${index+1}.png`),Buffer.from(image.src.split(',')[1],'base64'));
      }
    }else{assert.equal(images.length,0,'ambiguous inline answer/choices must never be attached to practice');assert.ok(result.warnings.some(w=>/手动|框选/.test(w)));}
    await fs.writeFile(path.join('.test-build/pdf-math',fixture.file+'.summary.json'),JSON.stringify({warnings:result.warnings,blocks:result.blocks.map(block=>({...block,visuals:block.visuals?.map(image=>({...image,src:`PNG (${image.src.length} chars)`}))}))},null,2));
    report.push({file:fixture.file,status:'passed',images:images.length});console.log(`PASS ${fixture.file} (${images.length} original field images)`);
  }catch(error){report.push({file:fixture.file,status:'failed',error:error.message});console.log(`FAIL ${fixture.file}: ${error.message}`);}
}
const lines=['1. Evaluate x squared.','A. one','B. two','C. three','D. four','E. five','Answer Key','1. E'].map((text,i)=>({text,x:40,right:480,top:40+i*50,bottom:55+i*50,y:52+i*50,height:12,source:String(i)}));
const planned=planPdfVisualRegions(lines,595,842);
assert.equal(planned.regions.length,6);
assert.ok(planned.regions.every(region=>region.bottom<=lines[6].top),'every crop stops above reference answers');
for(let i=0;i<planned.regions.length-1;i++)assert.ok(planned.regions[i].bottom<=planned.regions[i+1].top,'adjacent practice fields do not overlap');
assert.equal(planPdfVisualRegions([{...lines[0],text:'1. x² A. 1 B. 2 Answer: B'}],595,842).regions.length,0,'same-line answer cannot leak into a crop');
assert.equal(planPdfVisualRegions([{...lines[0],text:'1. x² Answer E'}],595,842).regions.length,0,'same-line answer without a colon cannot leak into a crop');
const noHeading=[...lines.slice(0,6),{...lines[6],text:'1. E'}];
assert.ok(planPdfVisualRegions(noHeading,595,842).regions.every(region=>region.bottom<=noHeading[6].top),'compact numbered answers without a heading remain outside every image');
report.push({file:'explicit crop and answer boundaries',status:'passed'});
await fs.writeFile('.test-build/pdf-math/report.json',JSON.stringify(report,null,2));
console.log(`${report.filter(item=>item.status==='passed').length}/${report.length} PDF formula preservation checks passed. Canvas is simulated in Node, not browser QA.`);
if(report.some(item=>item.status==='failed'))process.exitCode=1;
