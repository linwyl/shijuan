import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {IDBFactory,IDBObjectStore} from 'fake-indexeddb';
import React,{useState,useLayoutEffect} from 'react';
import TestRenderer,{act} from 'react-test-renderer';
await build({entryPoints:['hooks/use-exam-memory.ts'],outfile:'.test-build/use-exam-memory.mjs',bundle:true,platform:'node',format:'esm',packages:'external',logLevel:'silent'});
const {useExamMemory}=await import(pathToFileURL(path.resolve('.test-build/use-exam-memory.mjs')).href);
globalThis.IS_REACT_ACT_ENVIRONMENT=true;
globalThis.window=new EventTarget();
globalThis.indexedDB=new IDBFactory();
const empty=()=>({exam:{filename:'',title:'',questions:[],warnings:[],sourceText:''},choices:{},tab:'practice'});
const paper=title=>({exam:{filename:'same.docx',title,questions:[{id:'1',number:'1',section:'',stem:'Q',options:'ABCDE'.split('').map(key=>({key,label:key,text:key})),answer:'E',issues:[],images:[],context:'',source:'test',kind:'single',order:0}],warnings:[],sourceText:'original'},choices:{},tab:'practice'});
let api,renderer;
function Harness(){
  const [snapshot,setSnapshot]=useState(empty);const [source,setSource]=useState(null);
  const memory=useExamMemory(snapshot,source,saved=>{setSnapshot(saved?{exam:saved.exam,choices:saved.choices,tab:saved.tab}:empty());setSource(saved?.source||null);});
  useLayoutEffect(()=>{api={memory,snapshot,source,choose:key=>setSnapshot(old=>({...old,choices:{'1':key}}))};});
  return React.createElement('div',{'data-status':memory.status},memory.message);
}
async function settle(check){for(let i=0;i<100;i++){await act(async()=>{await new Promise(resolve=>setTimeout(resolve,5));});if(check())return;}throw new Error('Timed out: '+api.memory.status+' '+api.memory.message);}
async function mount(){await act(async()=>{renderer=TestRenderer.create(React.createElement(Harness));});await settle(()=>api.memory.ready);}
async function unmount(){await act(async()=>renderer.unmount());}
let count=0;
async function test(name,fn){await fn();count++;console.log('PASS '+name);}
await test('初始化完成前不创建空试卷',async()=>{await mount();assert.equal(api.memory.currentId,null);assert.deepEqual(api.memory.records,[]);});
let id;
await test('导入与作答自动保存，组件重新挂载恢复进度和原文件',async()=>{
  await act(async()=>{await api.memory.begin(paper('A'),new Blob(['source']));});await settle(()=>api.memory.status==='saved');id=api.memory.currentId;
  await act(async()=>api.choose('E'));await settle(()=>api.memory.status==='saved');await unmount();await mount();await settle(()=>api.memory.status==='saved');
  assert.equal(api.snapshot.exam.title,'A');assert.deepEqual(api.snapshot.choices,{'1':'E'});assert.equal(await api.source.text(),'source');assert.equal(api.memory.records.length,1);
});
await test('首次读取失败后重试恢复旧记录，不用空数据覆盖',async()=>{
  await unmount();const factory=globalThis.indexedDB;globalThis.indexedDB=undefined;
  await mount();assert.equal(api.memory.status,'error');assert.equal(api.memory.currentId,null);
  globalThis.indexedDB=factory;await act(async()=>api.memory.retry());await settle(()=>api.memory.ready&&api.memory.currentId===id);
  assert.equal(api.snapshot.exam.title,'A');assert.equal(api.snapshot.choices['1'],'E');
});
await test('保存失败保留内存修改，点击当前记录不回退，重试能保存',async()=>{
  const put=Reflect.get(IDBObjectStore.prototype,'put');IDBObjectStore.prototype.put=function(...args){if(this.name==='records')throw new DOMException('full','QuotaExceededError');return put.apply(this,args);};
  try {await act(async()=>api.choose('A'));await settle(()=>api.memory.status==='error');await act(async()=>api.memory.open(id));assert.equal(api.snapshot.choices['1'],'A');assert.match(api.memory.message,/空间不足/);}
  finally {IDBObjectStore.prototype.put=put;}
  await act(async()=>api.memory.retry());await settle(()=>api.memory.status==='saved');await unmount();await mount();assert.equal(api.snapshot.choices['1'],'A');
});
let second;
await test('切换试卷前保存当前进度，同名记录互不覆盖',async()=>{
  await act(async()=>{api.choose('B');});
  await act(async()=>{await api.memory.begin(paper('B'),new Blob(['second']));});await settle(()=>api.memory.status==='saved');second=api.memory.currentId;
  assert.notEqual(id,second);assert.equal(api.memory.records.length,2);
  await act(async()=>api.memory.open(id));await settle(()=>!api.memory.locked&&api.snapshot.exam.title==='A');assert.equal(api.snapshot.choices['1'],'B');
});
await test('打开不存在的试卷，错误不会被解锁后的自动保存清掉',async()=>{
  await act(async()=>api.memory.open('missing'));await settle(()=>!api.memory.locked);assert.equal(api.memory.status,'error');assert.match(api.memory.message,/删除/);assert.equal(api.snapshot.exam.title,'A');
});
await test('删除失败时保留原记录并保留错误提示',async()=>{
  const remove=Reflect.get(IDBObjectStore.prototype,'delete');IDBObjectStore.prototype.delete=function(...args){if(this.name==='records')throw new Error('模拟删除失败');return remove.apply(this,args);};
  try {await act(async()=>api.memory.remove(second));await settle(()=>!api.memory.locked);assert.equal(api.memory.records.length,2);assert.match(api.memory.message,/模拟删除失败/);}
  finally {IDBObjectStore.prototype.delete=remove;}
});
await test('删除其他记录保留当前作答，删除当前记录后重开仍为空',async()=>{
  await act(async()=>api.memory.remove(second));await settle(()=>api.memory.records.length===1&&!api.memory.locked&&api.memory.status==='saved');assert.equal(api.snapshot.choices['1'],'B');
  await act(async()=>api.memory.remove(id));await settle(()=>api.memory.currentId===null&&!api.memory.locked);assert.equal(api.snapshot.exam.filename,'');
  await unmount();await mount();assert.equal(api.memory.records.length,0);assert.equal(api.snapshot.exam.filename,'');await unmount();
});
console.log(`\n${count} memory lifecycle checks passed (React test renderer and simulated IndexedDB; not browser interaction tests).`);
