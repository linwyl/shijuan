import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {IDBFactory} from 'fake-indexeddb';
await build({entryPoints:['lib/exam-memory.ts'],outfile:'.test-build/exam-memory.mjs',bundle:true,platform:'node',format:'esm',logLevel:'silent'});
const {ExamMemory,memoryError}=await import(pathToFileURL(path.resolve('.test-build/exam-memory.mjs')).href);
const factory=new IDBFactory();
const make=(name='memory-test')=>new ExamMemory(()=>factory,name);
const image={src:'data:image/png;base64,aGVsbG8=',alt:'formula'};
const question=(id)=>({id,number:id,section:'',stem:'求 \\(x^2\\)',options:'ABCDE'.split('').map(key=>({key,label:key,text:key,visuals:[image]})),answer:'E',issues:[],images:[image],context:'reading',contextImages:[image],contextVisuals:[image],stemVisuals:[image],source:'test',kind:'single',order:Number(id)});
const exam={title:'数学 Math',filename:'same.pdf',questions:[question('3'),question('1')],warnings:['review'],sourceText:'source text',sourcePages:[{page:1,image,method:'review'}],requiresReview:true};
const original=new Blob(['original PDF bytes'],{type:'application/pdf'});
const snapshot=(choices={},extra={})=>({exam,choices,tab:'practice',...extra});
let count=0;
async function test(name,fn){await fn();count++;console.log('PASS '+name);}
let db=make(),id;
await test('首次启动不创建空记录',async()=>{assert.deepEqual(await db.restore(),{records:[],current:null,warning:''});});
await test('保存试卷、五个选项、选择和原始Blob，重启后恢复',async()=>{
  id=db.newId();await db.save(id,snapshot({'3':'E'}),original);await db.close();db=make();
  const {current,records}=await db.restore();assert.equal(records.length,1);assert.equal(current.id,id);assert.deepEqual(current.exam,exam);assert.deepEqual(current.choices,{'3':'E'});assert.equal(await current.source.text(),await original.text());
});
await test('公式与跨页原图、人工核对和修改完整保留',async()=>{
  const edited=structuredClone(exam);edited.questions[0].stem='修正 \\(\\frac{1}{2}\\)';edited.questions[0].stemVisuals.push(image);edited.questions[1].issues=['待核对'];
  await db.save(id,snapshot({'3':'E'},{exam:edited,tab:'review'}),original);
  assert.deepEqual((await db.load(id)).exam,edited);assert.equal((await db.load(id)).tab,'review');
});
await test('快速连续作答按顺序保存，最后一次选择不丢失',async()=>{
  const writes=[];for(let i=0;i<20;i++)writes.push(db.save(id,snapshot({'3':i%2?'E':'A','1':'B'}),original));await Promise.all(writes);
  assert.deepEqual((await db.load(id)).choices,{'3':'E','1':'B'});
});
await test('重新练习后重开，清空后的进度仍被保存',async()=>{await db.save(id,snapshot({}),original);assert.deepEqual((await db.load(id)).choices,{});});
let second;
await test('同名试卷独立保存，切换不串题和进度',async()=>{
  second=db.newId();await db.save(second,snapshot({'1':'C'},{exam:{...exam,title:'另一份'}}),original);
  const result=await db.restore();assert.equal(result.records.length,2);assert.equal(result.current.id,second);
  assert.deepEqual((await db.load(id)).choices,{});assert.equal((await db.restore()).current.id,id);
});
await test('删除非当前记录不影响当前试卷',async()=>{await db.remove(second);const result=await db.restore();assert.equal(result.records.length,1);assert.equal(result.current.id,id);});
await test('保存排队时删除，不被旧快照重新创建',async()=>{
  const writes=[db.save(id,snapshot({'3':'A'}),original),db.save(id,snapshot({'3':'E'}),original)];const deletion=db.remove(id);
  await Promise.allSettled(writes);await deletion;assert.equal((await db.restore()).records.length,0);assert.equal((await db.restore()).current,null);
  await assert.rejects(db.save(id,snapshot(),original),/删除/);
});
await test('另一页面删除后，旧页面的后续更新不能复活记录',async()=>{
  const a=make(),b=make();const key=a.newId();await a.save(key,snapshot(),original);await b.load(key);await a.remove(key);
  await assert.rejects(b.save(key,snapshot({'3':'E'}),original),/删除/);assert.equal((await b.restore()).records.length,0);await a.close();await b.close();
});
await test('另一个页面修改时阻止旧快照覆盖，重新打开后可继续',async()=>{
  const a=make(),b=make();const key=a.newId();await a.save(key,snapshot(),original);await b.load(key);await a.save(key,snapshot({'3':'E'}),original);
  await assert.rejects(b.save(key,snapshot({'1':'A'}),original),/其他页面更新/);await b.load(key);await b.save(key,snapshot({'3':'E','1':'A'}),original);
  assert.deepEqual((await a.load(key)).choices,{'3':'E','1':'A'});await a.remove(key);await a.close();await b.close();
});
await test('数据库不可用和配额不足返回可理解信息',async()=>{
  const unavailable=new ExamMemory(()=>undefined);await assert.rejects(unavailable.restore(),/无法自动保存/);
  const quota=new DOMException('full','QuotaExceededError');assert.match(memoryError(quota),/空间不足/);
  assert.match(memoryError(new DOMException('denied','SecurityError')),/本次内容尚未保存/);
});
await test('事务中断不得报成功，后续重试可以恢复',async()=>{
  const key=db.newId();const bad={...exam,invalid:()=>{}};
  await assert.rejects(db.save(key,snapshot({},{exam:bad}),original));assert.equal((await db.restore()).records.length,0);
  await db.save(key,snapshot(),original);assert.equal((await db.restore()).records.length,1);await db.remove(key);
});
await test('每次作答不重复写入大图和原文件',async()=>{
  const key=db.newId();await db.save(key,snapshot(),original);let paperPuts=0;
  const connection=await new Promise((resolve,reject)=>{const request=factory.open('memory-test',1);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
  const proto=Object.getPrototypeOf(connection.transaction('papers').objectStore('papers'));const put=proto.put;
  proto.put=function(...args){if(this.name==='papers')paperPuts++;return put.apply(this,args);};
  try { await db.save(key,snapshot({'3':'E'}),original);assert.equal(paperPuts,0);await db.save(key,snapshot({'3':'E'},{exam:{...exam,title:'Changed'}}),original);assert.equal(paperPuts,1); }
  finally {proto.put=put;connection.close();await db.remove(key);}
});
await test('删除同时移除原文件和最近打开标记，重新实例化后仍为空',async()=>{
  await db.close();db=make();const result=await db.restore();assert.deepEqual(result,{records:[],current:null,warning:''});
  const connection=await new Promise(resolve=>{const request=factory.open('memory-test',1);request.onsuccess=()=>resolve(request.result);});
  const papers=await new Promise(resolve=>{const request=connection.transaction('papers').objectStore('papers').count();request.onsuccess=()=>resolve(request.result);});assert.equal(papers,0);connection.close();
});
await test('恢复未修改的记录不写入新版本，不制造跨页面冲突',async()=>{
  const a=make(),b=make();const key=a.newId();await a.save(key,snapshot(),original);
  const {current}=await b.restore();await b.save(key,{exam:current.exam,choices:current.choices,tab:current.tab},current.source);
  await a.save(key,snapshot({'3':'E'}),original);assert.equal((await b.load(key)).choices['3'],'E');
  await a.remove(key);await a.close();await b.close();
});
await test('打开失败不改变最近试卷，刷新仍恢复原来的记录',async()=>{
  const key=db.newId();await db.save(key,snapshot(),original);await assert.rejects(db.load('missing-record'),/删除/);
  assert.equal((await db.restore()).current.id,key);await db.remove(key);
});
await db.close();
await fs.writeFile('.test-build/memory-test-result.json',JSON.stringify({passed:count,environment:'fake-indexeddb; no browser interaction test'},null,2));
console.log(`\n${count} persistence checks passed (IndexedDB simulation, not browser interaction tests).`);
