import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { build } from 'esbuild';
import { pathToFileURL } from 'node:url';
await fs.mkdir('.test-build',{recursive:true});
await build({entryPoints:['lib/import-word.ts'],outfile:'.test-build/import-word.mjs',platform:'node',format:'esm',bundle:true,packages:'external',logLevel:'silent'});
const {importWord}=await import(pathToFileURL(path.resolve('.test-build/import-word.mjs')).href);
const fixtures=JSON.parse(await fs.readFile('tests/fixtures/expected-all.json','utf8'));
const report=[];let failed=0;
for(const f of fixtures){try{const b=await fs.readFile('tests/fixtures/'+f.file);const exam=await importWord(b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),f.file);assert.equal(exam.questions.length,f.questions.length,'题目数量');
  for(let i=0;i<f.questions.length;i++){const expected=f.questions[i],q=exam.questions[i];assert.equal(q.number,expected.number,'题序/题号');assert.ok(q.stem.includes(expected.stem),'题干缺失 '+q.stem);assert.deepEqual(q.options.map(o=>({key:o.key,text:o.text})),expected.options,'选项内容');assert.equal(q.answer,expected.answer?.join('')||'','答案关联');if(expected.type==='multiple')assert.ok(q.issues.some(x=>x.includes('多选')),'多选未标记');else if(!expected.answer)assert.ok(q.issues.length,'缺失答案未标记');else if(expected.media?.includes('omml-formula'))assert.ok(q.stem.includes('frac{1}{2}')||q.issues.some(x=>x.includes('公式')),'公式结构或核对提示缺失');else if(expected.media?.includes('image'))assert.ok(q.images.length||q.issues.length,'图片静默丢失');else assert.deepEqual(q.issues,[],'正常题出现错误');}
  if(f.features.includes('reading-passage'))assert.ok(exam.questions.every(q=>q.context.includes('Answer')),'共同材料丢失');
  report.push({file:f.file,status:'passed',questions:exam.questions.length,ready:exam.questions.filter(q=>!q.issues.length).length});
}catch(e){failed++;report.push({file:f.file,status:'failed',error:e.message});}}
await fs.writeFile('.test-build/parser-report.json',JSON.stringify(report,null,2));
for(const r of report)console.log(`${r.status==='passed'?'PASS':'FAIL'} ${r.file}${r.error?' — '+r.error:''}`);
console.log(`\n${report.length-failed}/${report.length} fixture groups passed. Synthetic fixtures; not a real-world accuracy claim.`);
if(failed)process.exitCode=1;
