import fs from 'node:fs/promises';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
export async function documentAssetSource(){
  const pdf=path.dirname(require.resolve('pdfjs-dist/package.json'));
  const data={cMapUrl:{},standardFontDataUrl:{},wasmUrl:{},languages:{}};
  for(const [kind,folder,pattern] of [['cMapUrl','cmaps',/\.bcmap$/],['standardFontDataUrl','standard_fonts',/\.(pfb|ttf)$/],['wasmUrl','wasm',/\.wasm$/]]){
    for(const file of await fs.readdir(path.join(pdf,folder)))if(pattern.test(file))data[kind][file]=(await fs.readFile(path.join(pdf,folder,file))).toString('base64');
  }
  for(const language of ['chi_sim','eng']){
    const directory=path.dirname(require.resolve(`@tesseract.js-data/${language}/package.json`));
    data.languages[language]=(await fs.readFile(path.join(directory,'4.0.0_best_int',language+'.traineddata.gz'))).toString('base64');
  }
  return `export default ${JSON.stringify(data)};`;
}
export function documentAssetsEsbuild(){return{name:'document-assets',setup(builder){builder.onResolve({filter:/^virtual:document-assets$/},()=>({path:'document-assets',namespace:'document-assets'}));builder.onLoad({filter:/.*/,namespace:'document-assets'},async()=>({contents:await documentAssetSource(),loader:'js'}));}};}
export function documentAssetsVite(){return{name:'document-assets',resolveId(id){if(id==='virtual:document-assets')return '\0document-assets';},async load(id){if(id==='\0document-assets')return documentAssetSource();}};}
