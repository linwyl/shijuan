import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const html=await fs.readFile('dist/index.html','utf8');
assert.ok(html.includes('lang="zh-CN"'));
assert.ok(html.includes("connect-src 'none'"));
assert.ok(!/<script[^>]+src=|<link[^>]+(?:href=)/i.test(html),'HTML should not request external scripts or CSS');
assert.equal((html.match(/<\/script>/g)||[]).length,1,'One self-contained script terminator');
console.log('PASS HTML bundles scripts, CSS and network-blocking policy');
await build({entryPoints:['app/exam-app.tsx'],outbase:'.',outdir:'.test-build/render',outExtension:{'.js':'.mjs'},platform:'node',format:'esm',bundle:true,packages:'external',logLevel:'silent',plugins:[{name:'stub-browser-worker-for-render',setup(b){b.onResolve({filter:/\?worker&inline$/},()=>({path:'worker',namespace:'stub'}));b.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export default class Worker {}',loader:'js'}));}}]});
const {QuestionCard,default:ExamApp}=await import(pathToFileURL(path.resolve('.test-build/render/app/exam-app.mjs')).href);
const q={id:'test-choice',number:'1',section:'',stem:'Choose number five.',options:['one','two','three','four','five'].map((text,i)=>({key:'ABCDE'[i],label:'ABCDE'[i],text})),answer:'E',issues:[],images:[],context:'',source:'test',kind:'single',order:0};
const render=choice=>renderToStaticMarkup(React.createElement(QuestionCard,{question:q,index:0,choice,onChoose:()=>{}}));
const untouched=render();assert.ok(!untouched.includes('answer-feedback'));assert.ok(!untouched.includes('参考答案'));assert.ok(!untouched.includes('option correct'));console.log('PASS unselected card renders only question and choices');
assert.equal((untouched.match(/class="option-letter"/g)||[]).length,5,'all five choices rendered');
const right=render(q.answer);assert.ok(right.includes('回答正确'));assert.ok(right.includes('参考答案'));assert.ok(right.includes('option correct'));console.log('PASS correct selection reveals the current reference answer');
const wrong=render(q.options.find(o=>o.key!==q.answer).key);assert.ok(wrong.includes('再记住这道题'));assert.match(wrong,/class="option\s+incorrect/);assert.ok(wrong.includes('参考答案'));console.log('PASS wrong selection displays feedback and reference answer');
const page=renderToStaticMarkup(React.createElement(ExamApp));assert.equal((page.match(/class="question-card"/g)||[]).length,0);assert.ok(page.includes('导入试卷后开始答题'));assert.ok(page.includes('支持中文、英文、中英混合'));assert.ok(!page.includes('查看原文'));assert.ok(!page.includes('重新练习'));assert.ok(!page.includes('去核对'));assert.ok(!page.includes('answer-feedback'));assert.ok(!page.includes('review-card'));assert.ok(!page.includes('<pre>'));console.log('PASS initial page has no sample cards and waits for document import');
const workerCode=await fs.readFile('.test-build/word-worker.js','utf8');
const require=createRequire(import.meta.url);
const canvasPath=require.resolve('@napi-rs/canvas',{paths:[require.resolve('pdfjs-dist/package.json')]});
// Keep Node's host APIs intact (Response/canvas need them internally), but run
// application code in its own browser-like realm without Buffer/process/require.
const browserBootstrap=`const {parentPort}=require('node:worker_threads');const vm=require('node:vm');const canvas=require(${JSON.stringify(canvasPath)});const listeners=new Set();const sandbox={};
Object.assign(sandbox,{DOMMatrix:canvas.DOMMatrix,ImageData:canvas.ImageData,Path2D:canvas.Path2D});
sandbox.OffscreenCanvas=class{constructor(w,h){const c=canvas.createCanvas(w,h);c.convertToBlob=async({type='image/png',quality=.8}={})=>new Blob([await c.encode(type==='image/jpeg'?'jpeg':'png',Math.round(quality*100))],{type});return c;}};
for(const key of ['console','setTimeout','clearTimeout','setInterval','clearInterval','queueMicrotask','performance','atob','btoa','TextEncoder','TextDecoder','Blob','URL','URLSearchParams','DOMException','AbortController','AbortSignal','Response','Request','Headers','ReadableStream','WritableStream','TransformStream','DecompressionStream','CompressionStream','crypto','structuredClone','ArrayBuffer','SharedArrayBuffer','DataView','Uint8Array','Uint8ClampedArray','Uint16Array','Uint32Array','Int8Array','Int16Array','Int32Array','Float32Array','Float64Array','BigInt64Array','BigUint64Array'])sandbox[key]=globalThis[key];
sandbox.self=sandbox;sandbox.location={href:'blob:offline-test'};sandbox.WorkerGlobalScope=class{};
sandbox.addEventListener=(type,fn)=>{if(type==='message')listeners.add(fn);};sandbox.removeEventListener=(type,fn)=>listeners.delete(fn);sandbox.postMessage=value=>parentPort.postMessage(value);sandbox.importScripts=()=>{throw new Error('External worker scripts are forbidden');};
sandbox.fetch=()=>{throw new Error('Network access forbidden in offline test');};sandbox.XMLHttpRequest=class{constructor(){throw new Error('Network access forbidden in offline test');}};
vm.createContext(sandbox);vm.runInContext("if(typeof Buffer!=='undefined'||typeof process!=='undefined'||typeof require!=='undefined')throw new Error('Node globals leaked into browser realm')",sandbox);
vm.runInContext(${JSON.stringify(workerCode)},sandbox,{filename:'offline-parser-worker.js'});
parentPort.on('message',data=>{sandbox.onmessage?.({data});for(const fn of listeners)fn({data});});`;
const worker=new Worker(browserBootstrap,{eval:true});
const ask=data=>new Promise((resolve,reject)=>{const clean=()=>{clearTimeout(timer);worker.off('message',message);worker.off('error',error);};const error=e=>{clean();reject(e);};const message=r=>{if(!r.exam&&!r.error)return;clean();resolve(r);};const timer=setTimeout(()=>error(new Error('Worker timeout')),90000);worker.on('message',message);worker.once('error',error);worker.postMessage(data,[data.bytes]);});
try{const b=await fs.readFile('tests/fixtures/03_mixed_inline_answers.docx');const result=await ask({bytes:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),filename:'mixed.docx'});assert.ok(!result.error,result.error);assert.equal(result.exam.questions.length,3);assert.equal(result.exam.questions.filter(q=>!q.issues.length).length,3);console.log('PASS production worker bundle imports a real mixed-language DOCX fixture');const bad=await ask({bytes:new ArrayBuffer(16),filename:'fake.docx'});assert.match(bad.error,/格式不符/);console.log('PASS production worker returns a readable invalid-file error');
for(const name of ['01_mixed_five_options_source_order.pdf','04_scanned_mixed_five_options.pdf']){const b=await fs.readFile('tests/pdf-fixtures/'+name);const result=await ask({bytes:b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength),filename:name});assert.ok(!result.error,result.error);assert.equal(result.exam.questions[0].options.length,5);assert.equal(result.exam.questions[0].answer,'E');if(name.startsWith('04'))assert.ok(result.exam.questions[0].issues.length&&result.exam.sourcePages.length);console.log('PASS production worker, network forbidden: '+name);}
const wordMathBytes=await fs.readFile('tests/math-fixtures/01_native_math_five_options.docx');const wordMath=await ask({bytes:wordMathBytes.buffer.slice(wordMathBytes.byteOffset,wordMathBytes.byteOffset+wordMathBytes.byteLength),filename:'native-math.docx'});assert.ok(!wordMath.error,wordMath.error);assert.ok(wordMath.exam.questions.some(q=>q.stem.includes('frac{')));assert.ok(wordMath.exam.questions.every(q=>q.options.length===5));console.log('PASS native Word formulas and KaTeX validation in browser realm without Node globals');
const mathPdfBytes=await fs.readFile('tests/pdf-math-fixtures/04_scanned_math.pdf');const mathPdf=await ask({bytes:mathPdfBytes.buffer.slice(mathPdfBytes.byteOffset,mathPdfBytes.byteOffset+mathPdfBytes.byteLength),filename:'scanned-math.pdf'});assert.ok(!mathPdf.error,mathPdf.error);assert.equal(mathPdf.exam.questions.length,2);for(const question of mathPdf.exam.questions){assert.ok(question.stemVisuals?.length);assert.equal(question.options.length,5);assert.ok(question.options.every(o=>o.visuals?.length));assert.ok(question.issues.length);}console.log('PASS scanned math preserves stem and all five option images without Node globals/network');
}finally{await worker.terminate();}
console.log('\n11 offline/rendering/worker checks passed. Browser globals and canvas are simulated in Node; these are not browser interaction tests.');
