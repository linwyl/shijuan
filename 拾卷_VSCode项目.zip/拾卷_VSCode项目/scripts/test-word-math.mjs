import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import {DOMParser} from '@xmldom/xmldom';
import katex from 'katex';

await fs.mkdir('.test-build/word-math',{recursive:true});
await build({entryPoints:['lib/word-math.ts','lib/word-reader.ts','lib/import-word.ts'],outdir:'.test-build/word-math',outExtension:{'.js':'.mjs'},platform:'node',format:'esm',bundle:true,packages:'external',logLevel:'silent'});
const load=name=>import(pathToFileURL(path.resolve('.test-build/word-math/'+name+'.mjs')).href);
const {ommlToLatex,wordVerticalText}=await load('word-math');
const {readWord}=await load('word-reader');
const {importWord}=await load('import-word');
const fixtures='tests/math-fixtures/';
const cases=JSON.parse(await fs.readFile(fixtures+'omml-cases.json','utf8'));
const element=fragment=>new DOMParser().parseFromString(`<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">${fragment}</m:oMath>`,'application/xml').documentElement;
const render=latex=>katex.renderToString(latex,{output:'htmlAndMathml',throwOnError:true,trust:false,strict:'ignore',maxExpand:1000,maxSize:30});
const buffer=b=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength);
const readFixture=async name=>buffer(await fs.readFile(fixtures+name));
let passed=0;
async function test(name,fn){await fn();passed++;console.log('PASS '+name);}

for(const fixture of cases)await test('OMML '+fixture.name,()=>{
  const result=ommlToLatex(element(fixture.xml));
  if(fixture.equals)assert.equal(result.latex,fixture.equals);
  for(const fragment of fixture.includes||[])assert.ok(result.latex.includes(fragment),`missing ${fragment}: ${result.latex}`);
  for(const fragment of fixture.excludes||[])assert.ok(!result.latex.includes(fragment),`unexpected ${fragment}: ${result.latex}`);
  assert.ok(!/[\r\n]/.test(result.latex),'公式中不得出现实际换行');
  if(fixture.warning)assert.ok(result.issues.length,'未知或不完整公式必须核对');
  else assert.deepEqual(result.issues,[],'完整支持公式不应一概提示未支持');
  const html=render(result.latex);
  assert.ok(!/(?:href|src)="(?:https?:|javascript:)/i.test(html),'用户公式文字不能产生外部链接或资源');
  assert.ok(!html.includes('class="bad"'),'用户文字不能注入HTML class');
});

await test('Word普通上下标保留，普通文本保持原样',()=>{
  assert.equal(wordVerticalText('2','superscript'),'\\({}^{2}\\)');
  assert.equal(wordVerticalText('2','subscript'),'\\({}_{2}\\)');
  assert.equal(wordVerticalText('正文普通文字','baseline'),'正文普通文字');
  assert.equal(wordVerticalText('2026',''),'2026');
  render(wordVerticalText(String.raw`\href{x}{y}`,'superscript').slice(2,-2));
});

await test('五选项DOCX的题干/选项/材料公式保持位置与答案E',async()=>{
  const bytes=await readFixture('01_native_math_five_options.docx');
  const blocks=await readWord(bytes,'native.docx');
  assert.deepEqual(blocks.warnings,[]);
  assert.ok(blocks.blocks.every(b=>!(b.warnings||[]).length));
  assert.ok(!blocks.blocks.some(b=>b.text.includes('[Word公式')));
  const exam=await importWord(bytes,'native.docx');
  assert.deepEqual(exam.questions.map(q=>q.number),['1','3','2','4','5']);
  for(const question of exam.questions){
    assert.deepEqual(question.options.map(o=>o.key),['A','B','C','D','E']);
    assert.equal(question.answer,'E');
    assert.deepEqual(question.issues,[],JSON.stringify(question));
    assert.ok(question.context.includes('\\({x}_{i}^{2}\\)'),question.context);
  }
  assert.ok(exam.questions[0].stem.includes('\\(\\frac{a}{b}\\)'));
  assert.equal(exam.questions[0].options[4].text,'\\(\\frac{1}{2}\\)');
  assert.ok(exam.questions[2].options[0].text.includes('\\begin{matrix}1&2\\\\3&4'));
  assert.ok(exam.questions[2].options[1].text.includes('\\begin{gathered}'));
  assert.ok(exam.questions[4].stem.includes('x\\({}^{2}\\) 与 H\\({}_{2}\\)O'));
});

await test('未知OMML、MathType与字体编码符号保留痕迹并核对',async()=>{
  const exam=await importWord(await readFixture('02_unsupported_and_literal_text.docx'),'unsupported.docx');
  assert.equal(exam.questions.length,4);
  assert.ok(exam.questions[0].stem.includes('x+yz'));
  assert.match(exam.questions[0].issues.join(' '),/未完整支持/);
  assert.match(exam.questions[1].stem,/嵌入公式或对象/);
  assert.match(exam.questions[1].issues.join(' '),/MathType/);
  assert.match(exam.questions[2].stem,/Symbol F061/);
  assert.match(exam.questions[2].issues.join(' '),/特殊字体符号/);
  assert.equal(exam.questions[3].options.length,5);
  assert.equal(exam.questions[3].answer,'E');
  assert.deepEqual(exam.questions[3].issues,[]);
});

await test('旧图片与公式fixture12保留真实1/2及原答案B',async()=>{
  const file='tests/fixtures/12_image_and_native_formula.docx';
  const exam=await importWord(buffer(await fs.readFile(file)),'existing.docx');
  assert.equal(exam.questions.length,3);
  assert.equal(exam.questions[1].answer,'B');
  assert.ok(exam.questions[1].stem.includes('\\frac{1}{2}'));
  assert.deepEqual(exam.questions[1].issues,[]);
});

await test('未知分式类型与异常矩阵不被静默认定为正确',()=>{
  const a=ommlToLatex(element('<m:f><m:fPr><m:type m:val="unknown"/></m:fPr><m:num><m:r><m:t>a</m:t></m:r></m:num><m:den><m:r><m:t>b</m:t></m:r></m:den></m:f>'));
  assert.ok(a.issues.length);
  const b=ommlToLatex(element('<m:m><m:mr><m:e><m:r><m:t>a</m:t></m:r></m:e></m:mr><m:mr><m:e/><m:e/></m:mr></m:m>'));
  assert.match(b.issues.join(' '),/行列不完整/);
});

await test('公式结构深度受限，不无限递归',()=>{
  const result=ommlToLatex(element('<m:e>'.repeat(110)+'<m:r><m:t>x</m:t></m:r>'+'</m:e>'.repeat(110)));
  assert.match(result.issues.join(' '),/过深或过大/);
  assert.ok(result.latex.length<1000);
});
console.log(`\n${passed} native Word math/position/security checks passed. Synthetic cases, not a real-world accuracy claim.`);
