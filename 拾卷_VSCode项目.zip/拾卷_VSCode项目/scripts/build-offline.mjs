// Build a single HTML file with the application, CSS and Word worker included.
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';
import postcss from 'postcss';
import tailwind from '@tailwindcss/postcss';
import {documentAssetsEsbuild} from './document-assets.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);
const common = {
  bundle: true,
  metafile: true,
  platform: 'browser',
  format: 'iife',
  target: ['chrome110', 'edge110', 'firefox115', 'safari17'],
  minify: true,
  legalComments: 'inline',
  logLevel: 'warning',
  define: { 'process.env.NODE_ENV': '"production"' },
};
const worker = await build({
  ...common,
  entryPoints: ['lib/parser-worker.ts'],
  plugins: [documentAssetsEsbuild()],
  external: ['fs','path','crypto','node:*'],
  write: false,
});
const workerCode = worker.outputFiles[0].text;
const app = await build({
  ...common,
  entryPoints: ['app/offline-entry.tsx'],
  write: false,
  plugins: [
    {
      name: 'offline-worker',
      setup(builder) {
        builder.onResolve({ filter: /\?worker&inline$/ }, () => ({
          path: 'word-worker',
          namespace: 'offline-worker',
        }));
        builder.onLoad({ filter: /.*/, namespace: 'offline-worker' }, () => ({
          loader: 'js',
          contents: `
      export default class LocalWordWorker extends Worker {
        constructor(){const url=URL.createObjectURL(new Blob([${JSON.stringify(workerCode)}],{type:'text/javascript'}));super(url);this.localUrl=url;}
        terminate(){super.terminate();if(this.localUrl){URL.revokeObjectURL(this.localUrl);this.localUrl=null;}}
      }
    `,
        }));
      },
    },
  ],
});
const css = await postcss([tailwind({ base: root, optimize: true })]).process(
  await fs.readFile('app/globals.css', 'utf8'),
  { from: path.join(root, 'app/globals.css') },
);
if (/@import\s/.test(css.css))
  throw new Error('CSS still contains an external import.');
const script = app.outputFiles[0].text.replace(/<\/script/gi, '<\\/script');
const packages = new Map(['tailwindcss', 'tw-animate-css', 'shadcn','@tesseract.js-data/chi_sim','@tesseract.js-data/eng'].map(name => [name, path.join(root, 'node_modules', name)]));
for (const input of [...Object.keys(worker.metafile.inputs), ...Object.keys(app.metafile.inputs)]) {
  const normalized = input.replaceAll('\\', '/');
  const offset = normalized.lastIndexOf('node_modules/');
  if (offset < 0) continue;
  const name = normalized.slice(offset + 13).match(/^((?:@[^/]+\/)?[^/]+)/)?.[1];
  if (name) packages.set(name, path.resolve(root, normalized.slice(0, offset + 13) + name));
}
let notices = 'Paper Cards — bundled third-party notices\n\n';
for (const [name, directory] of [...packages].sort(([a], [b]) => a.localeCompare(b))) {
  const metadata = JSON.parse(await fs.readFile(path.join(directory, 'package.json'), 'utf8'));
  const licenses = (await fs.readdir(directory)).filter(file => /^(?:licen[cs]e|copying)(?:\.|$)/i.test(file));
  notices += `\n===== ${name} ${metadata.version} (${metadata.license || 'see package'}) =====\n`;
  if (!licenses.length) {
    const readme=(await fs.readdir(directory)).find(file=>/^readme(?:\.|$)/i.test(file));
    if(!readme||!metadata.license)throw new Error(`Missing bundled license: ${name}`);
    notices += `${metadata.repository?.url || metadata.repository || metadata.homepage || ''}\n` + await fs.readFile(path.join(directory,readme),'utf8') + '\n';
  }
  for (const file of licenses) notices += await fs.readFile(path.join(directory, file), 'utf8') + '\n';
}
notices += '\n===== JSDoc, pinned 821695a884e0c0bb8592a635d9524bb3e116cd67 =====\n';
notices += await fs.readFile('lib/vendor/JSDoc-LICENSE.txt', 'utf8');
const escapedNotices = notices.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
const html = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline' 'wasm-unsafe-eval' blob:; style-src 'unsafe-inline'; img-src data: blob:; worker-src blob:; font-src data:; connect-src 'none'; base-uri 'none'; form-action 'none'">
<meta name="description" content="拾卷：在本地读取中英文Word、文字PDF与扫描PDF，按原顺序练习。无需联网。">
<title>拾卷 · Word与PDF试卷答题卡片</title><style>${css.css.replace(/<\/style/gi, '<\\/style')}</style></head>
<body><div id="root"><p style="padding:40px;font-family:Arial,sans-serif">正在打开拾卷…</p></div><noscript>请启用浏览器的JavaScript后打开此页面。</noscript><template id="third-party-notices"><pre>${escapedNotices}</pre></template><script>${script}</script></body></html>`;
await fs.mkdir('dist', { recursive: true });
await fs.writeFile('dist/index.html', html);
await fs.writeFile('dist/THIRD_PARTY_NOTICES.txt', notices);
// Worker is an intermediate test artifact; it is already embedded in the HTML.
await fs.mkdir('.test-build', { recursive: true });
await fs.writeFile('.test-build/word-worker.js', workerCode);
console.log(
  `Built dist/index.html (${(Buffer.byteLength(html) / 1024).toFixed(0)} KB). No CDN, network API or server required.`,
);
