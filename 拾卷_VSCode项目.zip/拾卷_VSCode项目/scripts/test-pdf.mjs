import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {build} from 'esbuild';
import {documentAssetsEsbuild} from './document-assets.mjs';
const require=createRequire(import.meta.url);
const canvas=require(require.resolve('@napi-rs/canvas',{paths:[require.resolve('pdfjs-dist/package.json')]}));
Object.assign(globalThis,{DOMMatrix:canvas.DOMMatrix,ImageData:canvas.ImageData,Path2D:canvas.Path2D});
globalThis.OffscreenCanvas=class{constructor(width,height){const result=canvas.createCanvas(width,height);result.convertToBlob=async({type='image/png',quality=.8}={})=>new Blob([await result.encode(type==='image/jpeg'?'jpeg':'png',Math.round(quality*100))],{type});return result;}};
globalThis.createImageBitmap=async blob=>{const image=await canvas.loadImage(Buffer.from(await blob.arrayBuffer()));image.close=()=>{};return image;};
await fs.mkdir('.test-build',{recursive:true});
await build({entryPoints:['lib/import-document.ts'],outfile:'.test-build/import-document.mjs',platform:'node',format:'esm',bundle:true,packages:'external',plugins:[documentAssetsEsbuild()],logLevel:'silent'});
const {importDocument}=await import(pathToFileURL(path.resolve('.test-build/import-document.mjs')).href);
const fixtures=JSON.parse(await fs.readFile('tests/pdf-fixtures/expected-all.json','utf8'));
const report=[];
for(const fixture of fixtures){
  const bytes=await fs.readFile('tests/pdf-fixtures/'+fixture.file);
  try{
    if(fixture.kind==='encrypted'){await assert.rejects(importDocument(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),fixture.file),/密码保护/);report.push({file:fixture.file,status:'passed'});console.log('PASS '+fixture.file);continue;}
    const exam=await importDocument(bytes.buffer.slice(bytes.byteOffset,bytes.byteOffset+bytes.byteLength),fixture.file);
    await fs.writeFile('.test-build/'+fixture.file+'.json',JSON.stringify(exam,null,2));
    assert.equal(exam.questions.length,fixture.questions.length,'question count');
    if(fixture.kind==='mixed-text-scan'){
      assert.deepEqual(exam.questions.map(q=>q.number),fixture.sourceOrder);
      assert.ok(exam.requiresReview&&exam.questions.every(q=>q.issues.length));
      assert.ok(exam.questions.every(q=>q.options.length===5));
      assert.equal(exam.sourcePages.filter(page=>page.method==='ocr').length,1);
      report.push({file:fixture.file,status:'passed',questions:exam.questions.length});console.log('PASS '+fixture.file);continue;
    }
    if(fixture.kind==='two-column'){
      assert.ok(exam.requiresReview,'columns must require review');
      assert.ok(exam.questions.every(q=>q.issues.length),'ambiguous layout cannot enter practice');
      assert.ok(exam.questions.every(q=>q.options.length===5&&q.answer==='E'),'columns preserve all five choices and explicit answer keys');
    }else{
      assert.deepEqual(exam.questions.map(q=>q.number),fixture.sourceOrder,'source order');
      for(let i=0;i<fixture.questions.length;i++){
        const q=exam.questions[i],expected=fixture.questions[i];
        assert.equal(q.options.length,5,'five complete options');
        assert.deepEqual(q.options.map(o=>o.key),['A','B','C','D','E'],'option labels');
        assert.equal(q.answer,expected.answer,'answer E association');
        if(fixture.kind!=='image-only'){
          assert.ok(q.stem.includes(expected.stem),'stem');
          if(expected.continuation)assert.ok(q.stem.includes(expected.continuation),'cross-page continuation');
          assert.deepEqual(q.options.map(o=>o.text),expected.options,'option content');
          if(fixture.kind==='text-table')assert.ok(exam.requiresReview&&q.issues.length,'table graphics remain reviewable');
          else assert.deepEqual(q.issues,[],'clean text should not require manual OCR review');
        }else{
          assert.ok(q.issues.some(issue=>issue.includes('OCR')),'OCR always requires manual review');
          assert.ok(q.stem.includes('以下')&&q.stem.includes('Choose'),'mixed language OCR content');
        }
      }
    }
    if(fixture.kind==='image-only'){assert.equal(exam.sourcePages.length,1);assert.ok(exam.sourcePages[0].image.src.startsWith('data:image/jpeg;base64,'),'original scan preview');}
    report.push({file:fixture.file,status:'passed',questions:exam.questions.length});console.log('PASS '+fixture.file);
  }catch(error){report.push({file:fixture.file,status:'failed',error:error.message});console.log('FAIL '+fixture.file+' '+error.message);}
}
await assert.rejects(importDocument(new TextEncoder().encode('not a real PDF').buffer,'invalid.pdf'),/PDF格式不符/);
report.push({file:'invalid PDF signature',status:'passed'});
await fs.writeFile('.test-build/pdf-report.json',JSON.stringify(report,null,2));
console.log(`${report.filter(r=>r.status==='passed').length}/${report.length} PDF/OCR/five-option checks passed; OCR outputs remain unconfirmed.`);
if(report.some(r=>r.status==='failed'))process.exitCode=1;
