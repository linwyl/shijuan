import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {build} from 'esbuild';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
await fs.mkdir('.test-build',{recursive:true});
await build({entryPoints:['lib/math-render.ts','lib/math-text.ts','lib/exam-parser.ts','lib/crop-geometry.ts','app/math-text.tsx','app/exam-app.tsx','app/pdf-cropper.tsx'],outdir:'.test-build/math-ui',bundle:true,platform:'node',format:'esm',outExtension:{'.js':'.mjs'},packages:'external',logLevel:'silent',plugins:[{name:'stub-render-worker',setup(b){b.onResolve({filter:/\?worker&inline$/},()=>({path:'worker',namespace:'stub'}));b.onLoad({filter:/.*/,namespace:'stub'},()=>({contents:'export default class Worker {}',loader:'js'}));}}]});
const load=file=>import(pathToFileURL(path.resolve('.test-build/math-ui/'+file+'.mjs')).href);
const {renderFormula,mathIssues}=await load('lib/math-render');
const {parseExam,splitOptions,validateQuestion}=await load('lib/exam-parser');
const {MathText}=await load('app/math-text');
const {QuestionCard,default:ExamApp}=await load('app/exam-app');
const {boxFromPoints,pixelBox}=await load('lib/crop-geometry');
const {default:PdfCropper}=await load('app/pdf-cropper');
let count=0;
function test(name,fn){fn();count++;console.log('PASS '+name);}
test('分式、根号、上下标、积分和矩阵输出原生MathML',()=>{
  for(const [latex,tag] of [[String.raw`\frac{a}{b}`,'mfrac'],[String.raw`\sqrt{x}`,'msqrt'],[String.raw`\sqrt[3]{x}`,'mroot'],['x_{i}^{2}','msubsup'],[String.raw`\sum\limits_{i=1}^{n}i`,'munderover'],[String.raw`\int_{0}^{1}x dx`,'msubsup'],[String.raw`\begin{matrix}1&2\\3&4\end{matrix}`,'mtable']]){const r=renderFormula(latex,tag==='munderover');assert.ok(!r.error,latex);assert.ok(r.html.includes('<'+tag),latex);}
});
test('公式中的A./(B)不拆成选项，仍保留外部五选项',()=>{const options=splitOptions(String.raw`A. \(\text{B. and (C)}\) B. 2 C. 3 D. 4 E. \(x^{2}\)`);assert.deepEqual(options.options.map(o=>o.key),['A','B','C','D','E']);assert.ok(options.options[0].text.includes('B. and (C)'));});
test('材料、题干及五个公式选项按题序保留',()=>{const e=parseExam([String.raw`Reading passage: \(\frac{1}{2}\)`,String.raw`3. 求 \(x^{2}\)`,...['A','B','C','D','E'].map((v,i)=>`${v}. \\(\\sqrt{${i+1}}\\)`),'Answer Key','3. E'].map((text,i)=>({text,source:String(i)})),'math.docx');assert.equal(e.questions.length,1);assert.equal(e.questions[0].answer,'E');assert.equal(e.questions[0].options.length,5);assert.deepEqual(e.questions[0].issues,[]);});
test('错误公式不会静默放行，超长或未闭合公式会提示',()=>{assert.ok(mathIssues(String.raw`\(\frac{1}\)`).length);assert.ok(mathIssues(String.raw`\(x^2`).length);assert.ok(renderFormula('x'.repeat(12001)).error);});
test('阅读材料夹有答案时阻止未作答卡片提前显示',()=>{const e=parseExam(['Reading passage: 材料。参考答案：E','1. Select one.','A. one','B. two','C. three','D. four','E. five','Answer Key','1. E'].map(text=>({text,source:'test'})),'context.docx');assert.equal(e.questions.length,1);assert.ok(e.questions[0].issues.some(i=>i.includes('提前显示')));});
test('外部图片/脚本及HTML输入不会变为可执行内容',()=>{const markup=renderToStaticMarkup(React.createElement(MathText,{text:String.raw`<img src=x onerror=alert(1)> \(\href{javascript:alert(1)}{x}\)`}));assert.ok(!markup.includes('<img'));assert.ok(!markup.includes('href="javascript:'));assert.ok(markup.includes('&lt;img'));});
const pictures=['stem','A','B','C','D','E'].map(id=>({src:'data:image/png;base64,'+id,alt:id+' formula'}));
test('无阅读材料的Word题不在题干前多显示0，原文中的0仍保留',()=>{
  const exam=parseExam(['19. 辛亥革命发生在哪一年（）','A. 1900年 B. 1911年 C. 1921年 D. 1949年','参考答案','19. B'].map(text=>({text,source:'word'})),'plain.docx');
  const q=exam.questions[0];
  assert.deepEqual(q.contextVisuals,[]);
  for(const contextVisuals of [[],undefined]){
    const html=renderToStaticMarkup(React.createElement(QuestionCard,{question:{...q,contextVisuals},index:0,onChoose:()=>{}}));
    assert.ok(html.includes('</div><h2 id='),'题目信息栏后应直接显示题干，不能夹入0');
    assert.ok(!html.includes('reading-material'));
    assert.ok(html.includes('<span>辛亥革命发生在哪一年（）</span>'));
    assert.ok(html.includes('<span>1900年</span>'));
  }
  const zero=renderToStaticMarkup(React.createElement(QuestionCard,{question:{...q,stem:'0',options:q.options.map(o=>({...o,text:'0'}))},index:0,onChoose:()=>{}}));
  assert.equal((zero.match(/<span>0<\/span>/g)||[]).length,5);
});
test('文字和原图阅读材料仍显示，文字0也属于有效材料',()=>{
  const q=parseExam(['1. Choose one.','A. one B. two','Answer Key','1. B'].map(text=>({text,source:'word'})),'passage.docx').questions[0];
  for(const context of ['阅读材料正文','0']){
    const html=renderToStaticMarkup(React.createElement(QuestionCard,{question:{...q,context},index:0,onChoose:()=>{}}));
    assert.ok(html.includes('class="reading-material"'));
    assert.ok(html.includes(`<span>${context}</span>`));
  }
  const html=renderToStaticMarkup(React.createElement(QuestionCard,{question:{...q,contextVisuals:[pictures[0]]},index:0,onChoose:()=>{}}));
  assert.ok(html.includes('class="reading-material"'));
  assert.ok(html.includes(`src="${pictures[0].src}"`));
  assert.ok(!html.includes('</div>1<h2'));
});
let visualQuestion;
test('PDF题干和选项原图分别关联，跨页续片保持顺序',()=>{const blocks=[{text:'1. 求以下表达式',source:'p1',visuals:[pictures[0]]},...['A','B','C','D','E'].map((key,i)=>({text:key+'. option '+key,source:'p1',visuals:[pictures[i+1]]})),{text:'第五项续页',source:'p2',visuals:[{src:'data:image/png;base64,continuation',alt:'续页'}]},{text:'答案\n1. E',source:'key'}];const e=parseExam(blocks,'formula.pdf');visualQuestion=e.questions[0];assert.deepEqual(visualQuestion.stemVisuals,[pictures[0]]);assert.deepEqual(visualQuestion.options.map(o=>o.visuals.length),[1,1,1,1,2]);assert.equal(visualQuestion.options[4].visuals[1].alt,'续页');});
test('未作答卡片显示五个独立公式选项且不泄露答案',()=>{const html=renderToStaticMarkup(React.createElement(QuestionCard,{question:visualQuestion,index:0,onChoose:()=>{}}));assert.equal((html.match(/class="option-letter"/g)||[]).length,5);assert.equal((html.match(/<img /g)||[]).length,7);assert.ok(!html.includes('参考答案'));assert.ok(!html.includes('answer-feedback'));const answered=renderToStaticMarkup(React.createElement(QuestionCard,{question:visualQuestion,index:0,choice:'E',onChoose:()=>{}}));assert.ok(answered.includes('回答正确'));});
test('仅原图字段可通过校验，多题同块不误配原图',()=>{assert.deepEqual(validateQuestion({...visualQuestion,stem:'',options:visualQuestion.options.map(o=>({...o,text:''}))}),[]);const e=parseExam([{text:'1. x\nA. one\nB. two',source:'p1',visuals:[pictures[0]]},{text:'答案\n1. B',source:'key'}],'ambiguous.pdf');assert.ok(!e.questions[0].stemVisuals?.length);assert.ok(!e.questions[0].options.some(o=>o.visuals?.length));assert.ok(e.questions[0].issues.some(i=>i.includes('原图')));const multi=parseExam([{text:'1. first\nA. one\nB. two\n2. second\nA. one\nB. two',source:'same',visuals:[pictures[0]]},{text:'答案\n1. A\n2. B',source:'key'}],'multi.pdf');assert.equal(multi.questions.length,2);assert.ok(multi.questions.every(q=>q.issues.some(i=>/图片归属|原图/.test(i))));});
test('框选支持反向拖动、边界约束和正确像素映射',()=>{assert.deepEqual(boxFromPoints({x:.8,y:.9},{x:.2,y:.1}),{x:.2,y:.1,width:.6000000000000001,height:.8});assert.deepEqual(pixelBox({x:.25,y:.1,width:.5,height:.2},1000,2000),{x:250,y:200,width:500,height:400});assert.deepEqual(pixelBox({x:-1,y:2,width:3,height:3},1000,2000),{x:0,y:2000,width:1000,height:0});});
test('框选提供键盘数值入口与防答案混入确认，删除指定三处文案',()=>{const html=renderToStaticMarkup(React.createElement(PdfCropper,{pages:[{page:1,image:pictures[0],method:'review'}],targets:[{key:'stem',label:'题干'}],onAdd:()=>{}}));assert.equal((html.match(/type="number"/g)||[]).length,4);assert.ok(html.includes('不含参考答案'));assert.ok(/<button[^>]*disabled/.test(html));const app=renderToStaticMarkup(React.createElement(ExamApp));for(const text of ['本地处理 · 文件留在你的设备','先用示例体验','原文识别，不生成或猜测答案。'])assert.ok(!app.includes(text));});
console.log(`\n${count} formula/rendering/crop checks passed (no browser interaction tests).`);
