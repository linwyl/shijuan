from pathlib import Path
import json
from pypdf import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4

ROOT = Path(__file__).resolve().parent
expected_path = ROOT / 'expected-all.json'
expected = [item for item in json.loads(expected_path.read_text(encoding='utf-8')) if not item['file'].startswith(('07_', '08_', '09_'))]
base = next(item for item in expected if item['file'].startswith('01_'))
scanned = next(item for item in expected if item['file'].startswith('04_'))

filename = '07_mixed_text_and_scan.pdf'
writer = PdfWriter()
writer.append(ROOT / base['file'])
writer.append(ROOT / scanned['file'])
with (ROOT / filename).open('wb') as stream:
    writer.write(stream)
expected.append(dict(file=filename, kind='mixed-text-scan', questions=base['questions']+scanned['questions'], sourceOrder=['1','3','2','1'], allPending=True, note='第一页文字层，第二页真实扫描。总 4 题，保留重复题号 1；混合页 OCR 及重复题号必须核对，不得静默合并或错配答案。'))

pdfmetrics.registerFont(TTFont('FixtureCN', 'C:/Windows/Fonts/simhei.ttf'))
W,H = A4
filename = '08_repeated_options_at_page_edge.pdf'
c = canvas.Canvas(str(ROOT / filename), pagesize=A4)
c.setTitle('Repeated answer choices at page edge')
questions = []
for number in [1,2]:
    stem = '请选择数字“五”的英文单词。' if number == 1 else 'Choose the English word for number five.'
    c.setFont('FixtureCN', 12)
    c.drawString(48,H-18, str(number)+'. '+stem)
    for idx,word in enumerate(['one','two','three','four','five']):
        c.drawString(48,H-42-idx*28,f'{chr(65+idx)}. {word}')
    if number == 2:
        c.drawString(48,H-240,'参考答案 / Answer Key')
        c.drawString(48,H-270,'1. E    2. E')
    questions.append(dict(number=str(number),stem=stem,options=['one','two','three','four','five'],answer='E'))
    c.showPage()
c.save()
expected.append(dict(file=filename, kind='repeated-page-edge-options', questions=questions, sourceOrder=['1','2'], note='两页的题干基线距顶边 18 pt，重复 A. one 基线距顶边 42 pt。不能仅因文本重复且靠近页边而当作页眉删除；两题必须各有 A-E。'))

filename = '09_encrypted.pdf'
writer = PdfWriter()
writer.append(ROOT / base['file'])
writer.encrypt(user_password='fixture-only', owner_password='fixture-owner-only', algorithm='RC4-128')
with (ROOT / filename).open('wb') as stream:
    writer.write(stream)
assert PdfReader(ROOT / filename).is_encrypted
expected.append(dict(file=filename,kind='encrypted',expectedError=True,password='fixture-only',note='只用于验证应用拒绝加密 PDF 并提示用户先解除密码；应用不应自动猜测/绕过密码。生成器使用测试兼容性加密算法，非安全配置建议。'))

expected_path.write_text(json.dumps(expected,ensure_ascii=False,indent=2),encoding='utf-8')
for filename in ['07_mixed_text_and_scan.pdf','08_repeated_options_at_page_edge.pdf']:
    reader=PdfReader(ROOT/filename)
    page_texts=[page.extract_text() or '' for page in reader.pages]
    print(filename, 'pages:',len(page_texts),'characters:',list(map(len,page_texts)))
    if filename.startswith('07_'):
        assert len(page_texts)==2 and len(page_texts[0])>100 and not page_texts[1].strip()
    else:
        assert len(page_texts)==2 and all('A. one' in text and 'E. five' in text for text in page_texts)
print('Created edge fixtures 07-09 without changing 01-06.')
