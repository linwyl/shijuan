from pathlib import Path
from io import BytesIO
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Pt
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent
ROOT.mkdir(exist_ok=True)
pdfmetrics.registerFont(TTFont('FixtureCN', 'C:/Windows/Fonts/simhei.ttf'))
W, H = A4
EXPECTED = []

def sheet(filename, title):
    c = canvas.Canvas(str(ROOT / filename), pagesize=A4)
    c.setTitle(title)
    c.setAuthor('Synthetic regression fixture')
    c.setFont('FixtureCN', 17)
    c.drawString(48, H - 48, title)
    c.setFont('FixtureCN', 11)
    return c

def lines(c, texts, x=48, y=None, step=24, size=12):
    y = H - 85 if y is None else y
    c.setFont('FixtureCN', size)
    for text in texts:
        c.drawString(x, y, text)
        y -= step
    return y

def q(number, stem, options, answer, **extras):
    return dict(number=str(number), stem=stem, options=options, answer=answer, **extras)

mixed_questions = [
    q(1, '以下哪个选项是第五个选项？Choose the fifth option.', ['Alpha 阿尔法', 'Beta 贝塔', 'Gamma 伽马', 'Delta 德尔塔', 'Epsilon 艾普西龙'], 'E'),
    q(3, 'Which letter comes after D?', ['A', 'B', 'C', 'D', 'E'], 'E'),
    q(2, '数字 5 的 English word 是什么？', ['one', 'two', 'three', 'four', 'five'], 'E'),
]

filename = '01_mixed_five_options_source_order.pdf'
c = sheet(filename, '中英文混排五选项练习 / Mixed Practice')
y = H - 88
for item in mixed_questions:
    texts = [item['number'] + '. ' + item['stem']] + [f'{chr(65+i)}. {s}' for i, s in enumerate(item['options'])]
    y = lines(c, texts, y=y, step=23)
    y -= 14
lines(c, ['参考答案 / Answer Key', '1. E    3. E    2. E'], y=y-6, step=25)
c.save()
EXPECTED.append(dict(file=filename, kind='text', questions=mixed_questions, sourceOrder=['1','3','2']))

filename = '02_question_across_pages.pdf'
c = sheet(filename, '跨页题目 / Question Across Pages')
lines(c, ['1. Read the following instruction and choose its correct ending.', '请阅读这个中英文问题，然后选择表示“五”的单词。', 'A. one', 'B. two'], y=155, step=25)
c.showPage()
lines(c, ['C. three', 'D. four', 'E. five', '', '2. Which number is equal to 2 + 3?', 'A. 1', 'B. 2', 'C. 3', 'D. 4', 'E. 5', '', 'Answer Key', '1. E    2. E'], y=H-60, step=29)
c.save()
EXPECTED.append(dict(file=filename, kind='text', questions=[q(1, 'Read the following instruction', ['one','two','three','four','five'], 'E', continuation='请阅读这个中英文问题，然后选择表示“五”的单词。'), q(2,'Which number is equal to 2 + 3?', ['1','2','3','4','5'], 'E')], sourceOrder=['1','2']))

filename = '03_answer_table.pdf'
c = sheet(filename, '表格答案练习 / Answer Table')
items = [q(1,'Choose the fifth Greek name.', ['Alpha','Beta','Gamma','Delta','Epsilon'], 'E'), q(2,'选出数字“五”。', ['一','二','三','四','五'], 'E')]
y = H-90
for item in items:
    y = lines(c, [item['number']+'. '+item['stem']] + [f'{chr(65+i)}. {t}' for i,t in enumerate(item['options'])], y=y, step=25) - 16
lines(c,['参考答案 / Answer Key'], y=y-2)
top = y-28
xs = [48, 178, 288, 398]
rows = [['题号 / Number','1','2'], ['答案 / Answer','E','E']]
c.setFont('FixtureCN',11)
for r, row in enumerate(rows):
    for j,text in enumerate(row):
        c.rect(xs[j],top-(r+1)*35,xs[j+1]-xs[j],35,stroke=1,fill=0)
        c.drawString(xs[j]+9,top-r*35-22,text)
c.save()
EXPECTED.append(dict(file=filename, kind='text-table', questions=items, sourceOrder=['1','2'], note='答案表按列对应题号，不得把单元格间空白解释成选项内容。'))

filename = '04_scanned_mixed_five_options.pdf'
# Real image-only PDF: PNG has rasterized Chinese/Latin content, no text layer.
dpi = 220
width,height = round(W/72*dpi),round(H/72*dpi)
im = Image.new('RGB',(width,height),'white')
draw = ImageDraw.Draw(im)
font = ImageFont.truetype('C:/Windows/Fonts/simhei.ttf',40)
titlefont = ImageFont.truetype('C:/Windows/Fonts/simhei.ttf',52)
draw.text((145,150),'扫描试卷 / Scanned Practice',font=titlefont,fill='#111827')
scan_lines = ['1. 以下哪个选项表示“五”？', 'Choose the English word for number five.', 'A. one', 'B. two', 'C. three', 'D. four', 'E. five', '', '参考答案 / Answer Key', '1. E']
for i,text in enumerate(scan_lines):
    draw.text((150,280+i*94),text,font=font,fill='black')
png = ROOT/'04_scanned_mixed_five_options.source.png'
im.save(png, dpi=(dpi,dpi))
c = canvas.Canvas(str(ROOT/filename),pagesize=A4)
c.setTitle('Scanned mixed five option question - image only')
c.drawImage(ImageReader(im),0,0,width=W,height=H)
c.save()
EXPECTED.append(dict(file=filename,kind='image-only',sourcePNG=png.name,dpi=dpi,questions=[q(1,'以下哪个选项表示“五”？',['one','two','three','four','five'],'E',continuation='Choose the English word for number five.')],sourceOrder=['1'],note='没有可选择文本；必须走 OCR 或提示需要 OCR。OCR 输出须经过核对，不等于已验证准确率。'))

filename='05_two_columns.pdf'
c=sheet(filename,'双栏试卷 / Two Columns')
columns=[q(1,'Choose the fifth letter.', ['A','B','C','D','E'],'E'),q(2,'选出数字“五”。',['一','二','三','四','五'],'E')]
for item,x in zip(columns,[48,320]):
    lines(c,[item['number']+'. '+item['stem']]+[f'{chr(65+i)}. {t}' for i,t in enumerate(item['options'])],x=x,y=H-100,step=33,size=11)
lines(c,['参考答案 / Answer Key','1. E    2. E'],y=H-355,step=28)
c.save()
EXPECTED.append(dict(file=filename,kind='two-column',questions=columns,sourceOrder=['1','2'],note='检测双栏并提示阅读顺序核对；不得把左右栏同一水平位置强行拼成一道题。'))

doc=Document()
normal=doc.styles['Normal']; normal.font.name='Arial'; normal.font.size=Pt(11)
doc.add_heading('中英文五选项回归练习',0)
for item in mixed_questions:
    doc.add_paragraph(item['number']+'. '+item['stem'])
    for i,text in enumerate(item['options']):
        doc.add_paragraph(f'{chr(65+i)}. {text}')
doc.add_heading('参考答案 / Answer Key',1)
doc.add_paragraph('1. E    3. E    2. E')
doc.save(ROOT/'06_mixed_five_options.docx')
EXPECTED.append(dict(file='06_mixed_five_options.docx',kind='docx',questions=mixed_questions,sourceOrder=['1','3','2']))

extracted = {}
for p in ROOT.glob('*.pdf'):
    reader=PdfReader(p)
    texts=[page.extract_text() or '' for page in reader.pages]
    extracted[p.name] = dict(pages=len(reader.pages),characters=sum(map(len,texts)),text='\n--- PAGE ---\n'.join(texts))
    if '04_scanned' in p.name:
        assert all(not text.strip() for text in texts), 'Scanned fixture accidentally has text layer'
    else:
        assert sum(map(len,texts))>40, 'Text fixture missing extractable text'
(ROOT/'expected-all.json').write_text(json.dumps(EXPECTED,ensure_ascii=False,indent=2),encoding='utf-8')
(ROOT/'text-extraction-check.json').write_text(json.dumps(extracted,ensure_ascii=False,indent=2),encoding='utf-8')
print('Created 5 PDF fixtures, one DOCX fixture, source PNG, and expectations.')
