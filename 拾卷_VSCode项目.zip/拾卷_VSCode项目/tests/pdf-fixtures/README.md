# PDF 与五选项回归样例

本目录为合成测试素材，用于检查导入、题目拆分、五个选项和答案 E 的对应关系。它不是用户真实试卷数据集，也不能用于声称实际识别准确率。

| 文件 | 内容 | 预期 |
| --- | --- | --- |
| `01_mixed_five_options_source_order.pdf` | 中文、英文和同题混排，3 题 | 卡片原序为 1、3、2；每题完整 A-E；答案都是 E |
| `02_question_across_pages.pdf` | 第一题题干与 A/B 在第一页，C/D/E 在第二页 | 合并为同一道题，不能丢失 C-E；2 题答案都是 E。第一页大面积留白是刻意的跨页测试安排 |
| `03_answer_table.pdf` | 两题和题号/答案横向表格 | 按题号和列对应答案 E，不发生移位 |
| `04_scanned_mixed_five_options.pdf` | 真实图像页，无可选择文字，中文题干+英文续行、A-E 和答案 E | 触发 OCR；识别后需要人工核对，不能误报成文本 PDF 或空文件 |
| `04_scanned_mixed_five_options.source.png` | 扫描样例的清晰栅格源，1819 × 2572 像素、220 DPI | 可单独验证 OCR，验证 PDF 渲染和 OCR 的责任边界 |
| `05_two_columns.pdf` | 左右各一道五选项题，页下方共用答案区 | 检测/提示分栏阅读顺序，不能把左右栏同一行直接拼为一道题 |
| `06_mixed_five_options.docx` | 与 01 相同的 Word 文档 | 防止增加 PDF 支持时破坏 Word 五选项读取 |
| `07_mixed_text_and_scan.pdf` | 将 01 的文字页和 04 的扫描页合并 | 总 4 题，原序 1、3、2、1；文字页不能因存在扫描页而重复提取；重复题号及 OCR 内容全部进入待核对 |
| `08_repeated_options_at_page_edge.pdf` | 两页各一题，重复的 `A. one` 位于距顶边 42 pt 处 | 2 题各完整保留 A-E，答案 E；不能把靠近页边的重复选项误删成页眉 |
| `09_encrypted.pdf` | 具有打开密码的 PDF | 明确拒绝并提示解除密码，不自动猜测密码或绕过加密；测试打开密码是 `fixture-only` |

机器可读预期见 `expected-all.json`。其中 `stem` 有时为应包含的题干片段，`continuation` 标注应继续保留的内容。`text-extraction-check.json` 保存 pypdf 的基础提取结果，不代表应用解析测试通过。

## 生成和校验

- `generate_fixtures.py` 使用 ReportLab 生成 PDF、Pillow 生成扫描源、python-docx 生成 Word 样例。
- 文本 PDF 使用 Windows 黑体 `simhei.ttf`，由 ReportLab 嵌入使用到的 TrueType 字形子集，附文字 Unicode 映射；不分发字体源文件。扫描 PDF 只嵌入页面 PNG，不含字体或文字层。
- pypdf 检查 4 份文本 PDF 均存在可提取文本；扫描 PDF 全页可提取字符数为 0。
- 已使用 Poppler 将 5 份 PDF 的全部 6 页渲染为 PNG，并逐页目视核对：没有中文方框、溢出、重叠或被裁切的题干/选项。`*.preview-*.png` 是检查用预览，不是用户需导入的试卷。
- 测试样例内容原创、答案刻意统一为 E，用来验证第 5 个选项，不代表真实测评题目质量。

运行生成器需要 `reportlab`、`Pillow`、`python-docx`、`pypdf`，以及 `C:/Windows/Fonts/simhei.ttf`。路径可按运行电脑调整。

## 边界素材补充

`generate_edge_fixtures.py` 在现有 01/04 素材基础上生成 07-09，不会重新生成原 6 份。07 经 pypdf 检查，第一页提取 296 个文字字符、第二页 0 个字符；08 两页均保留 `A. one` 和 `E. five`；09 检查 `is_encrypted` 为真。07、08 的全部 4 页已用 Poppler 渲染并逐页目视核对，题干和选项均完整可见。08 靠近页面顶部的排版是有意构造的页眉误删回归条件。09 使用兼容性测试加密设置，不构成对加密安全性的建议。
