"""Deterministic synthetic OOXML fixtures for the paper-card importer.

Only creates files underneath this script's own test-assets directory.
Uses Python standard library so generated numbering/math/table XML is explicit.
These are parser inputs, not a collection of real exam papers.
"""
from pathlib import Path
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED
import base64
import json
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = f'xmlns:w="{W}" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"'

def run(text):
    return f'<w:r><w:t xml:space="preserve">{escape(text)}</w:t></w:r>'

def para(text='', style=None, num=False, xml=None):
    props = ''
    if style:
        props += f'<w:pStyle w:val="{style}"/>'
    if num:
        props += '<w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr>'
    return '<w:p>' + ('<w:pPr>' + props + '</w:pPr>' if props else '') + (xml if xml is not None else run(text)) + '</w:p>'

def table(rows):
    borders = ''.join(f'<w:{edge} w:val="single" w:sz="4" w:color="D9D9D9"/>' for edge in ['top','left','bottom','right','insideH','insideV'])
    props = f'<w:tblPr><w:tblW w:w="9000" w:type="dxa"/><w:tblBorders>{borders}</w:tblBorders></w:tblPr>'
    return '<w:tbl>' + props + ''.join('<w:tr>' + ''.join('<w:tc><w:tcPr><w:tcW w:w="1800" w:type="dxa"/></w:tcPr>' + para(str(cell)) + '</w:tc>' for cell in row) + '</w:tr>' for row in rows) + '</w:tbl>'

def q(number, stem, choices, answer, section='', issues=None, **kw):
    return dict(number=str(number), section=section, stem=stem,
                options=[dict(key=chr(65+i), text=t) for i,t in enumerate(choices)],
                answer=answer, issues=issues or [], **kw)

def question_xml(question, marker=None, option_marks=None, inline=False, num=False, stem_xml=None):
    prefix = '' if num else (marker if marker is not None else question['number'] + '. ')
    output = [para(prefix + question['stem'], num=num, xml=stem_xml)]
    marks = option_marks or ['A. ', 'B. ', 'C. ', 'D. ']
    choice_lines = [marks[i] + o['text'] for i,o in enumerate(question['options'])]
    output.extend([para('    '.join(choice_lines))] if inline else [para(x) for x in choice_lines])
    return output

STYLES = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="{W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="Microsoft YaHei"/><w:sz w:val="22"/><w:color w:val="000000"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="100"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:styleId="Normal" w:default="1"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="32"/><w:color w:val="000000"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:pPr><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="26"/><w:color w:val="000000"/></w:rPr></w:style></w:styles>'''
NUMBERING = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="{W}"><w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/><w:pPr><w:tabs><w:tab w:val="num" w:pos="360"/></w:tabs><w:ind w:left="360" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num></w:numbering>'''
CONTENT_TYPES = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/></Types>'''
PACKAGE_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'''
DOC_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rNumbering" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/><Relationship Id="rImage" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/sample.png"/></Relationships>'''
PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAADUlEQVQIHWP4z8AAAAMBAQDJ/pLvAAAAAElFTkSuQmCC')
DRAWING = '''<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="457200" cy="457200"/><wp:docPr id="1" name="示例色块" descr="红色方块示例图"/><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="1" name="sample.png"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="rImage"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="457200" cy="457200"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>'''
MATH = '<m:oMath><m:f><m:num><m:r><m:t>1</m:t></m:r></m:num><m:den><m:r><m:t>2</m:t></m:r></m:den></m:f></m:oMath>'

fixtures = []

def save(name, title, blocks, questions, checks, language, features, expected_status='reviewable'):
    filename = name + '.docx'
    body = para(title, style='Title') + para('自主编写的合成示例，仅用于导入与答题逻辑测试，不代表真实试卷或完整验收样本。') + ''.join(blocks)
    document = f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {NS}><w:body>{body}<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="900" w:right="1000" w:bottom="900" w:left="1000"/></w:sectPr></w:body></w:document>'
    with ZipFile(ROOT / filename, 'w', ZIP_DEFLATED) as z:
        for path, content in {'[Content_Types].xml':CONTENT_TYPES, '_rels/.rels':PACKAGE_RELS, 'word/document.xml':document, 'word/styles.xml':STYLES, 'word/numbering.xml':NUMBERING, 'word/_rels/document.xml.rels':DOC_RELS}.items():
            z.writestr(path, content.encode('utf-8'))
        z.writestr('word/media/sample.png', PNG)
    for index, question in enumerate(questions, 1):
        question['order'] = index
    fixture = dict(id=name, file=filename, synthetic=True, language=language, features=features, expectedStatus=expected_status, questionCount=len(questions), questions=questions, checks=checks)
    (ROOT / (name + '.expected.json')).write_text(json.dumps(fixture, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    fixtures.append(fixture)

cn = [q(1,'一加一等于多少？',['二','三','四','五'],['A']),q(2,'下列哪一个是水果？',['石头','苹果','桌子','铅笔'],['B']),q(3,'一个三角形有几条边？',['一条','两条','三条','四条'],['C'])]
save('01_chinese_end_answers','中文文末答案示例',sum([question_xml(x) for x in cn],[]) + [para('参考答案',style='Heading1'),para('1. A'),para('2. B'),para('3. C')],cn,['Extract exactly 3 questions, map answers by question number.'],'zh',['chinese','end-answer-section'])

en = [q(1,'Which number is even?',['3','4','5','7'],['B']),q(2,'Which word names a color?',['run','table','blue','read'],['C']),q(3,'What is 5 minus 3?',['2','3','5','8'],['A'])]
save('02_english_end_answers','English answer key example',sum([question_xml(x,inline=True) for x in en],[]) + [para('Answer Key',style='Heading1'),para('1. B'),para('2. C'),para('3. A')],en,['English stems and one-line A-D options retain original language.'],'en',['english','inline-options','end-answer-section'])

mix = [q(1,'Select 正确的 translation for 苹果。',['apple','orange','pear','banana'],['A']),q(2,'若 x = 2，what is x + 3?',['4','5','6','7'],['B']),q(3,'Choose the word 表示 红色。',['green 绿色','blue 蓝色','red 红色','white 白色'],['C'])]
blocks=[]
for x in mix:
    blocks += question_xml(x)
    blocks += [para('答案 / Answer: '+','.join(x['answer'])),para('解析 / Explanation: 本题为中英文混排的基础示例。')]
save('03_mixed_inline_answers','中英文题内混排示例',blocks,mix,['Preserve mixed-language stem and choices.','Extract inline answers and keep answer/explanation out of the stem.'],'mixed',['mixed-within-question','inline-answers','explanations'])

sec = [q(1,'1 + 0 = ?',['1','2','3','4'],['A'],'Section A'),q(2,'2 + 0 = ?',['1','2','3','4'],['B'],'Section A'),q(1,'3 + 0 = ?',['1','2','3','4'],['C'],'Section B'),q(2,'4 + 0 = ?',['1','2','3','4'],['D'],'Section B')]
blocks=[para('Section A',style='Heading1')]+sum([question_xml(x) for x in sec[:2]],[])+[para('Section B',style='Heading1')]+sum([question_xml(x) for x in sec[2:]],[])+[para('Answer Key',style='Heading1'),para('Section A',style='Heading1'),para('1. A'),para('2. B'),para('Section B',style='Heading1'),para('1. C'),para('2. D')]
save('04_section_renumbered','分节重号示例',blocks,sec,['Order must be Section A 1,2 then Section B 1,2.','Map repeated numbers using section identity; never overwrite.'],'en',['sections','repeated-numbers'])

missing=[q(1,'1 + 0 = ?',['1','2','3','4'],['A']),q(2,'2 + 0 = ?',['1','2','3','4'],None,issues=['missing-answer']),q(3,'3 + 0 = ?',['1','2','3','4'],['C']),q(4,'2 + 0 = ?',['1','2','3','4'],['B'])]
save('05_missing_answer_no_shift','缺失答案不移位示例',sum([question_xml(x) for x in missing],[])+[para('参考答案',style='Heading1'),para('1. A'),para('3. C'),para('4. B')],missing,['Question 2 remains unanswered/needs review.','Question 3 gets C and question 4 gets B; no positional shifting.'],'mixed',['missing-answer','number-based-mapping'],expected_status='needs-review')

tabh=[q(1,'Choose one.',['one','two','three','four'],['A']),q(2,'Choose two.',['one','two','three','four'],['B']),q(3,'Choose three.',['one','two','three','four'],['C'])]
save('06_horizontal_answer_table','横向答案表格示例',sum([question_xml(x) for x in tabh],[])+[para('参考答案',style='Heading1'),table([['题号','1','2','3'],['答案','A','B','C']])],tabh,['Read numbers across the first row and answers across the second row.'],'mixed',['table','horizontal-answer-table'])

tabv=[q(1,'Choose one.',['one','two','three','four'],['A']),q(2,'Choose two.',['one','two','three','four'],['B']),q(3,'Choose three.',['one','two','three','four'],['C'])]
save('07_vertical_answer_table','纵向答案表格示例',sum([question_xml(x) for x in tabv],[])+[para('Answer Key',style='Heading1'),table([['Question','Answer','Explanation'],['1','A','One is the first choice.'],['2','B','Two is the second choice.'],['3','C','Three is the third choice.']])],tabv,['Do not interpret table headers or explanations as questions.','Map by question number in each table row.'],'en',['table','vertical-answer-table','explanations'])

compact=[q(i,f'选择数字 {i}。',['1','2','3','4'],[chr(64+i)]) for i in range(1,5)]
save('08_compact_answer_keys','连写答案示例',sum([question_xml(x,inline=True) for x in compact],[])+[para('参考答案',style='Heading1'),para('1A2B3C4D')],compact,['Parse concatenated number-letter keys into four mappings.'],'zh',['compact-answers','inline-options'])

wide=[q(1,'选择数字一。',['一','二','三','四'],['A']),q(2,'Choose two.',['one','two','three','four'],['B']),q(3,'选择 three。',['1','2','3','4'],['C'])]
blocks=question_xml(wide[0],marker='１．',option_marks=['ａ．','ｂ．','ｃ．','ｄ．'])+question_xml(wide[1],marker='2）',option_marks=['a) ','b) ','c) ','d) '])+question_xml(wide[2],marker='（３）',option_marks=['Ａ、','Ｂ、','Ｃ、','Ｄ、'])+[para('参考答案',style='Heading1'),para('１．ａ  ２．b  ３．Ｃ')]
save('09_fullwidth_lowercase','全半角与小写选项示例',blocks,wide,['Normalize labels and question numbers only; preserve textual content.','Recognize fullwidth lowercase, ASCII lowercase, and fullwidth uppercase choices.'],'mixed',['fullwidth','lowercase-labels','punctuation-variants'])

reading=[q(1,'What word is printed on the blue button?',['Question','Answer','Next','Home'],['B']),q(2,'What color is the button?',['red','green','blue','yellow'],['C']),q(3,'Which button does Lee press?',['the blue button','the red button','the green button','the yellow button'],['A'])]
passage='Reading passage: A blue button has the word Answer on it. Lee reads the label "Answer" and presses the blue button. The story does not contain the answer key.'
save('10_answer_word_in_passage','阅读材料中含 Answer 示例',[para(passage)]+sum([question_xml(x) for x in reading],[])+[para('Answer Key',style='Heading1'),para('1. B'),para('2. C'),para('3. A')],reading,['The word Answer in narrative text and option B must not start the answer section.','Keep the shared reading passage available to the questions.'],'en',['reading-passage','answer-keyword-in-body'])

ordered=[q(1,'Choose one.',['one','two','three','four'],['A']),q(3,'Choose three.',['one','two','three','four'],['C']),q(2,'Choose two.',['one','two','three','four'],['B'])]
save('11_document_order_132','原文题序示例',sum([question_xml(x) for x in ordered],[])+[para('Answers',style='Heading1'),para('1. A'),para('2. B'),para('3. C')],ordered,['Card order is 1,3,2, exactly as body order.','Answer mappings remain 1:A,3:C,2:B despite ordered answer keys.'],'en',['out-of-order-numbers','document-order'])

media=[q(1,'图中的色块是什么颜色？',['红色','蓝色','绿色','黄色'],['A'],issues=['image-must-be-preserved-or-flagged'],media=['image']),q(2,'原生 Word 公式所示分数等于多少？',['0.25','0.5','1','2'],['B'],issues=['formula-must-be-preserved-or-flagged'],media=['omml-formula']),q(3,'1 + 2 = ?',['1','2','3','4'],['C'])]
blocks=question_xml(media[0],stem_xml=run('1. '+media[0]['stem'])+DRAWING)+question_xml(media[1],stem_xml=run('2. '+media[1]['stem'])+MATH)+question_xml(media[2])+[para('参考答案',style='Heading1'),para('1. A'),para('2. B'),para('3. C')]
save('12_image_and_native_formula','图片与原生公式示例',blocks,media,['Question 1 image must be visible, or a visible issue must block silent acceptance.','Question 2 fraction 1/2 must be preserved faithfully or visibly flagged.','Dropping either object with no warning is a failure.'],'mixed',['embedded-image','native-omml-formula'],expected_status='media-review')

auto=[q(1,'Which number equals one?',['1','2','3','4'],['A']),q(2,'Which number equals two?',['1','2','3','4'],['B']),q(3,'Which number equals three?',['1','2','3','4'],['C'])]
save('13_word_automatic_numbering','Word 自动编号示例',sum([question_xml(x,num=True) for x in auto],[])+[para('Answer Key',style='Heading1'),para('1. A'),para('2. B'),para('3. C')],auto,['Question numbers exist as w:numPr and numbering.xml, not plain text.','Recognize as three ordered questions or visibly request correction rather than report zero without explanation.'],'en',['word-automatic-numbering'])

pair=[q(i,f'选择数字 {i}。',['1','2','3','4'],[chr(64+i)]) for i in range(1,5)]
save('14_paired_answer_table','并排两组答案表格示例',sum([question_xml(x) for x in pair],[])+[para('参考答案',style='Heading1'),table([['题号','答案','题号','答案'],['1','A','3','C'],['2','B','4','D']])],pair,['Each row contains two independent number-answer pairs.','No row-order mapping: body order is 1,2,3,4.'],'zh',['table','paired-answer-table'])

multi=[q(1,'多选题：选择所有偶数。',['2','3','4','5'],['A','C'],type='multiple'),q(2,'Multiple choice: select all numbers greater than 2.',['1','2','3','4'],['C','D'],type='multiple'),q(3,'单选题：选择数字一。',['1','2','3','4'],['A'],type='single')]
save('15_multiple_choice','中英文多选题示例',sum([question_xml(x) for x in multi],[])+[para('参考答案',style='Heading1'),para('1. AC'),para('2. C,D'),para('3. A')],multi,['Preserve multi-answer sets, not just their first letter.','Multiple choice answers should be revealed after explicit completion/submit so first selection cannot leak the remaining choices.'],'mixed',['multiple-choice','multi-letter-answers'])

manifest = dict(schemaVersion=1, synthetic=True, purpose='Small importer regression fixtures, not a real-world accuracy benchmark.', totalFiles=len(fixtures), totalQuestions=sum(x['questionCount'] for x in fixtures), fixtures=[{k:v for k,v in f.items() if k != 'questions'} for f in fixtures])
(ROOT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'expected-all.json').write_text(json.dumps(fixtures,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
readme='''# 电子试卷合成测试素材

此目录包含 15 份自主编写的 `.docx` 小样本，共 49 题。所有题目均为示例，不是真实试卷，不可用于宣称完成项目说明要求的真实试卷准确率验收。

每份 Word 文件都有同名 `.expected.json`；`expected-all.json` 汇总完整逐题预期，`manifest.json` 是场景索引。`generate_fixtures.py` 可重复生成全部输入。

## 预期结构

- `order`：题目在正文出现的顺序，从 1 开始；不能通过题号排序替代。
- `number`：规范化后的原始题号；可能重复，需要结合 `section` 匹配。
- `section`：所属分节；无分节为空字符串。
- `stem`：题干原文；保留语言，不翻译。
- `options`：按原文顺序排列的 `{key, text}`，标签规范化为大写 ASCII。
- `answer`：正确选项数组；缺失时为 `null`，不得猜测或按位置挪用其他答案。
- `issues`：必须保留的检查要求。图片/公式保留成功时可以不产生警告；无法保留则必须显式标记。
- `checks`：该文件的关键验收断言。

自动编号文件使用原生 `w:numPr` 与 `word/numbering.xml`。图片与公式文件包含真实内嵌 PNG 和原生 OMML 分数，不能仅用纯文本模拟。

这些是用于导入解析的结构测试输入，不是用户交付的排版文档；验证应以真实导入结果和逐题断言为准。
'''
(ROOT/'README.md').write_text(readme,encoding='utf-8')

# Verify package integrity and all XML parts, without relying on optional libraries.
for fixture in fixtures:
    with ZipFile(ROOT/fixture['file']) as z:
        assert z.testzip() is None, fixture['file']
        for name in z.namelist():
            if name.endswith('.xml') or name.endswith('.rels'):
                ET.fromstring(z.read(name))
assert len(fixtures)==15
print(json.dumps(dict(files=len(fixtures),questions=manifest['totalQuestions'],path=str(ROOT)),ensure_ascii=False))
