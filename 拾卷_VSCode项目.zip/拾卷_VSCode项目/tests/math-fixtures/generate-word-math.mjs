import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import JSZip from 'jszip';
const root=path.dirname(fileURLToPath(import.meta.url));
const escape=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const run=(text,props='')=>`<m:r>${props?'<m:rPr>'+props+'</m:rPr>':''}<m:t>${escape(text)}</m:t></m:r>`;
const part=(name,content)=>`<m:${name}>${content}</m:${name}>`;
const fraction=(type,a='a',b='b')=>`<m:f><m:fPr><m:type m:val="${type}"/></m:fPr>${part('num',run(a))}${part('den',run(b))}</m:f>`;
const script=(type)=>`<m:${type}>${type==='sPre'?'':part('e',run('x'))}${type==='sSup'?'':part('sub',run('i'))}${type==='sSub'?'':part('sup',run('2'))}${type==='sPre'?part('e',run('x')):''}</m:${type}>`;
const radical=(index,hide=false)=>`<m:rad><m:radPr><m:degHide m:val="${hide?'1':'0'}"/></m:radPr>${part('deg',run(index))}${part('e',run('x+1'))}</m:rad>`;
const nary=(char,loc='undOvr',hidden=false)=>`<m:nary><m:naryPr><m:chr m:val="${char}"/><m:limLoc m:val="${loc}"/><m:supHide m:val="${hidden?'1':'0'}"/></m:naryPr>${part('sub',run('i=1'))}${part('sup',run('n'))}${part('e',script('sSub'))}</m:nary>`;
const delimiter=(begin,end,expressions)=>`<m:d><m:dPr><m:begChr m:val="${escape(begin)}"/><m:endChr m:val="${escape(end)}"/></m:dPr>${expressions.map(e=>part('e',e)).join('')}</m:d>`;
const array=`<m:eqArr>${part('e',run('x+y=2'))}${part('e',run('x−y=0'))}</m:eqArr>`;
const matrix=`<m:m><m:mPr/><m:mr>${part('e',run('1'))}${part('e',run('2'))}</m:mr><m:mr>${part('e',run('3'))}${part('e',run('4'))}</m:mr></m:m>`;
const cases=[
  {name:'bar-fraction',xml:fraction('bar'),equals:'\\frac{a}{b}'},
  {name:'linear-fraction',xml:fraction('lin'),equals:'{a}/{b}'},
  {name:'skewed-fraction',xml:fraction('skw'),includes:['{}^{a}','{}_{b}'],excludes:['\\frac']},
  {name:'no-bar-stack',xml:fraction('noBar'),equals:'\\genfrac{}{}{0pt}{}{a}{b}'},
  {name:'subscript',xml:script('sSub'),equals:'{x}_{i}'},
  {name:'superscript',xml:script('sSup'),equals:'{x}^{2}'},
  {name:'sub-and-sup',xml:script('sSubSup'),equals:'{x}_{i}^{2}'},
  {name:'prescripts',xml:script('sPre'),equals:'{}_{i}^{2}{x}'},
  {name:'cube-root',xml:radical('3'),equals:'\\sqrt[3]{x+1}'},
  {name:'square-root-hidden-degree',xml:radical('99',true),equals:'\\sqrt{x+1}'},
  {name:'integral-side-limits',xml:nary('∫','subSup'),includes:['\\int\\nolimits_{i=1}^{n}','{x}_{i}']},
  {name:'sum-over-under-limits',xml:nary('∑'),includes:['\\sum\\limits_{i=1}^{n}']},
  {name:'product',xml:nary('∏'),includes:['\\prod\\limits_{i=1}^{n}']},
  {name:'hidden-upper-limit',xml:nary('∑','undOvr',true),includes:['_{i=1}'],excludes:['^{n}']},
  {name:'limit',xml:`<m:limLow>${part('e',run('lim'))}${part('lim',run('x→0'))}</m:limLow>`,includes:['\\underset{x\\to 0}{\\lim }']},
  {name:'upper-limit',xml:`<m:limUpp>${part('e',run('max'))}${part('lim',run('n'))}</m:limUpp>`,includes:['\\overset{n}{\\max }']},
  {name:'absolute-value',xml:delimiter('|','|',[run('x−1')]),equals:'\\left|x-1\\right|'},
  {name:'system-of-equations',xml:delimiter('{','',[array]),includes:['\\left\\{','\\begin{gathered}x+y=2\\\\x-y=0\\end{gathered}','\\right.']},
  {name:'matrix',xml:delimiter('[',']',[matrix]),equals:'\\left[\\begin{matrix}1&2\\\\3&4\\end{matrix}\\right]'},
  {name:'vector',xml:`<m:acc><m:accPr><m:chr m:val="⃗"/></m:accPr>${part('e',run('v'))}</m:acc>`,equals:'\\vec{v}'},
  {name:'overline',xml:`<m:bar><m:barPr><m:pos m:val="top"/></m:barPr>${part('e',run('AB'))}</m:bar>`,equals:'\\overline{AB}'},
  {name:'underline',xml:`<m:bar><m:barPr><m:pos m:val="bot"/></m:barPr>${part('e',run('AB'))}</m:bar>`,equals:'\\underline{AB}'},
  {name:'double-dot',xml:`<m:acc><m:accPr><m:chr m:val="̈"/></m:accPr>${part('e',run('x'))}</m:acc>`,equals:'\\ddot{x}'},
  {name:'underbrace',xml:`<m:groupChr><m:groupChrPr><m:chr m:val="⏟"/><m:pos m:val="bot"/></m:groupChrPr>${part('e',run('a+b'))}</m:groupChr>`,equals:'\\underbrace{a+b}'},
  {name:'over-arc',xml:`<m:groupChr><m:groupChrPr><m:chr m:val="⏜"/><m:pos m:val="top"/></m:groupChrPr>${part('e',run('AB'))}</m:groupChr>`,equals:'\\overgroup{AB}'},
  {name:'under-arc',xml:`<m:groupChr><m:groupChrPr><m:chr m:val="⏝"/><m:pos m:val="bot"/></m:groupChrPr>${part('e',run('AB'))}</m:groupChr>`,equals:'\\undergroup{AB}'},
  {name:'sin-function',xml:`<m:func>${part('fName',run('sin'))}${part('e',run('θ'))}</m:func>`,includes:['\\sin','\\theta']},
  {name:'named-function',xml:`<m:func>${part('fName',run('rank'))}${part('e',run('A'))}</m:func>`,includes:['\\operatorname{rank}']},
  {name:'common-symbols',xml:run('α+β≤π×∞→ℝ'),includes:['\\alpha','\\beta','\\leq','\\pi','\\times','\\infty','\\to','\\mathbb{R}']},
  {name:'normal-math-text',xml:run('中文 rate 5%', '<m:nor m:val="1"/>'),equals:'\\text{中文 rate 5\\%}'},
  {name:'double-struck',xml:run('R','<m:scr m:val="double-struck"/>'),equals:'\\mathbb{R}'},
  {name:'bold-vector',xml:run('v','<m:sty m:val="b"/>'),equals:'\\boldsymbol{v}'},
  {name:'unknown-structure',xml:`<m:futureEquation>${run('x+y')}${part('e',run('z'))}</m:futureEquation>`,includes:['x+y','z'],warning:true},
  {name:'unknown-property-like-structure',xml:`<m:futurePr>${run('preserve')}</m:futurePr>`,includes:['preserve'],warning:true},
  {name:'missing-denominator',xml:`<m:f>${part('num',run('1'))}</m:f>`,includes:['缺失'],warning:true},
  {name:'literal-tex-injection',xml:run(String.raw`\href{https://bad.invalid}{click} \htmlClass{bad}{x} \gdef\evil{y} #$%&_^{}`),excludes:['\\href{','\\htmlClass{','\\gdef\\','\\evil{']},
  {name:'literal-normal-injection',xml:run(String.raw`}\href{https://bad.invalid}{bad}\text{`,'<m:nor m:val="1"/>'),excludes:['\\href{']},
];
const textRun=t=>`<w:r><w:t xml:space="preserve">${escape(t)}</w:t></w:r>`;
const math=x=>`<m:oMath>${x}</m:oMath>`;
const p=(...items)=>`<w:p>${items.join('')}</w:p>`;
const item=name=>cases.find(c=>c.name===name).xml;
async function docx(filename,paragraphs){
  const zip=new JSZip();
  zip.file('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>');
  zip.file('_rels/.rels','<?xml version="1.0"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>');
  zip.file('word/document.xml',`<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math" xmlns:o="urn:schemas-microsoft-com:office:office"><w:body>${paragraphs.join('')}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134"/></w:sectPr></w:body></w:document>`);
  await fs.writeFile(path.join(root,filename),await zip.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));
}
const body=[p(textRun('Native Word Equation Practice')),p(textRun('Reading passage: 原生 Word 公式示例 '),math(item('sub-and-sup')),textRun('；保持中文与English材料顺序。'))];
const definitions=[
  {number:'1',stem:'比较以下分式：',math:[item('bar-fraction')],options:['bar-fraction','skewed-fraction','linear-fraction','no-bar-stack',fraction('bar','1','2')]},
  {number:'3',stem:'Compare integral, sum and product: ',math:['integral-side-limits','sum-over-under-limits','product'].map(item),options:['cube-root','square-root-hidden-degree','limit','upper-limit','absolute-value']},
  {number:'2',stem:'识别上下标与前置上下标：',math:['subscript','superscript','sub-and-sup','prescripts'].map(item),options:['matrix','system-of-equations','vector','overline','underbrace']},
  {number:'4',stem:'常见函数与符号：',math:['common-symbols','sin-function','named-function'].map(item),options:['normal-math-text','double-struck','bold-vector','underline','double-dot']},
];
for(const definition of definitions){
  body.push(p(textRun(definition.number+'. '+definition.stem),...definition.math.map(x=>math(x))));
  definition.options.forEach((name,i)=>body.push(p(textRun(`${String.fromCharCode(65+i)}. `),math(name.startsWith('<')?name:item(name)))));
}
body.push(p(textRun('5. 普通 Word 上下标 x'),'<w:r><w:rPr><w:vertAlign w:val="superscript"/></w:rPr><w:t>2</w:t></w:r>',textRun(' 与 H'),'<w:r><w:rPr><w:vertAlign w:val="subscript"/></w:rPr><w:t>2</w:t></w:r>',textRun('O 的位置需保留。')));
['one','two','three','four','five'].forEach((t,i)=>body.push(p(textRun(`${String.fromCharCode(65+i)}. ${t}`))));
body.push(p(textRun('参考答案 / Answer Key')),p(textRun('1. E 3. E 2. E 4. E 5. E')));
await docx('01_native_math_five_options.docx',body);
const unsupported=[p(textRun('Unsupported equation review'))];
for(const [i,fragment] of [math(item('unknown-structure')),'<w:r><w:object><o:OLEObject ProgID="Equation.3"/></w:object></w:r>','<w:r><w:sym w:font="Symbol" w:char="F061"/></w:r>',math(item('literal-tex-injection'))].entries()){
  unsupported.push(p(textRun(`${i+1}. 核对下列原始内容：`),fragment));
  ['one','two','three','four','five'].forEach((t,j)=>unsupported.push(p(textRun(`${String.fromCharCode(65+j)}. ${t}`))));
}
unsupported.push(p(textRun('Answer Key')),p(textRun('1. E 2. E 3. E 4. E')));
await docx('02_unsupported_and_literal_text.docx',unsupported);
await fs.writeFile(path.join(root,'omml-cases.json'),JSON.stringify(cases,null,2));
console.log(`Generated 2 real OOXML documents and ${cases.length} structure/security cases.`);
