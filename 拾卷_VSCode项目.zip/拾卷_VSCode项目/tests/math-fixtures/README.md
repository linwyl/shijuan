# 原生 Word 公式回归素材

这些样例只用于验证转换和位置保留，不是实际试卷准确率数据集。

- `01_native_math_five_options.docx`：真正的 OOXML/OMML 公式结构。题序 1、3、2、4、5；每题五个选项 A-E，答案均为 E。材料、题干、选项均含公式；包含 Word 普通上下标。
- `02_unsupported_and_literal_text.docx`：未知 OMML、嵌入 Equation.3 对象、Symbol 字体编码符号，以及看起来像 TeX 命令的原文。前三题必须核对；第四题必须按字面保留，不能生成外部链接或执行原文命令。
- `omml-cases.json`：37 个结构、边界和安全用例，涵盖分式四种类型、前后上下标、根式、大型运算符及上下限、极限、括号/绝对值、矩阵、方程组、向量重音、上划线、组合括号、函数、常见符号和不完整结构。
- `generate-word-math.mjs`：可重建生成器，使用项目中的 JSZip 创建合法的 OOXML 包。所有公式写入 `m:oMath` 的结构节点，而不是仅把 TeX 字符串塞入普通 Word 文本。

在项目根目录运行：

```sh
node tests/math-fixtures/generate-word-math.mjs
node scripts/test-word-math.mjs
```

`scripts/test-word-math.mjs` 共 43 项检查；所有 37 个 OMML 用例的输出都会实际交给 KaTeX `renderToString`，开启 `throwOnError` 并关闭 `trust`。另外检查完整 DOCX 导入后的题序、五选项、答案 E、题干/选项/材料中的公式位置、未知结构、旧 fixture12 的 1/2、字体上下标、异常矩阵和递归深度。

结构依据为 Microsoft Open XML 文档的 [Fraction](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.math.fraction?view=openxml-3.0.1) 和 [Math 命名空间](https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.math?view=openxml-3.0.1)。其中 `bar` 为水平分式，`skw` 为斜分式，`lin` 为同行斜线分式，`noBar` 为无横线堆叠；四者不能统一转换为 `frac`。

这些测试验证数据结构与 KaTeX 排版解析，不替代真实 Word 界面、复杂试卷或浏览器实机的视觉验收。旧 `.doc` 的二进制嵌入公式仍需转 `.docx` 或人工核对。
