const fs = require('node:fs');
const path = require('node:path');
const { createWorker } = require('tesseract.js');

(async () => {
  const langPath=path.resolve(__dirname,'../../.test-build/ocr-math-cache');
  fs.mkdirSync(langPath,{recursive:true});
  for(const code of ['chi_sim','eng']) fs.copyFileSync(path.join(path.dirname(require.resolve(`@tesseract.js-data/${code}/package.json`)),'4.0.0_best_int',`${code}.traineddata.gz`),path.join(langPath,`${code}.traineddata.gz`));
  const worker = await createWorker('chi_sim+eng', 1, {langPath,cacheMethod:'none',gzip:true}, {preserve_interword_spaces:'1'});
  try {
    const { data } = await worker.recognize(path.join(__dirname,'01_single_column_math.page-1.png'), {rotateAuto:false}, {text:true,blocks:true});
    const lines = (data.blocks || []).flatMap(b => (b.paragraphs || []).flatMap(p => p.lines || []));
    const numbered = lines.filter(l=>/^\s*[12][.\s]/.test(l.text));
    const labels = lines.filter(l=>/^\s*[A-E][.\s]/.test(l.text));
    const summary = {confidence:data.confidence,text:data.text,lines,questionStartLines:numbered.map(l=>l.text),optionLabelLines:labels.map(l=>l.text)};
    fs.writeFileSync(path.join(__dirname,'04_scanned_math.ocr-check.json'),JSON.stringify(summary,null,2));
    console.log(JSON.stringify({confidence:data.confidence,questionStartLines:summary.questionStartLines,optionLabelLines:summary.optionLabelLines},null,2));
    if(new Set(labels.map(l=>l.text.trim()[0])).size!==5 || labels.length<5) throw new Error('Missing five option labels');
    if(!numbered.some(l=>/^\s*1[.\s]/.test(l.text))) throw new Error('Missing question 1');
  } finally { await worker.terminate(); }
})();
