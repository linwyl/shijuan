from pathlib import Path
import copy
import json
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from pypdf import PdfReader
import pypdfium2 as pdfium

ROOT = Path(__file__).resolve().parent
ROOT.mkdir(exist_ok=True)
W, H = A4
pdfmetrics.registerFont(TTFont('FixtureArial', 'C:/Windows/Fonts/arial.ttf'))

def text(c, x, y, s, size=13):
    c.setFont('FixtureArial', size)
    c.drawString(x, H-y, s)

def line(c, x1, y1, x2, y2):
    c.setLineWidth(.8)
    c.line(x1, H-y1, x2, H-y2)

def fraction(c, x, y, top='x + 1', bottom='x - 1', width=44):
    # y is the mathematical baseline; numerator, line, denominator are distinct objects.
    text(c, x+3, y-11, top, 11)
    line(c, x, y-6, x+width, y-6)
    text(c, x+3, y+7, bottom, 11)
    return x+width

def power(c, x, y, base='x', exponent='2'):
    text(c, x, y, base)
    text(c, x+8, y-8, exponent, 8)
    return x+15

def subscript(c, x, y):
    text(c, x, y, 'H')
    text(c, x+9, y+4, '2', 8)
    text(c, x+15, y, 'O')
    return x+26

def radical(c, x, y, inner='x + 4', width=54):
    # All strokes of the radical are vector paths, so text extraction alone loses it.
    line(c, x, y-4, x+4, y-7)
    line(c, x+4, y-7, x+9, y+2)
    line(c, x+9, y+2, x+15, y-15)
    line(c, x+15, y-15, x+width, y-15)
    text(c, x+19, y-1, inner, 11)
    return x+width

def formula(c, x, y, variant=0):
    x = fraction(c, x, y, str(variant+1), 'x + 1', 43)
    text(c, x+9, y, '+')
    x = power(c, x+26, y)
    text(c, x+10, y, '+')
    radical(c, x+29, y, str(variant+4), 43)

def sheet(filename, title):
    c = canvas.Canvas(str(ROOT/filename), pagesize=A4)
    c.setTitle(title)
    c.setAuthor('Synthetic math-crop regression fixture')
    text(c, 48, 39, title, 15)
    return c

def frag(page, bbox):
    return {'page': page, 'bbox': bbox}

def q(number, stem, options, answer, attach=True):
    return {'number':str(number), 'expectedAutoAttach':attach,
            'stemFragments':stem, 'optionFragments':options, 'answer':answer}

def option_boxes(baselines, page=1):
    return {chr(65+i):[frag(page,[48,y-24,548,y+14])] for i,y in enumerate(baselines)}

def expect(filename, kind, questions, answer_regions, **kwargs):
    result = {'file':filename,'kind':kind,'coordinateSystem':'PDF points, origin top-left',
              'pageSize':[W,H], 'pageNumbers':'one-based', 'questions':questions,
              'answerRegions':answer_regions, **kwargs}
    (ROOT/filename.replace('.pdf','.expected.json')).write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

expectations=[]
filename='01_single_column_math.pdf'
c=sheet(filename,'Mathematics - five options')
questions=[]
for number, stem_top, math_y, opts, answer in [
    (1,90,118,[165,207,249,291,333],'E'),
    (2,392,420,[467,509,551,593,635],'C'),
]:
    text(c,48,stem_top,f'{number}. Select the equivalent expression. Consider the formula below:')
    formula(c,68,math_y,4 if number==1 else 2)
    text(c,290,math_y,'with')
    subscript(c,326,math_y)
    text(c,365,math_y,'and')
    power(c,400,math_y)
    text(c,423,math_y,'positive.')
    for i,y in enumerate(opts):
        text(c,48,y,f'{chr(65+i)}. Choice {i+1}:')
        formula(c,137,y,i)
    questions.append(q(number,[frag(1,[48,stem_top-18,548,math_y+15])],option_boxes(opts),answer))
text(c,48,719,'Answer Key',15)
text(c,48,748,'1. E    2. C',13)
c.save()
expectations.append(expect(filename,'text',questions,[{'page':1,'top':697,'bbox':[48,697,548,764]}],
    note='All options have a true stacked fraction, raised exponent, and a vector radical; stems also have H2O with a lowered 2. Crops must stop before answerRegions.top.'))

filename='02_stem_across_pages_math.pdf'
c=sheet(filename,'Question continued on the next page')
text(c,48,650,'1. Read the situation below and choose the equivalent expression.')
text(c,48,681,'A student studies a quantity that depends on a positive variable.')
text(c,48,712,'The exact mathematical expression is printed on the next page.')
text(c,48,741,'Use all of this information when selecting one of five choices.')
c.showPage()
text(c,48,59,'Continuation: evaluate the following mathematical expression.')
formula(c,68,93,3)
text(c,290,93,'for')
power(c,316,93)
text(c,345,93,'positive.')
opts=[149,191,233,275,317]
for i,y in enumerate(opts):
    text(c,48,y,f'{chr(65+i)}. Choice {i+1}:')
    formula(c,137,y,i)
text(c,48,394,'Answer Key',15)
text(c,48,424,'1. D')
c.save()
expectations.append(expect(filename,'text',[
    q(1,[frag(1,[48,631,548,754]),frag(2,[48,40,548,111])],option_boxes(opts,2),'D')
], [{'page':2,'top':371,'bbox':[48,371,548,440]}],
    note='The first stem fragment contains only ordinary text. Both pages must remain represented because the mathematical continuation appears only on page two.'))

filename='03_ambiguous_same_line.pdf'
c=sheet(filename,'Ambiguous layout - do not attach crops')
text(c,48,88,'1. Choose the equivalent expression from five choices.')
formula(c,68,122,4)
for i,x in enumerate([48,138,228,318,408]):
    text(c,x,180,f'{chr(65+i)}.',12)
    fraction(c,x+18,180,str(i+1),'x+1',35)
text(c,479,180,'Answer: E',11)
text(c,48,290,'2. Choose the equivalent expression from the vertical choices.')
formula(c,68,324,2)
opts=[370,412,454,496,538]
for i,y in enumerate(opts):
    text(c,48,y,f'{chr(65+i)}. Choice {i+1}:')
    formula(c,137,y,i)
text(c,385,538,'Answer: C',13)
c.save()
same_line={chr(65+i):[frag(1,[x,156,x+61,194])] for i,x in enumerate([48,138,228,318,408])}
expectations.append(expect(filename,'text-ambiguous',[
    q(1,[frag(1,[48,70,548,137])],same_line,'E',False),
    q(2,[frag(1,[48,272,548,339])],option_boxes(opts),'C',False)
], [{'page':1,'top':165,'bbox':[477,165,548,189],'inlineWithQuestion':'1'},
    {'page':1,'top':521,'bbox':[382,521,548,550],'inlineWithQuestion':'2'}],
    note='Question 1 has A-E on a single line and an inline answer; question 2 has a vertical E option sharing its line with Answer: C. Neither question should automatically receive any crop.'))

# Render text fixtures first; the scan is a real raster-only copy of the first PDF.
rendered=[]
for item in expectations:
    doc=pdfium.PdfDocument(str(ROOT/item['file']))
    for page_index in range(len(doc)):
        bitmap=doc[page_index].render(scale=3)
        png=ROOT/(Path(item['file']).stem+f'.page-{page_index+1}.png')
        bitmap.to_pil().save(png)
        rendered.append(png.name)
    doc.close()
filename='04_scanned_math.pdf'
c=canvas.Canvas(str(ROOT/filename),pagesize=A4)
c.setTitle('Image-only mathematics - five options')
source=ROOT/'01_single_column_math.page-1.png'
c.drawImage(ImageReader(str(source)),0,0,width=W,height=H)
c.save()
scan=copy.deepcopy(expectations[0])
scan.update(file=filename,kind='image-only',sourcePNG=source.name,renderScale=3,
    note='Raster-only copy of the first fixture, rendered at 216 dpi. No text layer. OCR must recover question numbers 1/2 and all five labels A-E before matching crops. Formula exactness is validated visually, not by OCR text.')
(ROOT/'04_scanned_math.expected.json').write_text(json.dumps(scan,indent=2),encoding='utf-8')
expectations.append(scan)

extraction={}
for item in expectations:
    reader=PdfReader(ROOT/item['file'])
    texts=[p.extract_text() or '' for p in reader.pages]
    extraction[item['file']]={'pages':len(reader.pages),'characters':sum(map(len,texts)),'textByPage':texts}
    if item['kind']=='image-only':
        assert not any(t.strip() for t in texts)
    else:
        assert all(len(t)>100 for t in texts)
(ROOT/'expected-all.json').write_text(json.dumps(expectations,indent=2),encoding='utf-8')
(ROOT/'text-extraction-check.json').write_text(json.dumps(extraction,indent=2),encoding='utf-8')
print(json.dumps({'created':[i['file'] for i in expectations], 'rendered':rendered},indent=2))
