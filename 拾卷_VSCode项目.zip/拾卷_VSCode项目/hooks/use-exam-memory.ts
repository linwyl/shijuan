'use client';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { ExamMemory, memoryError, type PracticeSnapshot, type SavedPaper, type SavedSummary } from '@/lib/exam-memory';

export function useExamMemory(snapshot: PracticeSnapshot, source: Blob | null, onRestore: (paper: SavedPaper | null) => void) {
  const [store] = useState(() => new ExamMemory());
  const [ready, setReady] = useState(false);
  const [records, setRecords] = useState<SavedSummary[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [status, setStatus] = useState<'loading' | 'saving' | 'saved' | 'error' | 'ready'>('loading');
  const [message, setMessage] = useState('');
  const [locked, setLocked] = useState(false);
  const [retry, setRetry] = useState(0);
  const [reload, setReload] = useState(0);
  const activeId = useRef<string | null>(null);
  const latest = useRef({ snapshot, source, onRestore });
  const writeVersion = useRef(0);
  const enqueued = useRef<{id:string;snapshot:PracticeSnapshot;source:Blob|null;retry:number} | null>(null);
  useLayoutEffect(() => { latest.current = { snapshot, source, onRestore }; }, [snapshot, source, onRestore]);
  const activate = (id: string | null) => { activeId.current = id; setCurrentId(id); writeVersion.current++; };

  useEffect(() => {
    let cancelled = false;
    store.restore().then(result => {
      if (cancelled) return;
      setRecords(result.records);
      if (result.current) {
        activeId.current = result.current.id; setCurrentId(result.current.id);
        latest.current.onRestore(result.current);
      }
      setMessage(result.warning);
      setStatus(result.warning ? 'error' : result.current ? 'saved' : 'ready');
    }).catch(error => {
      if (!cancelled) { setMessage(memoryError(error)); setStatus('error'); }
    }).finally(() => { if (!cancelled) setReady(true); });
    return () => { cancelled = true; };
  }, [store, reload]);

  function remember(summary: SavedSummary) {
    setRecords(previous => [summary, ...previous.filter(record => record.id !== summary.id)].sort((a, b) => b.updatedAt - a.updatedAt));
  }

  useLayoutEffect(() => {
    if (!ready || !currentId || !snapshot.exam.filename || locked) return;
    const previous = enqueued.current;
    if (previous?.id === currentId && previous.snapshot.exam === snapshot.exam && previous.snapshot.choices === snapshot.choices && previous.snapshot.tab === snapshot.tab && previous.source === source && previous.retry === retry) return;
    enqueued.current = {id:currentId,snapshot,source,retry};
    const version = ++writeVersion.current;
    setStatus('saving'); setMessage('');
    store.save(currentId, snapshot, source).then(summary => {
      remember(summary);
      if (activeId.current === currentId && writeVersion.current === version) setStatus('saved');
    }).catch(error => {
      if (activeId.current === currentId && writeVersion.current === version) { setMessage(memoryError(error)); setStatus('error'); }
    });
  }, [store, ready, currentId, snapshot, source, retry, locked]);

  useEffect(() => {
    if (status !== 'saving' && !(status === 'error' && currentId)) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      // oxlint-disable-next-line typescript/no-deprecated -- Older supported browsers still require this fallback for unsaved writes.
      event.returnValue = '';
    };
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [status, currentId]);

  async function flushCurrent() {
    if (activeId.current) remember(await store.save(activeId.current, latest.current.snapshot, latest.current.source));
  }

  async function begin(next: PracticeSnapshot, file: Blob) {
    try {
      await flushCurrent();
      const id = store.newId();
      activate(id); latest.current.onRestore({ id, ...next, source: file });
      return true;
    } catch (error) { setMessage(memoryError(error)); setStatus('error'); return false; }
  }

  async function open(id: string) {
    if (!ready || locked || activeId.current === id) return;
    setLocked(true); writeVersion.current++;
    try {
      await flushCurrent();
      const paper = await store.load(id);
      activate(id); latest.current.onRestore(paper); setMessage(''); setStatus('saved');
    } catch (error) { setMessage(memoryError(error)); setStatus('error'); }
    finally { setLocked(false); }
  }

  async function remove(id: string) {
    if (!ready || locked) return false;
    setLocked(true); writeVersion.current++;
    try {
      await store.remove(id);
      setRecords(previous => previous.filter(record => record.id !== id));
      if (activeId.current === id) { activate(null); latest.current.onRestore(null); setStatus('ready'); }
      else if (activeId.current) { setStatus('saving'); setRetry(value => value + 1); }
      else setStatus('ready');
      setMessage(''); return true;
    } catch (error) { setMessage(memoryError(error)); setStatus('error'); return false; }
    finally { setLocked(false); }
  }

  return { ready, records, currentId, status, message, locked, begin, open, remove,
    retry: () => { if (activeId.current) setRetry(value => value + 1); else { setReady(false); setStatus('loading'); setReload(value => value + 1); } } };
}
