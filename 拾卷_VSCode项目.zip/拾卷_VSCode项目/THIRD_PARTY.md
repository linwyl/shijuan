# 第三方代码与素材

## 自动保存测试工具

fake-indexeddb 6.2.4（Apache-2.0）用于模拟IndexedDB事务，react-test-renderer 19.2.6（MIT）用于检查React恢复/保存/删除流程。二者仅为开发依赖，不包含在交付HTML的运行代码内。具体版本和完整性信息记录于pnpm-lock.yaml。

## 旧版 Word 读取器

- 项目：JSDoc / docToText，作者 Alpaq92。
- 仓库：https://github.com/Alpaq92/JSDoc
- 固定版本：`821695a884e0c0bb8592a635d9524bb3e116cd67`
- 原路径：`src/docToText.js`；本地路径：`lib/vendor/doc-to-text.cjs`。
- 使用上游内容，仅改用 `.cjs` 文件扩展名以便构建。
- 许可证：0BSD；全文保留在 `lib/vendor/JSDoc-LICENSE.txt`。

## 旧版 Word 测试素材

- 仓库：https://github.com/morungos/node-word-extractor
- 固定版本：`d971d9f69056245ae129bd2ce31436d518293854`
- `__tests__/data/test05.doc` → `tests/fixtures/legacy/english.doc`。
- `__tests__/data/test11.doc` → `tests/fixtures/legacy/mixed.doc`。
- `__tests__/data/test12.doc` → `tests/fixtures/legacy/table.doc`。
- 仅用于旧版格式兼容性检查，未使用该项目的解析代码。
- MIT 许可证全文保留在 `tests/fixtures/legacy/LICENSE-MIT.txt`。

15 份 `.docx` 题目样例为本项目合成素材，不属于真实试卷，不用于宣称识别准确率。

## 应用依赖

本轮新增以下固定版本，模型和运行资源随 HTML 内嵌，不使用 CDN 或识别服务：

- [KaTeX 0.18.7](https://github.com/KaTeX/KaTeX/tree/v0.18.7)，[MIT许可证](https://github.com/KaTeX/KaTeX/blob/v0.18.7/LICENSE)，版权归Khan Academy及其他贡献者。使用官方[`renderToString` API](https://katex.org/docs/api)，设置`output: 'mathml'`，将Word OMML转换后的LaTeX及用户编辑的公式输出为浏览器原生MathML；本地渲染，不使用CDN。[官方配置说明](https://katex.org/docs/options)列明MathML输出方式。Word结构转换及PDF原页裁图由本项目实现，KaTeX不负责OCR或识别PDF公式。完整MIT许可随构建收集的第三方声明保留。
- [PDF.js 6.3.289](https://github.com/mozilla/pdf.js/tree/v6.3.289)，Apache-2.0。内嵌 CMap、标准字体及 PDF 解码资源，通过本地 BinaryDataFactory 读取。
- [Tesseract.js 7.0.0](https://github.com/naptha/tesseract.js/releases/tag/v7.0.0) 与 tesseract.js-core 7.0.0，Apache-2.0。使用内置 WASM 的 LSTM 引擎，在单一解析 Worker 内按顺序调用固定版本的 worker-script 接口。
- `@tesseract.js-data/chi_sim` 与 `@tesseract.js-data/eng` 1.0.0，npm 包声明 MIT；使用 `4.0.0_best_int` 下的简体中文和英文模型。来源为 [naptha/tessdata](https://github.com/naptha/tessdata)。模型通过字节数组写入内存，初始化时显式传入语言名，持久缓存关闭。
- PDF/OCR 的合成样例位于 `tests/pdf-fixtures`；页面由 ReportLab 生成，测试环境用 Poppler 渲染检查。它们不是真实试卷准确率数据。

V0.6增加的Word公式与PDF公式开发素材为合成测试内容，验证结构、视觉保留、裁图边界和答案隔离，不用于宣称真实数学试卷的自动识别准确率。PDF原图片段保持原文视觉内容，不代表KaTeX或OCR模型能将任意数学图像转为语义公式。

OCR 内部接口随版本可能变化，升级后必须重跑扫描页与禁止网络访问的生产 Worker 测试。

主要使用 React、React DOM、Base UI / shadcn UI、Lucide React、JSZip、xmldom、Tailwind CSS 和 esbuild。具体版本由 `package.json` 与 `pnpm-lock.yaml` 固定。

构建脚本根据实际被打包的模块收集许可证，输出 `dist/THIRD_PARTY_NOTICES.txt`，并在单文件 HTML 中保留相同声明。未打入离线成品的开发框架依赖，按其 npm 包各自的许可证使用。
