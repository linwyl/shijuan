'use client';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import {
  BookOpen,
  FileUp,
  ArrowRight,
  Check,
  FileText,
  CircleAlert,
  Trash2,
  RotateCcw,
  X,
  ScanText,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import type { Exam, Question } from '@/lib/types';
// oxlint-disable-next-line import/default -- Vite and the offline builder provide this virtual worker module.
import ParserWorker from '@/lib/parser-worker.ts?worker&inline';
import { parseExam } from '@/lib/exam-parser';
import QuestionEditor from './question-editor';
import { Textarea } from '@/components/ui/textarea';
import {FormulaContent} from './math-text';
import {collapseMathLines} from '@/lib/math-text';
import {useExamMemory} from '@/hooks/use-exam-memory';
import type {SavedPaper} from '@/lib/exam-memory';
import {AlertDialog, AlertDialogContent, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction} from '@/components/ui/alert-dialog';

export function QuestionCard({
  question: q,
  index,
  choice,
  onChoose,
}: {
  question: Question;
  index: number;
  choice?: string;
  onChoose: (id: string, value: string) => void;
}) {
  const answered = !!choice;
  return (
    <article className="question-card" aria-labelledby={`q-${q.id}`}>
      <div className="question-top">
        <span className="question-index">
          {String(index + 1).padStart(2, '0')}
        </span>
        <span>
          {q.section || '单项选择'} <i>·</i> 原题 {q.number}
        </span>
        <span className={`question-status ${answered ? 'answered' : ''}`}>
          {answered ? '已作答' : '单选题'}
        </span>
      </div>
      {(!!q.context || !!q.contextVisuals?.length) && (
        <div className="reading-material">
          <span>阅读材料 / PASSAGE</span>
          <p><FormulaContent text={q.context} visuals={q.contextVisuals}/></p>
          {q.contextImages?.map((img, i) => (
            <img
              className="question-image"
              src={img.src}
              alt={img.alt || '阅读材料图片'}
              key={i}
            />
          ))}
        </div>
      )}
      <h2 id={`q-${q.id}`} className="question-stem">
        <FormulaContent text={q.stem} visuals={q.stemVisuals}/>
      </h2>
      {q.images.map((img, i) => (
        <img
          className="question-image"
          key={i}
          src={img.src}
          alt={img.alt || '原试题图片'}
        />
      ))}
      <RadioGroup
        aria-labelledby={`q-${q.id}`}
        value={choice || ''}
        onValueChange={(v) => {
          if (!answered) onChoose(q.id, String(v));
        }}
        className="options"
        disabled={answered}
      >
        {q.options.map((o) => (
          <label
            key={o.key}
            className={`option ${answered && o.key === q.answer ? 'correct' : ''} ${answered && choice === o.key && choice !== q.answer ? 'incorrect' : ''}`}
          >
            <RadioGroupItem value={o.key} className="option-radio" />
            <span className="option-letter">{o.label}</span>
            <span className="option-text"><FormulaContent text={o.text} visuals={o.visuals}/></span>
            {answered && o.key === q.answer && (
              <Check size={19} className="option-check" />
            )}
          </label>
        ))}
      </RadioGroup>
      {answered && (
        <div
          className={`answer-feedback ${choice === q.answer ? 'is-correct' : 'is-incorrect'}`}
          role="status"
        >
          <div className="answer-symbol">
            {choice === q.answer ? <Check size={18} /> : <X size={18} />}
          </div>
          <div>
            <strong>{choice === q.answer ? '回答正确' : '再记住这道题'}</strong>
            <p>
              你的选择 <b>{choice}</b>
              <span>
                参考答案 <b>{q.answer}</b>
              </span>
            </p>
          </div>
        </div>
      )}
    </article>
  );
}
function createEmptyExam():Exam{return{title:'',filename:'',questions:[],warnings:[],sourceText:''};}
export default function ExamApp() {
  const [exam, setExam] = useState<Exam>(createEmptyExam);
  const [choices, setChoices] = useState<Record<string, string>>({});
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [busyStatus,setBusyStatus]=useState('正在整理试卷…');
  const [drag, setDrag] = useState(false);
  const [tab, setTab] = useState('practice');
  const [sourceOpen, setSourceOpen] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const [editing, setEditing] = useState<Question | null>(null);
  const [rawOpen, setRawOpen] = useState(false);
  const [raw, setRaw] = useState('');
  const [fileUrl, setFileUrl] = useState('');
  const [sourceFile, setSourceFile] = useState<Blob | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{id:string;filename:string} | null>(null);
  function restorePaper(paper: SavedPaper | null) {
    setExam(paper?.exam || createEmptyExam());
    setChoices(paper?.choices || {});
    setTab(paper?.tab || 'practice');
    setSourceFile(paper?.source || null);
    setFileUrl(paper?.source ? URL.createObjectURL(paper.source) : '');
    setError(''); setSourceOpen(false); setRawOpen(false); setRaw(''); setEditing(null);
  }
  const memory = useExamMemory({exam, choices, tab}, sourceFile, restorePaper);
  const controlsLocked = busy || !memory.ready || memory.locked;
  const activeWorker = useRef<Worker | null>(null);
  const cancelPending = useRef<(() => void) | null>(null);
  const stateRef = useRef({ exam, choices, locked: controlsLocked });
  useLayoutEffect(() => {
    stateRef.current = { exam, choices, locked: controlsLocked };
  }, [exam, choices, controlsLocked]);
  useEffect(
    () => () => {
      activeWorker.current?.terminate();
      cancelPending.current?.();
    },
    [],
  );
  useEffect(() => () => { if (fileUrl) URL.revokeObjectURL(fileUrl); }, [fileUrl]);
  const hasExam=!!exam.filename;
  const ready = exam.questions.filter((q) => !q.issues.length),
    pending = exam.questions.filter((q) => q.issues.length);
  const answeredCount = ready.filter((q) => choices[q.id]).length;
  const progress = ready.length
    ? Math.round((answeredCount / ready.length) * 100)
    : 0;
  async function importFile(file?: File) {
    if (!file || controlsLocked) return;
    setError('');
    if (!/\.(docx|doc|pdf)$/i.test(file.name)) {
      setError('请导入Word（.docx/.doc）或PDF文件。');
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      setError('文件超过20 MB，请拆分试卷或减少图片。');
      return;
    }
    setBusy(true);
    setBusyStatus('正在读取文档…');
    try {
      const bytes = await file.arrayBuffer();
      const next = await new Promise<Exam>((resolve, reject) => {
        const worker = new ParserWorker();
        activeWorker.current = worker;
        let timer:ReturnType<typeof setTimeout>;
        const done = () => {
          clearTimeout(timer);
          clearTimeout(deadline);
          worker.terminate();
          activeWorker.current = null;
          cancelPending.current = null;
        };
        const timeout=()=>{done();reject(new Error('文档处理超时，请拆成较少页数后重试；扫描PDF可先检查清晰度。'));};
        const refreshTimeout=()=>{clearTimeout(timer);timer=setTimeout(timeout,120000);};
        refreshTimeout();const deadline=setTimeout(timeout,12*60*1000);
        cancelPending.current = () => {
          done();
          reject(new Error('已取消导入，原有试卷保持不变。'));
        };
        worker.onmessage = (e) => {
          if(e.data?.type==='progress'){setBusyStatus(e.data.message);refreshTimeout();return;}
          if(!e.data?.exam&&!e.data?.error)return;
          done();
          if (e.data.error) reject(new Error(e.data.error));
          else resolve(e.data.exam);
        };
        worker.onerror = () => {
          done();
          reject(new Error('文档读取出现问题，请检查文件后重试。'));
        };
        worker.postMessage({ bytes, filename: file.name }, [bytes]);
      });
      await memory.begin({exam:next, choices:{}, tab:next.questions.some(q => !q.issues.length) ? 'practice' : 'review'}, file);
    } catch (e) {
      setError(e instanceof Error ? e.message : '导入失败，请检查文件。');
    } finally {
      setBusy(false);
      if (input.current) input.current.value = '';
    }
  }
  function choose(id: string, value: string) {
    if (controlsLocked) return;
    setChoices((old) => (old[id] ? old : { ...old, [id]: value }));
  }
  function saveQuestion(q: Question) {
    setExam((old) => ({
      ...old,
      questions: old.questions.map((item) => (item.id === q.id ? q : item)),
    }));
    setChoices((old) => {
      const next = { ...old };
      delete next[q.id];
      return next;
    });
    setEditing(null);
  }
  function reparse() {
    const next = parseExam(
      collapseMathLines(raw)
        .split(/\r?\n/)
        .map((text, i) => ({ text, source: `人工校对文本第${i + 1}行` })),
      exam.filename,
      ['本轮由人工校对文本重新识别，请检查题目数与题答对应。'],
    );
    if(exam.requiresReview)for(const question of next.questions)question.issues.push('本份PDF含OCR或不明确的版式，请对照原文核对并逐题确认。');
    setExam({ ...next,requiresReview:exam.requiresReview,sourcePages:exam.sourcePages });
    setChoices({});
    setRawOpen(false);
    setTab('review');
  }
  useEffect(() => {
    const context = (
      document as Document & {
        modelContext?: {
          registerTool: (
            tool: unknown,
            options: { signal: AbortSignal },
          ) => unknown;
        };
      }
    ).modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const tools = [
      {
        name: 'get_practice_state',
        description:
          'Read current practice questions and visible choices without revealing unanswered reference answers.',
        inputSchema: {
          type: 'object',
          properties: {},
          additionalProperties: false,
        },
        annotations: { readOnlyHint: true, untrustedContentHint: true },
        execute: () => {
          const s = stateRef.current;
          return {
            title: s.exam.title,
            questions: s.exam.questions
              .filter((q) => !q.issues.length)
              .map((q) => ({
                id: q.id,
                number: q.number,
                stem: q.stem,
                options: q.options,
                selected: s.choices[q.id] || null,
                ...(s.choices[q.id] ? { answer: q.answer } : {}),
              })),
            pending: s.exam.questions.filter((q) => q.issues.length).length,
          };
        },
      },
      {
        name: 'choose_option',
        description:
          'Answer a single-choice question and reveal its reference answer in the current card.',
        inputSchema: {
          type: 'object',
          properties: {
            questionId: { type: 'string' },
            option: { type: 'string' },
          },
          required: ['questionId', 'option'],
          additionalProperties: false,
        },
        annotations: { readOnlyHint: false, untrustedContentHint: true },
        execute: (input: unknown) => {
          if (!input || typeof input !== 'object')
            throw new Error('Invalid input');
          const value = input as { questionId: string; option: string };
          const s = stateRef.current,
            q = s.exam.questions.find((q) => q.id === value.questionId);
          if (
            s.locked || !q ||
            q.issues.length ||
            !q.options.some((o) => o.key === value.option)
          )
            throw new Error('Question or option is not available');
          if (s.choices[q.id]) throw new Error('Question already answered');
          flushSync(() =>
            setChoices((old) => ({ ...old, [q.id]: value.option })),
          );
          return { questionId: q.id, selected: value.option, answer: q.answer };
        },
      },
    ];
    for (const tool of tools) {
      try {
        Promise.resolve(
          context.registerTool(tool, { signal: lifecycle.signal }),
        ).catch(() => {});
      } catch {}
    }
    return () => lifecycle.abort();
  }, []);
  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="header-inner">
          <a className="brand" href="#workspace" aria-label="拾卷首页">
            <span className="brand-icon">
              <BookOpen size={23} />
            </span>
            <span>
              拾卷<small>PAPER CARDS</small>
            </span>
          </a>
          <span className="edition">欢迎使用</span>
        </div>
      </header>
      <main id="workspace" className="workspace">
        <aside className="import-panel">
          <div
            className={`dropzone ${drag ? 'is-dragging' : ''} ${busy ? 'is-busy' : ''}`}
            onDragOver={(e) => {
              e.preventDefault();
              setDrag(true);
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDrag(false);
              if (e.dataTransfer.files.length > 1) {
                setError('每次请导入一份试卷。');
                return;
              }
              void importFile(e.dataTransfer.files[0]);
            }}
          >
            <span className="upload-icon">
              <FileUp size={29} strokeWidth={1.6} />
            </span>
            <strong aria-live="polite">{busy ? busyStatus : '把试卷放在这里'}</strong>
            <span>或选择设备中的文件</span>
            <Button
              className="import-button"
              onClick={() => input.current?.click()}
              disabled={controlsLocked}
            >
              选择试卷文件 <ArrowRight size={16} />
            </Button>
            <small>.docx / .doc / .pdf · 最大20 MB</small>
            <input
              ref={input}
              hidden
              type="file"
              disabled={controlsLocked}
              accept=".docx,.doc,.pdf,application/pdf,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
              onChange={(e) => void importFile(e.target.files?.[0])}
              aria-label="导入Word或PDF试卷"
            />
          </div>
          {busy && (
            <Button variant="ghost" onClick={() => cancelPending.current?.()}>
              取消导入
            </Button>
          )}
          {error && (
            <div className="error-note" role="alert">
              <CircleAlert size={18} />
              <p>{error}</p>
            </div>
          )}
          <div className="import-guide">
            <p>请保证题目和答案在同一份文档中。</p>
          </div>
          <section className="saved-library" aria-label="已保存试卷">
            <h2>已保存试卷 <span>{memory.records.length}</span></h2>
            <p className={`memory-status ${memory.status === 'error' ? 'is-error' : ''}`} role="status" aria-live="polite">
              {memory.status === 'loading' ? '正在恢复记录…' : memory.status === 'saving' ? '正在自动保存…' : memory.status === 'saved' ? '已自动保存' : memory.status === 'error' ? '记录未保存或未能读取' : '导入后自动保存'}
            </p>
            {memory.message && <div className="memory-error"><p>{memory.message}</p><Button variant="outline" size="sm" disabled={controlsLocked} onClick={memory.retry}>{memory.currentId ? '重试保存' : '重试读取'}</Button></div>}
            {memory.records.length ? <ul className="saved-list">{memory.records.map(record => <li key={record.id} className={memory.currentId === record.id ? 'is-current' : ''}>
              <button className="saved-open" disabled={controlsLocked} onClick={() => void memory.open(record.id)} aria-current={memory.currentId === record.id ? 'true' : undefined}>
                <strong>{record.title || record.filename}</strong>
                <span>{record.filename}</span>
                <small>已答 {record.answeredCount}/{record.readyCount} · {new Date(record.updatedAt).toLocaleDateString('zh-CN')}</small>
              </button>
              <Button variant="ghost" size="sm" className="saved-delete" disabled={controlsLocked} aria-label={`删除保存记录：${record.filename}`} onClick={() => setDeleteTarget({id:record.id, filename:record.filename})}><Trash2 size={16}/><span>删除</span></Button>
            </li>)}</ul> : memory.ready && <p className="library-empty">还没有保存的试卷</p>}
          </section>
        </aside>
        <section className="practice-panel" aria-label="试卷答题区">
          <fieldset className="practice-content" disabled={controlsLocked}>
          <div className="exam-heading">
            <div>
              {hasExam && <div className="exam-eyebrow">
                <FileText size={15} />
                已导入的试卷
              </div>}
              {hasExam && <h2>{exam.title}</h2>}
              <p>{hasExam ? exam.filename : '支持中文、英文、中英混合'}</p>
            </div>
            {hasExam && <Button
              variant="outline"
              className="soft-button"
              onClick={() => setSourceOpen(true)}
            >
              <ScanText size={16} />
              查看原文
            </Button>}
          </div>
          {hasExam ? <>
          <div className="exam-summary">
            <div>
              <strong>{exam.questions.length}</strong>
              <span>检测题目</span>
            </div>
            <div>
              <strong>{ready.length}</strong>
              <span>可答卡片</span>
            </div>
            <button
              onClick={() => setTab('review')}
              className={pending.length ? 'has-pending' : ''}
            >
              <strong>{pending.length}</strong>
              <span>
                待核对 <ChevronRight size={13} />
              </span>
            </button>
            <div className="summary-caption">
              <span className="tiny-dot" />
              <span>按原文顺序排列</span>
            </div>
          </div>
          <Tabs
            value={tab}
            onValueChange={(v) => setTab(String(v))}
            className="exam-tabs"
          >
            <div className="tabs-row">
              <TabsList variant="line" className="tab-list">
                <TabsTrigger value="practice">练习卡片</TabsTrigger>
                <TabsTrigger value="review">
                  识别核对
                  {pending.length > 0 && (
                    <span className="count-badge">{pending.length}</span>
                  )}
                </TabsTrigger>
              </TabsList>
              <Button
                variant="ghost"
                className="reset-button"
                onClick={() => setChoices({})}
                disabled={!answeredCount}
              >
                <RotateCcw size={14} />
                重新练习
              </Button>
            </div>
            <TabsContent value="practice">
              {(pending.length > 0 || exam.warnings.length > 0) && (
                <div className="warning-note">
                  {pending.length > 0
                    ? `${pending.length}道题需要核对，已暂缓加入练习。`
                    : ''}
                  {exam.warnings.length > 0
                    ? '文档包含识别提示，请先检查核对页。'
                    : ''}
                  <Button variant="link" onClick={() => setTab('review')}>
                    查看核对
                  </Button>
                </div>
              )}
              <div className="progress-line">
                <span>
                  已完成 <b>{answeredCount}</b> / {ready.length}
                </span>
                <div
                  className="progress-track"
                  role="progressbar"
                  aria-label="答题进度"
                  aria-valuenow={answeredCount}
                  aria-valuemin={0}
                  aria-valuemax={ready.length || 1}
                >
                  <i style={{ width: `${progress}%` }} />
                </div>
                <span>{progress}%</span>
              </div>
              {ready.length ? (
                <div className="cards">
                  {ready.map((q, i) => (
                    <QuestionCard
                      question={q}
                      index={i}
                      key={q.id}
                      choice={choices[q.id]}
                      onChoose={choose}
                    />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <CircleAlert size={30} />
                  <h3>还没有可以作答的卡片</h3>
                  <p>请先在“识别核对”中检查题目和答案。</p>
                  <Button onClick={() => setTab('review')}>去核对</Button>
                </div>
              )}
              {ready.length > 0 && answeredCount === ready.length && (
                <div className="completion">
                  <Check size={22} />
                  <div>
                    <strong>本轮练习已完成</strong>
                    <p>你已核对这份试卷的全部可答题目。</p>
                  </div>
                </div>
              )}
            </TabsContent>
            <TabsContent value="review">
              <div className="review-intro">
                <h3>把不确定的地方，核对清楚。</h3>
                <p>这里可能显示参考答案；准备自测时，可以直接回到练习卡片。</p>
              </div>
              {hasExam && (
                <Button
                  variant="outline"
                  disabled={exam.questions.some(
                    (q) =>
                      q.images.length ||
                      q.contextImages?.length ||
                      q.stemVisuals?.length ||
                      q.contextVisuals?.length ||
                      q.options.some(o=>o.visuals?.length) ||
                      q.issues.some((s) => /公式|图片|图形|文本框/.test(s)),
                  )}
                  onClick={() => {
                    setRaw(exam.sourceText);
                    setRawOpen(true);
                  }}
                >
                  调整文本与题目边界
                </Button>
              )}
              {exam.warnings.map((w, i) => (
                <div className="warning-note" key={i}>
                  {w}
                </div>
              ))}
              {exam.questions.map((q) => (
                <div className="review-card" key={q.id}>
                  <span className="review-tag">
                    {q.issues.length ? '待核对' : '已关联'}
                  </span>
                  <h3>
                    {q.section} · 原题 {q.number}
                  </h3>
                  <p><FormulaContent text={q.stem} visuals={q.stemVisuals}/></p>
                  <p>参考答案：{q.answer || '缺失'}</p>
                  <div className="review-options">
                    {q.options.map((o) => (
                      <p key={o.key}>
                        {o.label}. <FormulaContent text={o.text} visuals={o.visuals}/>
                      </p>
                    ))}
                  </div>
                  <Button variant="outline" onClick={() => setEditing(q)}>
                    核对 / 修改此题
                  </Button>
                  {q.issues.map((issue, i) => (
                    <div className="issue" key={i}>
                      {issue}
                    </div>
                  ))}
                </div>
              ))}
            </TabsContent>
          </Tabs>
          <footer className="practice-footer">
            {hasExam && (
              <Button variant="link" disabled={controlsLocked || !memory.currentId} onClick={() => memory.currentId && setDeleteTarget({id:memory.currentId,filename:exam.filename})}>
                删除本卷记录
              </Button>
            )}
          </footer>
          </> : <div className="empty-state">
            <FileUp size={30}/>
            <h3>导入试卷后开始答题</h3>
            <p>选择 Word 或 PDF 文件，题目将按原文顺序显示在这里。</p>
            <Button disabled={controlsLocked} onClick={()=>input.current?.click()}>导入试卷</Button>
          </div>}
          </fieldset>
        </section>
      </main>
      <AlertDialog open={!!deleteTarget} onOpenChange={open => { if (!open && !memory.locked) setDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogTitle>删除这份保存记录？</AlertDialogTitle>
          <AlertDialogDescription>将删除“{deleteTarget?.filename}”在拾卷中的题目、修改和作答进度。电脑里的原始 Word 或 PDF 文件不受影响。</AlertDialogDescription>
          {memory.status === 'error' && memory.message && <p className="memory-error" role="alert">{memory.message}</p>}
          <AlertDialogFooter>
            <AlertDialogCancel disabled={memory.locked}>取消</AlertDialogCancel>
            <AlertDialogAction variant="destructive" disabled={memory.locked} onClick={async () => { if (deleteTarget && await memory.remove(deleteTarget.id)) setDeleteTarget(null); }}>{memory.locked ? '正在删除…' : '删除记录'}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog open={sourceOpen} onOpenChange={setSourceOpen}>
        <DialogContent className="source-dialog">
          <DialogTitle>原文内容核对</DialogTitle>
          <DialogDescription>
            这里包含参考答案，仅用于对照识别结果。内容保持原文顺序。
          </DialogDescription>
          <pre>{exam.sourceText}</pre>
          {!!exam.sourcePages?.length&&<div className="source-pages"><h3>PDF原页 · 请对照核对</h3>{exam.sourcePages.map(page=><figure key={page.page}><figcaption>PDF第{page.page}页 · 原页可能含答案</figcaption><img src={page.image.src} alt={page.image.alt}/></figure>)}</div>}
          {fileUrl && (
            <a
              className="download-link"
              href={fileUrl}
              download={exam.filename}
            >
              保存原文档，对照完整图文
            </a>
          )}
        </DialogContent>
      </Dialog>
      <Dialog
        open={!!editing}
        onOpenChange={(open) => {
          if (!open) setEditing(null);
        }}
      >
        {editing && (
          <QuestionEditor
            key={editing.id}
            question={editing}
            onSave={saveQuestion}
            sourcePages={exam.sourcePages}
          />
        )}
      </Dialog>
      <Dialog open={rawOpen} onOpenChange={setRawOpen}>
        <DialogContent className="source-dialog">
          <DialogTitle>调整识别文本</DialogTitle>
          <DialogDescription>
            用于修正题号、拆分或合并题目。每题以题号开头，选项以A.、B.等标记开头，参考答案放在“答案”或“Answer
            Key”标题下。重新识别会清除本轮作答。
          </DialogDescription>
          <Textarea
            className="raw-textarea"
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
          />
          <Button onClick={reparse}>按修正后的文本重新识别</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

