import {mathParts} from '@/lib/math-text';
import {renderFormula} from '@/lib/math-render';
import type {Picture} from '@/lib/types';
export function MathText({text}:{text:string}){
  return <>{mathParts(text).map((part,i)=>{
    if(part.latex===undefined)return <span key={i}>{part.text}</span>;
    const result=renderFormula(part.latex,part.display);
    // Only KaTeX output is inserted; trust:false forbids external resources/HTML.
    return result.html?<span key={i} className={`math-output ${part.display?'math-display':''}`} dangerouslySetInnerHTML={{__html:result.html}}/>:<code key={i} className="math-error" title={result.error}>{part.text}</code>;
  })}</>;
}
export function FormulaContent({text,visuals}:{text:string;visuals?:Picture[]}){
  return visuals?.length?<span className="formula-original">{visuals.map((image,i)=><img src={image.src} alt={image.alt||'原题公式与文字'} key={i}/>)}</span>:<MathText text={text}/>;
}
