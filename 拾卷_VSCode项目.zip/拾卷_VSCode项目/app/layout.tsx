import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: '拾卷 · Word与PDF试卷答题卡片', description: '支持Word、文字PDF和扫描PDF的中英混排识别，在本地转换为顺序答题卡片。' };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="zh-CN"><body>{children}</body></html>; }
