import ExamApp from './exam-app';
export default ExamApp;
