import { createRoot } from 'react-dom/client';
import ExamApp from './exam-app';

createRoot(document.getElementById('root')!).render(<ExamApp />);
