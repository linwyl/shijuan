'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  DialogContent,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  normalizeLabel,
  splitOptions,
  validateQuestion,
} from '@/lib/exam-parser';
import type { Question,SourcePage,Picture } from '@/lib/types';
import {FormulaContent} from './math-text';
import PdfCropper from './pdf-cropper';
export default function QuestionEditor({
  question: q,
  onSave,
  sourcePages,
}: {
  question: Question;
  onSave: (q: Question) => void;
  sourcePages?:SourcePage[];
}) {
  const [stem, setStem] = useState(q.stem),
    [context,setContext]=useState(q.context),
    [number, setNumber] = useState(q.number),
    [section, setSection] = useState(q.section),
    [options, setOptions] = useState(
      q.options.map((o) => `${o.label}. ${o.text}`).join('\n'),
    ),
    [answer, setAnswer] = useState(q.answer),
    [checked, setChecked] = useState(false),
    [error, setError] = useState('');
  const [visuals,setVisuals]=useState<Record<string,Picture[]>>(()=>Object.fromEntries([['stem',q.stemVisuals||[]],['context',q.contextVisuals||[]],...q.options.map(o=>[o.key,o.visuals||[]])]));
  const draftOptions=splitOptions(options).options;
  const targets=[{key:'stem',label:'题干'},...(context?[{key:'context',label:'阅读材料'}]:[]),...draftOptions.map(o=>({key:o.key,label:`选项 ${o.key}`}))];
  function addVisual(target:string,picture:Picture){setVisuals(v=>({...v,[target]:[...(v[target]||[]),picture]}));setChecked(false);}
  function preview(target:string,text:string,label:string){return <div className="formula-preview"><strong>{label}预览</strong><div><FormulaContent text={text} visuals={visuals[target]}/></div>{!!visuals[target]?.length&&<><p>当前使用原图展示。检查所有片段是否完整、有序，且不含答案。</p>{visuals[target].map((_,i)=><Button key={i} type="button" variant="outline" onClick={()=>{setVisuals(v=>({...v,[target]:v[target].filter((_,n)=>n!==i)}));setChecked(false);}}>移除片段 {i+1}</Button>)}<Button type="button" variant="outline" onClick={()=>{setVisuals(v=>({...v,[target]:[]}));setChecked(false);}}>改用文字 / 公式</Button></>}</div>;}
  function save() {
    const parsed = splitOptions(options);
    if (parsed.prefix) {
      setError('每个选项请以A.、B.等标签开头。');
      return;
    }
    const next: Question = {
      ...q,
      number: number.trim(),
      section: section.trim(),
      stem: stem.trim(),
      context:context.trim(),
      stemVisuals:visuals.stem,
      contextVisuals:visuals.context,
      options: parsed.options.map(o=>({...o,visuals:visuals[o.key]})),
      answer: normalizeLabel(answer)
        .toUpperCase()
        .replace(/[\s,，、]/g, ''),
      issues: [],
    };
    next.issues = validateQuestion(next);
    if (next.issues.length) {
      setError(next.issues.join(' '));
      return;
    }
    if (!checked) {
      setError('请先对照原文档确认内容完整。');
      return;
    }
    onSave(next);
  }
  return (
    <DialogContent className="editor-dialog">
      <DialogTitle>核对原题 {q.number}</DialogTitle>
      <DialogDescription>
        请对照原文档修正题干、全部选项和答案。确认后，此题会加入原位置的练习卡片。
      </DialogDescription>
      <div className="editor-scroll">
        {!!sourcePages?.length&&<PdfCropper pages={sourcePages} targets={targets} onAdd={addVisual}/>}
        <div className="editor-meta">
          <label>
            原题号
            <Input value={number} onChange={(e) => {setNumber(e.target.value);setChecked(false);}} />
          </label>
          <label>
            所属大题
            <Input
              value={section}
              onChange={(e) => {setSection(e.target.value);setChecked(false);}}
            />
          </label>
        </div>
        {q.context&&<><label>阅读材料<Textarea value={context} onChange={e=>{setContext(e.target.value);setChecked(false);}} rows={4}/></label>{preview('context',context,'阅读材料')}</>}
        <p className="formula-help">可编辑公式，例如 <code>{'\\(x^{2}\\)'}</code>、<code>{'\\(\\frac{1}{2}\\)'}</code>、<code>{'\\(\\sqrt{x}\\)'}</code>。下方预览会即时排版。</p>
        <label>
          题干
          <Textarea
            value={stem}
            rows={4}
            onChange={(e) => {setStem(e.target.value);setChecked(false);}}
          />
        </label>
        {preview('stem',stem,'题干')}
        {q.images.map((img, i) => (
          <img
            src={img.src}
            className="question-image"
            alt="原试题图片"
            key={i}
          />
        ))}
        <label>
          选项 · 每项以A.、B.等标签开头
          <Textarea
            value={options}
            rows={6}
            onChange={(e) => {setOptions(e.target.value);setChecked(false);}}
          />
        </label>
        {draftOptions.map(o=><div key={o.key}>{preview(o.key,o.text,`选项 ${o.key}`)}</div>)}
        <label>
          参考答案
          <Input
            value={answer}
            maxLength={20}
            onChange={(e) => {setAnswer(e.target.value);setChecked(false);}}
            placeholder="例如 B"
          />
        </label>
        <div className="original-fragment">
          <strong>原始位置与内容</strong>
          <pre>{q.source}</pre>
        </div>
        <label className="confirm-check">
          <Checkbox
            checked={checked}
            onCheckedChange={(v) => setChecked(v === true)}
          />
          <span>我已对照原文档，确认公式、题干、全部选项和答案完整对应；展示的原图不含参考答案或解析。</span>
        </label>
        {error && (
          <p className="issue" role="alert">
            {error}
          </p>
        )}
      </div>
      <Button onClick={save} disabled={!checked}>
        保存并加入练习
      </Button>
    </DialogContent>
  );
}

