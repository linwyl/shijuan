'use client';
import {useRef,useState,type PointerEvent} from 'react';
import {Button} from '@/components/ui/button';
import type {Picture,SourcePage} from '@/lib/types';
import {boxFromPoints,normalizeBox,pixelBox,type SelectionBox} from '@/lib/crop-geometry';
export default function PdfCropper({pages,targets,onAdd}:{pages:SourcePage[];targets:{key:string;label:string}[];onAdd:(target:string,picture:Picture)=>void}){
  const [pageIndex,setPageIndex]=useState(0),[target,setTarget]=useState('stem'),[box,setBox]=useState<SelectionBox>({x:0,y:0,width:0,height:0}),[confirmed,setConfirmed]=useState(false),[error,setError]=useState('');
  const image=useRef<HTMLImageElement>(null),start=useRef<{x:number;y:number}|null>(null);
  const page=pages[pageIndex];
  function point(event:PointerEvent<HTMLDivElement>){const b=event.currentTarget.getBoundingClientRect();return{x:(event.clientX-b.left)/b.width,y:(event.clientY-b.top)/b.height};}
  function changeBox(next:SelectionBox){setBox(normalizeBox(next));setConfirmed(false);setError('');}
  function add(){
    const img=image.current;if(!img?.complete||!img.naturalWidth)return setError('原页尚未加载，请稍后再试。');
    const rect=pixelBox(box,img.naturalWidth,img.naturalHeight);
    if(rect.width<5||rect.height<5)return setError('请框选一个完整的题干或选项区域。');
    if(!confirmed||!targets.some(t=>t.key===target))return;
    try{const canvas=document.createElement('canvas');canvas.width=rect.width;canvas.height=rect.height;const context=canvas.getContext('2d');if(!context)throw new Error();context.drawImage(img,rect.x,rect.y,rect.width,rect.height,0,0,rect.width,rect.height);onAdd(target,{src:canvas.toDataURL('image/png'),alt:`第${page.page}页 · ${targets.find(t=>t.key===target)?.label}原文（已核对）`});setConfirmed(false);setError('已添加原图，可在下方预览；跨页内容可以继续添加下一片。');}catch{setError('无法截取原页，请重新选择区域。');}
  }
  return <details className="cropper"><summary>从 PDF 原页框选题干或选项（保留公式）</summary>
    <p>拖动框选完整题干或一个完整选项。原图将代替该部分的识别文字展示；跨页内容可依次添加多个片段。</p>
    <div className="crop-controls"><label>原页<select value={pageIndex} onChange={e=>{setPageIndex(Number(e.target.value));changeBox({x:0,y:0,width:0,height:0});}}>{pages.map((p,i)=><option key={p.page} value={i}>第 {p.page} 页</option>)}</select></label><label>用于<select value={target} onChange={e=>{setTarget(e.target.value);setConfirmed(false);}}>{targets.map(t=><option key={t.key} value={t.key}>{t.label}</option>)}</select></label></div>
    <div className="crop-image" onPointerDown={e=>{if(e.button!==0)return;e.currentTarget.setPointerCapture(e.pointerId);start.current=point(e);changeBox(boxFromPoints(start.current,start.current));}} onPointerMove={e=>{if(start.current)changeBox(boxFromPoints(start.current,point(e)));}} onPointerUp={e=>{if(start.current)changeBox(boxFromPoints(start.current,point(e)));start.current=null;if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);}} onPointerCancel={()=>{start.current=null;}}>
      <img ref={image} src={page.image.src} alt={`第${page.page}页，拖动选择区域，也可使用下方数值设置`} draggable={false}/>
      <span className="crop-selection" style={{left:`${box.x*100}%`,top:`${box.y*100}%`,width:`${box.width*100}%`,height:`${box.height*100}%`}}/>
    </div>
    <div className="crop-coordinates">{([['x','左侧'],['y','顶部'],['width','宽度'],['height','高度']] as const).map(([key,label])=><label key={key}>{label}（%）<input type="number" min={0} max={100} step={.1} value={Math.round(box[key]*1000)/10} onChange={e=>changeBox({...box,[key]:Number(e.target.value)/100})}/></label>)}</div>
    <label className="crop-confirm"><input type="checkbox" checked={confirmed} onChange={e=>setConfirmed(e.target.checked)}/>选区只包含当前题干或选项，不含参考答案、解析或其他题目。</label>
    <Button type="button" variant="outline" disabled={!confirmed||box.width<=0||box.height<=0} onClick={add}>添加选区原图</Button>
    {error&&<p role="status">{error}</p>}
  </details>;
}
