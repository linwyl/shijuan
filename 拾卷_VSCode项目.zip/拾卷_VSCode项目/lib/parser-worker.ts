import { importDocument } from './import-document';
self.onmessage=async(event:MessageEvent)=>{if(!event.data?.bytes)return;try{const {bytes,filename}=event.data;const exam=await importDocument(bytes,filename,progress=>self.postMessage({type:'progress',...progress}));self.postMessage({exam});}catch(error){self.postMessage({error:error instanceof Error?error.message:'无法读取这份文档，请确认没有损坏或加密。'});}};
