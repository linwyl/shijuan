import JSZip from 'jszip';
import {
  DOMParser,
  type Node as XmlNode,
  type Element as XmlElement,
  type Document as XmlDocument,
} from '@xmldom/xmldom';
// Vendored 0BSD implementation, pinned revision documented in THIRD_PARTY.md.
import docToText from './vendor/doc-to-text.cjs';
import type { Block, Picture } from './types';
import { ommlToLatex, wordVerticalText } from './word-math';

const W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const children = (node: XmlNode): XmlElement[] =>
  Array.from(node.childNodes || []).filter(
    (n) => n.nodeType === 1,
  ) as XmlElement[];
const descendants = (
  node: XmlElement | XmlDocument,
  name: string,
): XmlElement[] => Array.from(node.getElementsByTagNameNS('*', name));
const attr = (node: XmlElement | undefined, key: string) =>
  node?.getAttributeNS(W, key) ||
  node?.getAttribute('w:' + key) ||
  node?.getAttribute(key) ||
  '';
function xml(text: string) {
  if (text.length > 12_000_000 || /<!DOCTYPE|<!ENTITY/i.test(text))
    throw new Error('Word内部结构异常或过大，无法读取。');
  return new DOMParser({
    onError: (level: string, message: string) => {
      if (level !== 'warning')
        throw new Error('Word内部XML损坏：' + message.slice(0, 100));
    },
  }).parseFromString(text, 'application/xml');
}
function textNode(node: XmlNode, issues: string[] = []): string {
  if (node.nodeType === 3) return node.nodeValue || '';
  if (node.nodeType !== 1) return '';
  const name = (node as XmlElement).localName || '';
  if (
    [
      'del',
      'instrText',
      'pPr',
      'rPr',
      'drawing',
      'pict',
      'txbxContent',
    ].includes(name)
  )
    return '';
  if (name === 'oMath' || name === 'oMathPara') {
    const math = ommlToLatex(node as XmlElement);
    issues.push(...math.issues);
    return `\\(${math.latex}\\)`;
  }
  if (name === 'object') return '[嵌入公式或对象：请对照原Word]';
  if (name === 't') return node.textContent || '';
  if (name === 'tab') return '\t';
  if (name === 'br' || name === 'cr') return '\n';
  if (name === 'sym') {
    const element = node as XmlElement;
    return `[字体符号 ${attr(element, 'font')} ${attr(element, 'char')}]`;
  }
  const content = children(node).map((n) => textNode(n, issues)).join('');
  if (name === 'r') {
    const props = children(node).find((n) => n.localName === 'rPr');
    const vertical = props && children(props).find((n) => n.localName === 'vertAlign');
    return wordVerticalText(content, attr(vertical, 'val'));
  }
  return content;
}
function roman(n: number) {
  const vals: [[number, string], ...Array<[number, string]>] = [
    [1000, 'M'],
    [900, 'CM'],
    [500, 'D'],
    [400, 'CD'],
    [100, 'C'],
    [90, 'XC'],
    [50, 'L'],
    [40, 'XL'],
    [10, 'X'],
    [9, 'IX'],
    [5, 'V'],
    [4, 'IV'],
    [1, 'I'],
  ];
  let s = '';
  for (const [v, c] of vals) {
    while (n >= v) {
      s += c;
      n -= v;
    }
  }
  return s;
}
function numbered(value: number, fmt: string) {
  if (fmt === 'lowerLetter' || fmt === 'upperLetter') {
    let s = '';
    let n = value;
    while (n > 0) {
      n--;
      s = String.fromCharCode(65 + (n % 26)) + s;
      n = Math.floor(n / 26);
    }
    return fmt === 'lowerLetter' ? s.toLowerCase() : s;
  }
  if (/Roman/.test(fmt)) {
    const s = roman(value);
    return fmt === 'lowerRoman' ? s.toLowerCase() : s;
  }
  return String(value);
}
async function readDocx(
  bytes: ArrayBuffer,
): Promise<{ blocks: Block[]; warnings: string[] }> {
  const zip = await JSZip.loadAsync(bytes);
  const entries = Object.values(zip.files);
  let total = 0;
  if (entries.length > 3500)
    throw new Error('Word包含过多内部文件，请拆分后再导入。');
  for (const entry of entries) {
    const size =
      (entry as typeof entry & { _data?: { uncompressedSize?: number } })._data
        ?.uncompressedSize || 0;
    total += size;
    if (size > 32_000_000 || total > 90_000_000)
      throw new Error('解压后的Word内容过大，请减少图片或拆分文档。');
  }
  if (!zip.file('word/document.xml') || !zip.file('[Content_Types].xml'))
    throw new Error('文件实际内容不是有效的.docx，不能通过改后缀转换格式。');
  if (zip.file('word/vbaProject.bin'))
    throw new Error('不接受包含宏的文档，请保存为不含宏的.docx。');
  const doc = xml(await zip.file('word/document.xml')!.async('string'));
  const body = descendants(doc, 'body')[0];
  if (!body) throw new Error('Word正文为空或无法读取。');
  const warnings: string[] = [];
  const rels = new Map<string, string>();
  const relFile = zip.file('word/_rels/document.xml.rels');
  if (relFile) {
    for (const r of descendants(
      xml(await relFile.async('string')),
      'Relationship',
    )) {
      if (r.getAttribute('TargetMode') !== 'External') {
        const target = r.getAttribute('Target') || '';
        const path = target.startsWith('/')
          ? target.slice(1)
          : 'word/' + target;
        const pieces: string[] = [];
        for (const part of path.split('/')) {
          if (part === '..') pieces.pop();
          else if (part !== '.') pieces.push(part);
        }
        rels.set(r.getAttribute('Id') || '', pieces.join('/'));
      }
    }
  }
  const pictureCache = new Map<string, Picture>();
  async function pictures(p: XmlElement) {
    const images: Picture[] = [];
    const issues: string[] = [];
    const refs = [...descendants(p, 'blip'), ...descendants(p, 'imagedata')];
    for (const ref of refs) {
      const id = ref.getAttribute('r:embed') || ref.getAttribute('r:id') || '';
      const target = rels.get(id);
      if (!target || !target.startsWith('word/media/')) {
        issues.push('图片来源无法读取，请对照原Word补充内容。');
        continue;
      }
      const ext = target.split('.').pop()!.toLowerCase();
      const mime: Record<string, string> = {
        png: 'image/png',
        jpg: 'image/jpeg',
        jpeg: 'image/jpeg',
        gif: 'image/gif',
        webp: 'image/webp',
      };
      if (!mime[ext]) {
        issues.push('包含暂不支持的矢量图或图形，请对照原Word核对。');
        continue;
      }
      if (!pictureCache.has(target)) {
        const f = zip.file(target);
        if (!f) {
          issues.push('图片文件缺失。');
          continue;
        }
        pictureCache.set(target, {
          src: `data:${mime[ext]};base64,${await f.async('base64')}`,
          alt: '原Word图片',
        });
      }
      images.push(pictureCache.get(target)!);
    }
    if (descendants(p, 'object').length)
      issues.push('包含MathType或其他嵌入公式/对象，需对照原Word补充其内容。');
    if (descendants(p, 'txbxContent').length)
      issues.push('包含浮动文本框，需核对其内容和题序。');
    if (descendants(p, 'sym').length)
      issues.push('包含特殊字体符号，需对照原Word确认。');
    if (
      ((descendants(p, 'drawing').length || descendants(p, 'pict').length) &&
        !refs.length) ||
      ['chart', 'prstGeom', 'custGeom', 'relIds', 'shape'].some(
        (name) => descendants(p, name).length,
      )
    )
      issues.push('包含Word原生图形、图表或其他非位图内容，请对照原Word补全。');
    return { images, issues };
  }
  const abstracts = new Map<
    string,
    Map<string, { start: number; fmt: string; label: string }>
  >();
  const nums = new Map<
    string,
    { abstract: string; starts: Map<string, number> }
  >();
  const counters = new Map<string, Map<string, number>>();
  const numbering = zip.file('word/numbering.xml');
  if (numbering) {
    const nd = xml(await numbering.async('string'));
    for (const a of descendants(nd, 'abstractNum')) {
      const levels = new Map();
      for (const l of children(a).filter((n) => n.localName === 'lvl')) {
        levels.set(attr(l, 'ilvl'), {
          start: Number(attr(descendants(l, 'start')[0], 'val') || 1),
          fmt: attr(descendants(l, 'numFmt')[0], 'val'),
          label: attr(descendants(l, 'lvlText')[0], 'val'),
        });
      }
      abstracts.set(attr(a, 'abstractNumId'), levels);
    }
    for (const n of descendants(nd, 'num')) {
      const starts = new Map<string, number>();
      for (const o of descendants(n, 'lvlOverride')) {
        const v = attr(descendants(o, 'startOverride')[0], 'val');
        if (v) starts.set(attr(o, 'ilvl'), Number(v));
      }
      nums.set(attr(n, 'numId'), {
        abstract: attr(descendants(n, 'abstractNumId')[0], 'val'),
        starts,
      });
    }
  }
  const styleNumber = new Map<string, { id: string; level: string }>();
  const sf = zip.file('word/styles.xml');
  if (sf) {
    for (const s of descendants(xml(await sf.async('string')), 'style')) {
      const np = descendants(s, 'numPr')[0];
      if (np)
        styleNumber.set(attr(s, 'styleId'), {
          id: attr(descendants(np, 'numId')[0], 'val'),
          level: attr(descendants(np, 'ilvl')[0], 'val') || '0',
        });
    }
  }
  function numberingPrefix(p: XmlElement) {
    const np = descendants(p, 'numPr')[0];
    let id = attr(descendants(np || p, 'numId')[0], 'val');
    let level = attr(descendants(np || p, 'ilvl')[0], 'val') || '0';
    if (!id) {
      const def = styleNumber.get(attr(descendants(p, 'pStyle')[0], 'val'));
      if (def) {
        id = def.id;
        level = def.level;
      }
    }
    const n = nums.get(id);
    if (!n) return '';
    const levels = abstracts.get(n.abstract);
    const def = levels?.get(level);
    if (!def || def.fmt === 'bullet') return '';
    const count = counters.get(id) || new Map<string, number>();
    const v = count.has(level)
      ? count.get(level)! + 1
      : (n.starts.get(level) ?? def.start);
    count.set(level, v);
    for (const key of count.keys())
      if (Number(key) > Number(level)) count.delete(key);
    counters.set(id, count);
    return (
      def.label.replace(/%(\d+)/g, (_, a) => {
        const l = String(Number(a) - 1),
          d = levels?.get(l);
        return numbered(count.get(l) ?? d?.start ?? 1, d?.fmt || 'decimal');
      }) + ' '
    );
  }
  const blocks: Block[] = [];
  let blockCount = 0;
  async function paragraph(p: XmlElement, source: string) {
    const media = await pictures(p);
    const mathIssues: string[] = [];
    const raw = textNode(p, mathIssues);
    const prefix = numberingPrefix(p);
    return {
      text: prefix + raw,
      source,
      heading: /heading|title/i.test(attr(descendants(p, 'pStyle')[0], 'val')),
      images: media.images,
      warnings: [...new Set([...media.issues, ...mathIssues])],
    };
  }
  async function walk(container: XmlElement) {
    for (const node of children(container)) {
      if (++blockCount > 30000)
        throw new Error('文档段落过多，请分成较小的试卷。');
      const source = `正文位置 ${blockCount}`;
      if (node.localName === 'p') {
        const b = await paragraph(node, source);
        if (b.text.trim() || b.images.length || b.warnings.length)
          blocks.push(b);
      } else if (node.localName === 'tbl') {
        for (const row of children(node).filter((n) => n.localName === 'tr')) {
          const cells: string[] = [];
          const images: Picture[] = [];
          const issues: string[] = [];
          for (const cell of children(row).filter(
            (n) => n.localName === 'tc',
          )) {
            const parts = [];
            for (const p of children(cell).filter((n) => n.localName === 'p')) {
              const b = await paragraph(p, source);
              parts.push(b.text);
              images.push(...b.images);
              issues.push(...b.warnings);
            }
            cells.push(parts.join('\n'));
            const span = Number(
              attr(descendants(cell, 'gridSpan')[0], 'val') || 1,
            );
            if (span > 1 || descendants(cell, 'vMerge').length) {
              issues.push('合并表格单元格需核对对应关系。');
              for (let i = 1; i < Math.min(span, 30); i++) cells.push('');
            }
            if (descendants(cell, 'tbl').length)
              issues.push('嵌套表格需对照原文核对。');
          }
          blocks.push({
            text: cells.join('\t'),
            source,
            cells,
            images,
            warnings: issues,
          });
        }
      } else if (
        ['sdt', 'sdtContent', 'customXml'].includes(node.localName || '')
      )
        await walk(node);
      else if (node.localName !== 'sectPr')
        warnings.push(
          `正文含未自动处理的结构：${node.localName}。请对照原Word检查。`,
        );
    }
  }
  await walk(body);
  if (!blocks.some((b) => b.text.trim()))
    throw new Error(
      '没有可读取的正文文字。扫描图片型Word需要先在Word中转换为可编辑文字。',
    );
  return { blocks, warnings: [...new Set(warnings)] };
}
function readDoc(bytes: ArrayBuffer) {
  const section = docToText.sections(new Uint8Array(bytes)) as unknown as {
    body?: string;
    textboxes?: string;
    model?: { body?: { runs?: { image?: unknown; tbxRef?: unknown }[] }[] };
  } | null;
  if (!section || !section.body)
    throw new Error(
      '无法读取此.doc。支持Word 97—2003二进制文档；加密、损坏或更早版本请在Word中另存为.docx。',
    );
  const warnings = [
    '旧版.doc的图形、公式及复杂排版需要对照原Word核对；建议另存为.docx以保留更多结构。',
  ];
  const blocks: Block[] = String(section.body)
    .split(/\r?\n/)
    .filter((t) => t.trim())
    .map((text, i) => ({
      text,
      source: `正文段落 ${i + 1}`,
      cells: text.includes('\t') ? text.split('\t') : undefined,
    }));
  const media = section.model?.body?.some((p) =>
    p.runs?.some((r) => r.image || r.tbxRef != null),
  );
  if (section.textboxes?.trim() || media) {
    warnings.push(
      '此.doc包含图形或浮动文本框，正文位置可能不完整。请转换为.docx后导入，或在核对中逐题补全。',
    );
    for (const b of blocks)
      b.warnings = ['旧版Word包含图形或文本框，需逐题核对内容完整性。'];
  }
  return { blocks, warnings };
}
export async function readWord(bytes: ArrayBuffer, filename: string) {
  if (bytes.byteLength > 20 * 1024 * 1024)
    throw new Error('文件超过20 MB，请减少图片或拆分试卷后再导入。');
  if (bytes.byteLength < 8) throw new Error('文件为空或已损坏。');
  const ext = filename.toLowerCase().split('.').pop();
  const head = new Uint8Array(bytes, 0, 8);
  if (ext === 'docx') {
    if (head[0] !== 0x50 || head[1] !== 0x4b)
      throw new Error('文件内容与.docx格式不符，请用Word另存为真正的.docx。');
    return readDocx(bytes);
  }
  if (ext === 'doc') {
    if (
      [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1].some(
        (v, i) => head[i] !== v,
      )
    )
      throw new Error(
        '这不是有效的Word二进制.doc；请用Word另存为.docx，不能只修改后缀。',
      );
    return readDoc(bytes);
  }
  throw new Error('只接受Word文档（.docx或.doc）。');
}
