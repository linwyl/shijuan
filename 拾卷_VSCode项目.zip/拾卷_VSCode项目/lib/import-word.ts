import { readWord } from './word-reader';
import { parseExam } from './exam-parser';
export async function importWord(bytes:ArrayBuffer,filename:string){const result=await readWord(bytes,filename);return parseExam(result.blocks,filename,result.warnings);}
