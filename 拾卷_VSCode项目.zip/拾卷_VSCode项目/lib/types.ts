export type Picture = { src: string; alt?: string };
export type SourcePage = {page:number;image:Picture;method:'ocr'|'review';confidence?:number};
export type Question = {
  id: string;
  number: string;
  section: string;
  stem: string;
  options: { key: string; label: string; text: string;visuals?:Picture[] }[];
  answer: string;
  issues: string[];
  images: Picture[];
  stemVisuals?: Picture[];
  context: string;
  contextImages?: Picture[];
  contextVisuals?:Picture[];
  source: string;
  kind: string;
  order: number;
};
export type Exam = {
  title: string;
  filename: string;
  questions: Question[];
  warnings: string[];
  sourceText: string;
  sourcePages?: SourcePage[];
  requiresReview?: boolean;
};
export type Block = {
  text: string;
  source: string;
  cells?: string[];
  heading?: boolean;
  images?: Picture[];
  warnings?: string[];
  page?: number;
  visuals?: Picture[];
};
