import {importWord} from './import-word';
import {readPdf} from './pdf-reader';
import {parseExam} from './exam-parser';
import type {ImportProgress} from './local-ocr';
export async function importDocument(bytes:ArrayBuffer,filename:string,onProgress?:(progress:ImportProgress)=>void){
  if(/\.pdf$/i.test(filename)){
    const result=await readPdf(bytes,onProgress);const exam=parseExam(result.blocks,filename,result.warnings);
    if(result.requiresReview)for(const question of exam.questions)question.issues.push('本份PDF包含OCR或不明确的版式，请对照原文核对本题及参考答案后确认。');
    return {...exam,sourcePages:result.sourcePages,requiresReview:result.requiresReview};
  }
  return importWord(bytes,filename);
}
