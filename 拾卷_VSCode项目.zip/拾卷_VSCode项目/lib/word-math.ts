import type { Element as XmlElement, Node as XmlNode } from '@xmldom/xmldom';

/** Convert native Word equation trees, never interpreting document text as TeX. */
export type MathConversion = { latex: string; issues: string[] };
const M = 'http://schemas.openxmlformats.org/officeDocument/2006/math';
const kids = (node: XmlNode): XmlElement[] =>
  Array.from(node.childNodes || []).filter((n) => n.nodeType === 1) as XmlElement[];
const child = (node: XmlElement, name: string) => kids(node).find((n) => n.localName === name);
const value = (node: XmlElement | undefined, name = 'val') =>
  node?.getAttributeNS(M, name) ?? node?.getAttribute('m:' + name) ?? node?.getAttribute(name) ?? '';
const truth = (node: XmlElement | undefined) => !!node && !['0', 'false', 'off'].includes(value(node));

const symbols: Record<string, string> = {
  'α':'\\alpha ', 'β':'\\beta ', 'γ':'\\gamma ', 'δ':'\\delta ', 'ε':'\\varepsilon ',
  'ϵ':'\\epsilon ', 'ζ':'\\zeta ', 'η':'\\eta ', 'θ':'\\theta ', 'ϑ':'\\vartheta ',
  'ι':'\\iota ', 'κ':'\\kappa ', 'λ':'\\lambda ', 'μ':'\\mu ', 'ν':'\\nu ',
  'ξ':'\\xi ', 'π':'\\pi ', 'ϖ':'\\varpi ', 'ρ':'\\rho ', 'ϱ':'\\varrho ',
  'σ':'\\sigma ', 'ς':'\\varsigma ', 'τ':'\\tau ', 'υ':'\\upsilon ', 'φ':'\\varphi ',
  'ϕ':'\\phi ', 'χ':'\\chi ', 'ψ':'\\psi ', 'ω':'\\omega ',
  'Γ':'\\Gamma ', 'Δ':'\\Delta ', 'Θ':'\\Theta ', 'Λ':'\\Lambda ', 'Ξ':'\\Xi ',
  'Π':'\\Pi ', 'Σ':'\\Sigma ', 'Υ':'\\Upsilon ', 'Φ':'\\Phi ', 'Ψ':'\\Psi ', 'Ω':'\\Omega ',
  '∞':'\\infty ', '≤':'\\leq ', '≥':'\\geq ', '≠':'\\neq ', '≈':'\\approx ',
  '≡':'\\equiv ', '≅':'\\cong ', '≃':'\\simeq ', '∼':'\\sim ', '∝':'\\propto ',
  '×':'\\times ', '÷':'\\div ', '±':'\\pm ', '∓':'\\mp ', '·':'\\cdot ', '⋅':'\\cdot ',
  '−':'-', '∂':'\\partial ', '∇':'\\nabla ', '∫':'\\int ', '∬':'\\iint ',
  '∭':'\\iiint ', '∮':'\\oint ', '∑':'\\sum ', '∏':'\\prod ', '∐':'\\coprod ',
  '→':'\\to ', '←':'\\leftarrow ', '↔':'\\leftrightarrow ', '⇒':'\\Rightarrow ',
  '⇐':'\\Leftarrow ', '⇔':'\\Leftrightarrow ', '↦':'\\mapsto ',
  '∈':'\\in ', '∉':'\\notin ', '∋':'\\ni ', '⊂':'\\subset ', '⊆':'\\subseteq ',
  '⊃':'\\supset ', '⊇':'\\supseteq ', '∪':'\\cup ', '∩':'\\cap ',
  '∀':'\\forall ', '∃':'\\exists ', '∄':'\\nexists ', '∅':'\\varnothing ',
  '∧':'\\land ', '∨':'\\lor ', '¬':'\\neg ', '⊥':'\\perp ', '∥':'\\parallel ',
  'ℝ':'\\mathbb{R}', 'ℤ':'\\mathbb{Z}', 'ℕ':'\\mathbb{N}', 'ℚ':'\\mathbb{Q}',
  'ℂ':'\\mathbb{C}', 'ℓ':'\\ell ', 'ℏ':'\\hbar ', '°':'{}^{\\circ}',
  '…':'\\ldots ', '⋯':'\\cdots ', '⋮':'\\vdots ', '⋱':'\\ddots ',
  '′':'\\prime ', '″':'\\prime\\prime ', '‴':'\\prime\\prime\\prime ',
  '⟨':'\\langle ', '⟩':'\\rangle ', '⌊':'\\lfloor ', '⌋':'\\rfloor ',
  '⌈':'\\lceil ', '⌉':'\\rceil ', '√':'\\surd ',
};
const functions = new Set(['sin','cos','tan','cot','sec','csc','sinh','cosh','tanh','coth',
  'arcsin','arccos','arctan','log','ln','exp','lim','liminf','limsup','min','max','sup','inf','det','gcd','Pr']);
const propertyNodes = new Set(['oMathParaPr','rPr','fPr','sSubPr','sSupPr','sSubSupPr','sPrePr',
  'radPr','naryPr','limLowPr','limUppPr','funcPr','dPr','mPr','eqArrPr','accPr','barPr',
  'groupChrPr','boxPr','borderBoxPr','ctrlPr','argPr','aln','brk']);

function escapedText(text: string) {
  return text.replace(/[\\{}%$#&_^~]/g, (c) => ({
    '\\':'\\textbackslash{}', '{':'\\{', '}':'\\}', '%':'\\%', '$':'\\$', '#':'\\#',
    '&':'\\&', '_':'\\_', '^':'\\textasciicircum{}', '~':'\\textasciitilde{}',
  })[c]!).replace(/[\r\n\t]+/g, ' ');
}

export function mathTextToLatex(text: string, normal = false): string {
  if (normal) return `\\text{${escapedText(text)}}`;
  if (functions.has(text.trim())) return '\\' + text.trim() + ' ';
  let result = '';
  for (const char of text.replace(/[\r\n\t]+/g, ' ')) {
    if (symbols[char]) result += symbols[char];
    else if (char === '\\') result += '\\backslash{}';
    else if ('{}%$#&_'.includes(char)) result += '\\' + char;
    else if (char === '^') result += '\\text{\\textasciicircum{}}';
    else if (char === '~') result += '\\text{\\textasciitilde{}}';
    else if (/\s/.test(char)) result += '\\,';
    else if (/[\u3400-\u9fff\u3000-\u303f\uff00-\uffef]/u.test(char)) result += `\\text{${escapedText(char)}}`;
    else result += char;
  }
  return result;
}

/** Word run typography is kept as a separate inline superscript/subscript. */
export function wordVerticalText(text: string, position: string): string {
  if (!text.trim() || !['superscript', 'subscript'].includes(position)) return text;
  const script = position === 'superscript' ? '^' : '_';
  const content = /^[\dA-Za-z+−=()\-\s]{1,16}$/.test(text) ? mathTextToLatex(text) : `\\text{${escapedText(text)}}`;
  return `\\({}${script}{${content}}\\)`;
}

export function ommlToLatex(element: XmlElement): MathConversion {
  const issues: string[] = [];
  let visited = 0;
  const warn = (message: string) => { if (!issues.includes(message)) issues.push(message); };
  const unsupported = (name: string) => warn(`Word公式含未完整支持的结构“${name}”，已保留可读内容，请对照原文核对。`);
  const prop = (node: XmlElement, property: string, name: string) => child(child(node, property) || node, name);
  const part = (node: XmlElement, name: string, depth: number) => {
    const target = child(node, name);
    if (!target) { warn(`Word公式缺少${name}部分，请对照原文补全。`); return '\\text{[缺失]}'; }
    return convert(target, depth + 1);
  };
  const delims: Record<string, string> = {
    '(':'(', ')':')', '[':'[', ']':']', '{':'\\{', '}':'\\}', '|':'|',
    '‖':'\\Vert', '∥':'\\Vert', '⟨':'\\langle', '⟩':'\\rangle', '<':'\\langle', '>':'\\rangle',
    '⌊':'\\lfloor', '⌋':'\\rfloor', '⌈':'\\lceil', '⌉':'\\rceil',
  };
  function delimiter(char: string) {
    if (char === '') return '.';
    if (delims[char]) return delims[char];
    unsupported('括号 ' + char);
    return '.';
  }
  function convert(node: XmlElement, depth: number): string {
    if (++visited > 12000 || depth > 90) {
      warn('Word公式结构过深或过大，已中止展开，请对照原文核对。');
      return '\\text{[公式过大]}';
    }
    const name = node.localName || node.nodeName;
    const join = () => kids(node).map((n) => convert(n, depth + 1)).join('');
    if (propertyNodes.has(name)) return '';
    if (['oMath','oMathPara','e','num','den','deg','sub','sup','lim','fName'].includes(name)) return join();
    if (name === 't') return mathTextToLatex(node.textContent || '');
    if (name === 'r') {
      const normal = truth(child(child(node, 'rPr') || node, 'nor'));
      const output = kids(node).filter((n) => n.localName !== 'rPr').map((n) => n.localName === 't' ? mathTextToLatex(n.textContent || '', normal) : convert(n, depth + 1)).join('');
      const style = value(child(child(node, 'rPr') || node, 'sty'));
      const script = value(child(child(node, 'rPr') || node, 'scr'));
      const scriptCommands: Record<string,string> = { 'double-struck':'mathbb', fraktur:'mathfrak', script:'mathcal', monospace:'mathtt', 'sans-serif':'mathsf' };
      const wrapped = scriptCommands[script] ? `\\${scriptCommands[script]}{${output}}` : output;
      return style === 'b' || style === 'bi' ? `\\boldsymbol{${wrapped}}` : style === 'p' && !normal ? `\\mathrm{${wrapped}}` : wrapped;
    }
    if (name === 'f') {
      const numerator = part(node, 'num', depth), denominator = part(node, 'den', depth);
      const type = value(prop(node, 'fPr', 'type')) || 'bar';
      if (type === 'noBar') return `\\genfrac{}{}{0pt}{}{${numerator}}{${denominator}}`;
      if (type === 'lin') return `{${numerator}}/{${denominator}}`;
      if (type === 'skw') return `{}^{${numerator}}\\! / \\!{}_{${denominator}}`;
      if (type !== 'bar') unsupported('分式类型 ' + type);
      return `\\frac{${numerator}}{${denominator}}`;
    }
    if (['sSup','sSub','sSubSup','sPre'].includes(name)) {
      const base = part(node, 'e', depth);
      const sub = name !== 'sSup' ? `_{${part(node, 'sub', depth)}}` : '';
      const sup = name !== 'sSub' ? `^{${part(node, 'sup', depth)}}` : '';
      return name === 'sPre' ? `{}${sub}${sup}{${base}}` : `{${base}}${sub}${sup}`;
    }
    if (name === 'rad') {
      const degree = child(node, 'deg');
      const index = !truth(prop(node, 'radPr', 'degHide')) && degree ? convert(degree, depth + 1) : '';
      return `\\sqrt${index ? '['+index+']' : ''}{${part(node, 'e', depth)}}`;
    }
    if (name === 'nary') {
      const char = value(prop(node, 'naryPr', 'chr')) || '∫';
      const commands: Record<string,string> = { '∫':'int','∬':'iint','∭':'iiint','∮':'oint','∑':'sum','∏':'prod','∐':'coprod','⋃':'bigcup','⋂':'bigcap','⋁':'bigvee','⋀':'bigwedge' };
      if (!commands[char]) unsupported('大型运算符 ' + char);
      const operator = commands[char] ? '\\'+commands[char] : `\\mathop{${mathTextToLatex(char)}}`;
      const loc = value(prop(node, 'naryPr', 'limLoc')) || (/^[∫∬∭∮]$/.test(char) ? 'subSup' : 'undOvr');
      const sub = child(node, 'sub'), sup = child(node, 'sup');
      return operator + (loc === 'undOvr' ? '\\limits' : '\\nolimits')
        + (!truth(prop(node, 'naryPr', 'subHide')) && sub ? `_{${convert(sub, depth+1)}}` : '')
        + (!truth(prop(node, 'naryPr', 'supHide')) && sup ? `^{${convert(sup, depth+1)}}` : '')
        + `{${part(node, 'e', depth)}}`;
    }
    if (name === 'limLow' || name === 'limUpp') return `\\${name === 'limLow' ? 'underset' : 'overset'}{${part(node, 'lim', depth)}}{${part(node, 'e', depth)}}`;
    if (name === 'func') {
      const fName = child(node, 'fName');
      if (!fName) { unsupported('缺失函数名'); return part(node, 'e', depth); }
      const text = (fName.textContent || '').trim();
      const simple = kids(fName).every((n) => n.localName === 'r');
      const operator = simple ? (functions.has(text) ? '\\'+text : `\\operatorname{${escapedText(text)}}`) : convert(fName, depth + 1);
      return operator + `\\,{${part(node, 'e', depth)}}`;
    }
    if (name === 'd') {
      const pr = child(node, 'dPr');
      const beginNode = pr && child(pr, 'begChr'), endNode = pr && child(pr, 'endChr');
      const begin = beginNode ? value(beginNode) : '(', end = endNode ? value(endNode) : ')';
      const separator = value(pr && child(pr, 'sepChr')) || '|';
      const expressions = kids(node).filter((n) => n.localName === 'e');
      if (!expressions.length) unsupported('空括号');
      return `\\left${delimiter(begin)}${expressions.map((n) => convert(n, depth+1)).join('\\middle'+delimiter(separator))}\\right${delimiter(end)}`;
    }
    if (name === 'm') {
      const rows = kids(node).filter((n) => n.localName === 'mr');
      const counts = rows.map((row) => kids(row).filter((n) => n.localName === 'e').length);
      if (!rows.length || new Set(counts).size > 1) warn('Word矩阵行列不完整，请核对原文。');
      return `\\begin{matrix}${rows.map((row) => kids(row).filter((n) => n.localName === 'e').map((n) => convert(n, depth+1)).join('&')).join('\\\\')}\\end{matrix}`;
    }
    if (name === 'eqArr') return `\\begin{gathered}${kids(node).filter((n) => n.localName === 'e').map((n) => convert(n, depth+1)).join('\\\\')}\\end{gathered}`;
    if (name === 'acc') {
      const char = value(prop(node, 'accPr', 'chr')) || '\u0302';
      const commands: Record<string,string> = { '\u0302':'hat','^':'hat','\u0303':'tilde','~':'tilde','\u0307':'dot','˙':'dot','\u0308':'ddot','¨':'ddot','\u0304':'bar','\u0305':'overline','¯':'overline','\u20d7':'vec','→':'vec','\u030c':'check','\u0306':'breve','\u0301':'acute','\u0300':'grave' };
      if (commands[char]) return `\\${commands[char]}{${part(node, 'e', depth)}}`;
      unsupported('重音符号 ' + char);
      return `\\overset{${mathTextToLatex(char)}}{${part(node, 'e', depth)}}`;
    }
    if (name === 'bar') return `\\${value(prop(node, 'barPr', 'pos')) === 'bot' ? 'underline' : 'overline'}{${part(node, 'e', depth)}}`;
    if (name === 'groupChr') {
      const char = value(prop(node, 'groupChrPr', 'chr')) || '⏟';
      const position = value(prop(node, 'groupChrPr', 'pos')) || 'bot';
      if (char === '⏟' || char === '⏞') return `\\${position === 'top' ? 'overbrace' : 'underbrace'}{${part(node, 'e', depth)}}`;
      if (char === '⏜' || char === '⏝') return `\\${position === 'top' ? 'overgroup' : 'undergroup'}{${part(node, 'e', depth)}}`;
      unsupported('组合符号 ' + char);
      return `\\${position === 'top' ? 'overset' : 'underset'}{${mathTextToLatex(char)}}{${part(node, 'e', depth)}}`;
    }
    if (name === 'box') return `{${part(node, 'e', depth)}}`;
    if (name === 'borderBox') {
      if (kids(child(node, 'borderBoxPr') || node).some((n) => /^(hide|strike)/.test(n.localName || '') && truth(n))) unsupported('带隐藏边线或删除线的边框');
      return `\\boxed{${part(node, 'e', depth)}}`;
    }
    if (name === 'sym') {
      unsupported('特殊字体编码符号');
      const font = node.getAttribute('w:font') || node.getAttribute('font') || '';
      const code = node.getAttribute('w:char') || node.getAttribute('char') || '';
      return `\\text{[字体符号 ${escapedText(font)} ${escapedText(code)}]}`;
    }
    unsupported(name);
    return join() || (node.textContent ? mathTextToLatex(node.textContent, true) : '\\text{['+escapedText(name)+']}');
  }
  const latex = convert(element, 0).replace(/[\r\n]/g, ' ');
  return { latex, issues };
}
