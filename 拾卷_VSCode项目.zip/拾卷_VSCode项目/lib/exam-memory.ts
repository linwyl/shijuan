import type { Exam } from './types';

export type PracticeSnapshot = { exam: Exam; choices: Record<string, string>; tab: string };
export type SavedSummary = {
  id: string; title: string; filename: string; createdAt: number; updatedAt: number;
  questionCount: number; readyCount: number; answeredCount: number;
};
type SavedRecord = SavedSummary & { revision: number; choices: Record<string, string>; tab: string };
type SavedContent = { id: string; exam: Exam; source: Blob | null };
export type SavedPaper = PracticeSnapshot & { id: string; source: Blob | null };
type Session = { revision: number | null; deleted?: boolean; exam?: Exam; choices?: Record<string, string>; tab?: string; summary?: SavedSummary };

export const MEMORY_DB = 'paper-cards-memory';
const stores = ['records', 'papers', 'meta'];
const summaryOf = ({ id, title, filename, createdAt, updatedAt, questionCount, readyCount, answeredCount }: SavedRecord): SavedSummary =>
  ({ id, title, filename, createdAt, updatedAt, questionCount, readyCount, answeredCount });

function checked(record: SavedRecord | undefined, content: SavedContent | undefined) {
  if (!record || !content) throw new Error('这份保存记录已被删除，请重新导入原试卷。');
  const exam = content.exam;
  if (!exam || !exam.filename || !Array.isArray(exam.questions) || !Array.isArray(exam.warnings) ||
    typeof exam.sourceText !== 'string' || !record.choices || !Number.isInteger(record.revision) ||
    exam.questions.some(q => !q.id || !Array.isArray(q.options) || !Array.isArray(q.issues) || !Array.isArray(q.images))) {
    throw new Error('这份保存记录无法读取，可删除该记录后重新导入原试卷。');
  }
  return { record, content };
}

export function memoryError(error: unknown): string {
  if (error instanceof Error && error.name === 'QuotaExceededError') return '保存空间不足。请先删除不需要的已保存试卷，再点“重试保存”。';
  if (error instanceof Error && ['SecurityError', 'InvalidStateError', 'NotSupportedError'].includes(error.name)) return '自动保存不可用。请用本地启动入口和普通浏览窗口打开，再重试；本次内容尚未保存。';
  return error instanceof Error && error.message ? error.message : '自动保存失败，本次内容仍保留在页面中，请重试。';
}

// One queue orders writes and deletion. Updates never create missing records,
// so an old page cannot bring back a record deleted in another page.
export class ExamMemory {
  private connection?: Promise<IDBDatabase>;
  private tail: Promise<unknown> = Promise.resolve();
  private sessions = new Map<string, Session>();
  constructor(private factory: () => IDBFactory = () => globalThis.indexedDB, private name = MEMORY_DB) {}

  newId() {
    const id = globalThis.crypto.randomUUID();
    this.sessions.set(id, { revision: null });
    return id;
  }

  private queue<T>(action: () => Promise<T>): Promise<T> {
    const result = this.tail.then(action);
    this.tail = result.catch(() => {});
    return result;
  }

  private open(): Promise<IDBDatabase> {
    if (this.connection) return this.connection;
    this.connection = new Promise<IDBDatabase>((resolve, reject) => {
      const factory = this.factory();
      if (!factory) { reject(new Error('当前浏览器无法自动保存。请使用本地启动入口和普通浏览窗口打开。')); return; }
      const request = factory.open(this.name, 1);
      let finished = false;
      const fail = (error: unknown) => { if (!finished) { finished = true; clearTimeout(timer); reject(error); } };
      const timer = setTimeout(() => fail(new Error('读取保存记录超时，请关闭其他拾卷页面后重试。')), 8000);
      request.onupgradeneeded = () => {
        for (const name of stores) if (!request.result.objectStoreNames.contains(name)) {
          request.result.createObjectStore(name, name === 'meta' ? undefined : { keyPath: 'id' });
        }
      };
      request.onerror = () => fail(request.error);
      request.onblocked = () => fail(new Error('保存记录被其他页面占用，请关闭其他拾卷页面后重试。'));
      request.onsuccess = () => {
        if (finished) { request.result.close(); return; }
        finished = true; clearTimeout(timer);
        const database = request.result;
        database.onversionchange = () => { database.close(); this.connection = undefined; };
        resolve(database);
      };
    }).catch(error => { this.connection = undefined; throw error; });
    return this.connection;
  }

  private async transaction<T>(mode: IDBTransactionMode, body: (tx: IDBTransaction, result: (value: T) => void, fail: (error: Error) => void) => void): Promise<T> {
    const database = await this.open();
    return new Promise<T>((resolve, reject) => {
      const tx = database.transaction(stores, mode);
      let result: T, failure: Error | null = null;
      // Request success is not enough: report success only after the commit.
      tx.oncomplete = () => resolve(result);
      tx.onabort = () => reject(failure || tx.error || new Error('保存未完成，请重试。'));
      const fail = (error: Error) => { failure = error; tx.abort(); };
      try { body(tx, value => { result = value; }, fail); }
      catch (error) { fail(error instanceof Error ? error : new Error('读取保存记录失败。')); }
    });
  }

  private accept(record: SavedRecord | undefined, content: SavedContent | undefined): SavedPaper {
    ({ record, content } = checked(record, content));
    const exam = content.exam;
    const choices: Record<string, string> = {};
    for (const q of exam.questions) if (!q.issues.length && q.options.some(o => o.key === record.choices[q.id])) choices[q.id] = record.choices[q.id];
    const tab = record.tab === 'review' ? 'review' : 'practice';
    this.sessions.set(record.id, { revision: record.revision, exam, choices, tab, summary: summaryOf(record) });
    return { id: record.id, exam, choices, tab, source: content.source instanceof Blob ? content.source : null };
  }

  restore() {
    return this.queue(async () => {
      let records: SavedRecord[] = [], record: SavedRecord | undefined, content: SavedContent | undefined;
      await this.transaction<void>('readonly', (tx, done) => {
        tx.objectStore('records').getAll().onsuccess = event => { records = (event.target as IDBRequest<SavedRecord[]>).result; };
        const request = tx.objectStore('meta').get('current');
        request.onsuccess = () => {
          if (typeof request.result === 'string') {
            tx.objectStore('records').get(request.result).onsuccess = event => { record = (event.target as IDBRequest<SavedRecord>).result; };
            tx.objectStore('papers').get(request.result).onsuccess = event => { content = (event.target as IDBRequest<SavedContent>).result; };
          }
        };
        done();
      });
      let current: SavedPaper | null = null, warning = '';
      if (record || content) try { current = this.accept(record, content); } catch (error) { warning = memoryError(error); }
      return { records: records.map(summaryOf).sort((a, b) => b.updatedAt - a.updatedAt), current, warning };
    });
  }

  load(id: string) {
    return this.queue(async () => {
      let record: SavedRecord | undefined, content: SavedContent | undefined;
      await this.transaction<void>('readwrite', (tx, done, fail) => {
        let completed = 0;
        const finish = () => {
          if (++completed !== 2) return;
          try { checked(record, content); tx.objectStore('meta').put(id, 'current'); done(); }
          catch (error) { fail(error instanceof Error ? error : new Error('读取保存记录失败。')); }
        };
        tx.objectStore('records').get(id).onsuccess = event => { record = (event.target as IDBRequest<SavedRecord>).result; finish(); };
        tx.objectStore('papers').get(id).onsuccess = event => { content = (event.target as IDBRequest<SavedContent>).result; finish(); };
      });
      return this.accept(record, content);
    });
  }

  save(id: string, snapshot: PracticeSnapshot, source: Blob | null) {
    return this.queue(async () => {
      const session = this.sessions.get(id);
      if (!session || session.deleted) throw new Error('这份记录已删除，不会重新保存。');
      const { exam, choices, tab } = snapshot;
      if (session.summary && session.exam === exam && session.choices === choices && session.tab === tab) return session.summary;
      const ready = exam.questions.filter(q => !q.issues.length);
      let written!: SavedRecord;
      await this.transaction<void>('readwrite', (tx, done, fail) => {
        const records = tx.objectStore('records'), papers = tx.objectStore('papers');
        const request = records.get(id);
        request.onsuccess = () => {
          try {
          const previous: SavedRecord | undefined = request.result;
          if (session.revision !== null && !previous) { fail(new Error('这份记录已在其他页面删除。当前内容没有重新保存。')); return; }
          if (previous && previous.revision !== session.revision) { fail(new Error('这份记录已在其他页面更新，本页修改尚未保存。请先保留需要的修改，再刷新页面读取最新记录。')); return; }
          const now = Date.now();
          written = { id, title: exam.title, filename: exam.filename, createdAt: previous?.createdAt || now, updatedAt: now,
            questionCount: exam.questions.length, readyCount: ready.length, answeredCount: ready.filter(q => choices[q.id]).length,
            revision: (previous?.revision || 0) + 1, choices, tab };
          records.put(written);
          // Large formula pictures and the original file are rewritten only
          // when the exam changes, not after each answer or tab switch.
          if (!previous || session.exam !== exam) papers.put({ id, exam, source } satisfies SavedContent);
          tx.objectStore('meta').put(id, 'current'); done();
          } catch (error) { fail(error instanceof Error ? error : new Error('自动保存失败，请重试。')); }
        };
      });
      const summary = summaryOf(written);
      Object.assign(session, { revision: written.revision, exam, choices, tab, summary });
      return summary;
    });
  }

  remove(id: string) {
    const session = this.sessions.get(id);
    if (session) session.deleted = true;
    return this.queue(async () => {
      try {
        await this.transaction<void>('readwrite', (tx, done) => {
          tx.objectStore('records').delete(id); tx.objectStore('papers').delete(id);
          const current = tx.objectStore('meta').get('current');
          current.onsuccess = () => { if (current.result === id) tx.objectStore('meta').delete('current'); };
          done();
        });
      } catch (error) { if (session) session.deleted = false; throw error; }
    });
  }

  async close() { await this.tail; (await this.connection)?.close(); this.connection = undefined; }
}
