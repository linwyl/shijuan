import type { Block, Exam, Question } from './types';
import {maskMath,collapseMathLines} from './math-text';
import {mathIssues} from './math-render';
export const normalizeLabel = (s: string) =>
  s.replace(/[０-９Ａ-Ｚａ-ｚ]/g, (c) =>
    String.fromCharCode(c.charCodeAt(0) - 0xfee0),
  );
const compact = (s: string) => normalizeLabel(s).trim();
const unique = (items: string[]) => [...new Set(items)];
function sectionKey(s: string) {
  return compact(s)
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[、：:]/g, '')
    .trim();
}
function isAnswerHeading(text: string) {
  const s = compact(text)
    .replace(/^(?:[一二三四五六七八九十]+|[IVX]+)[.、．]\s*/i, '')
    .replace(/[：:。.]$/, '')
    .trim();
  return /^(?:参考答案|标准答案|正确答案|答案(?:与解析|及解析|解析)?|answers?|answer\s*key|reference\s*answers?|solutions?)(?:\s*[/／&（(]\s*(?:参考答案|答案|answers?|answer\s*key|reference\s*answers?)[）)]?)?$/i.test(
    s,
  );
}
function isSection(text: string, heading = false) {
  const s = compact(text);
  return (
    s.length < 110 &&
    (/^(?:section|part)\s+[A-Z0-9IVX]+(?:\b|[.、:：])/i.test(s) ||
      /^(?:第[一二三四五六七八九十\d]+[部分章节]+|[一二三四五六七八九十]+[、.．])/.test(
        s,
      ) ||
      /^(?:单项选择题?|单选题?|多项选择题?|多选题?|选择题|阅读理解|single[- ]choice(?:\s+questions)?|multiple[- ]choice(?:\s+questions)?)\s*[:：]?$/i.test(
        s,
      ) ||
      (heading && /^(?:[A-Z]|[IVX]+)[.、]\s+/i.test(s)))
  );
}
function questionStart(raw: string) {
  const s = compact(raw);
  const prefix =
    /^(?:(?:第\s*(\d+(?:[.．]\d+)*)\s*题)|(?:(?:question\s*|q\s*)(\d+(?:[.．]\d+)*)(?=\s|[.．、:：)）]|$))|(?:[（(]\s*(\d+(?:[.．]\d+)*)\s*[)）])|(\d+(?:[.．]\d+)*)(?:[.．、:：)）])(?!\d))\s*[.．、:：]?\s*/i.exec(
      s,
    );
  if (!prefix) return null;
  return {
    number: (prefix[1] || prefix[2] || prefix[3] || prefix[4]).replace(
      /．/g,
      '.',
    ),
    stem: raw.trim().slice(prefix[0].length),
  };
}
export function splitOptions(raw: string) {
  const re =
    /(^|[\s\u3000])(?:[（(]([A-Ha-hＡ-Ｈａ-ｈ])[）)]|([A-Ha-hＡ-Ｈａ-ｈ])[.．、:：)）])\s*/g;
  const found = [...maskMath(raw).matchAll(re)];
  if (!found.length) return { prefix: raw, options: [] as Question['options'] };
  const options = found.map((m, i) => ({
    key: normalizeLabel(m[2] || m[3]).toUpperCase(),
    label: m[2] || m[3],
    text: raw
      .slice(m.index! + m[0].length, found[i + 1]?.index ?? raw.length)
      .trim(),
  }));
  return { prefix: raw.slice(0, found[0].index).trim(), options };
}
function answerValue(raw: string) {
  const s = compact(raw)
    .replace(/[()（）]/g, '')
    .replace(/^(?:option|选项)\s*/i, '')
    .replace(/[.。;；]$/, '')
    .trim();
  if (!/^[A-Ha-h](?:[\s,，、/&和]*[A-Ha-h]){0,7}$/.test(s)) return '';
  return unique(s.toUpperCase().match(/[A-H]/g) || []).join('');
}
function inlineAnswer(text: string) {
  const s = compact(text);
  const match =
    /^(?:(?:参考答案|标准答案|正确答案|答案|correct\s+answer|reference\s+answer|answer)\s*[/／:：\s]*)+(.+)$/i.exec(
      s,
    );
  if (!match) return null;
  const body = match[1].split(/(?:解析|说明|explanation|analysis)\s*[:：]/i)[0];
  return { value: answerValue(body), raw: body.trim() };
}
function answerPairs(text: string) {
  const s = compact(text);
  const range =
    /^(\d+)\s*[-—–~～至]\s*(\d+)\s*[:：.、]\s*([A-Ha-h\s,，、]+)$/.exec(s);
  if (range) {
    const start = Number(range[1]),
      end = Number(range[2]),
      values = range[3].replace(/[\s,，、]/g, '').toUpperCase();
    if (
      end >= start &&
      end - start + 1 === values.length &&
      values.length <= 1000
    )
      return {
        pairs: values
          .split('')
          .map((answer, i) => ({ number: String(start + i), answer })),
        range: true,
      };
    return { pairs: [], range: true };
  }
  const re =
    /(?:^|[\s;；,，]|(?<=[A-Ha-h]))(?:第\s*)?(\d+(?:\.\d+)*)(?:\s*题)?\s*[.．、:：)）]?\s*[（(]?([A-Ha-h](?:[\s,，、/&]*[A-Ha-h])*)[)）]?(?=\s|[;；,，.。]|\d|$)/g;
  const matches = [...s.matchAll(re)];
  const pairs = matches
    .map((m) => ({ number: m[1], answer: answerValue(m[2]) }))
    .filter((p) => p.answer);
  return { pairs, range: false };
}
export function validateQuestion(
  q: Question,
  retained: string[] = [],
): string[] {
  const issues = [...retained];
  if (!q.stem.trim()&&!q.stemVisuals?.length) issues.push('题干为空。');
  if (q.options.length < 2) issues.push('未完整识别至少两个选项。');
  if (q.options.some((o) => !o.text.trim()&&!o.visuals?.length)) issues.push('选项内容缺失。');
  if(!q.stemVisuals?.length)issues.push(...mathIssues(q.stem));
  if(!q.contextVisuals?.length)issues.push(...mathIssues(q.context));
  for(const option of q.options)if(!option.visuals?.length)issues.push(...mathIssues(option.text));
  if (new Set(q.options.map((o) => o.key)).size !== q.options.length)
    issues.push('选项标签重复，需要拆分或校对。');
  if (!q.answer) issues.push('缺少可确认的参考答案。');
  else if (!/^[A-H]+$/.test(q.answer))
    issues.push('参考答案无法解析为选项标签。');
  else if (q.answer.split('').some((a) => !q.options.some((o) => o.key === a)))
    issues.push('参考答案超出本题选项范围。');
  if (
    q.answer.length > 1 ||
    q.kind === 'multiple' ||
    /多选|多项选择|select\s+all|choose\s+all|all\s+that\s+apply|multiple\s+answers/i.test(
      q.stem,
    )
  )
    issues.push('这是多选题，当前版本仅支持选择后即显示答案的单选题。');
  if (
    /(?:【?答案】?|参考答案|(?:correct\s+|reference\s+)?\banswer)\s*[:：]/i.test(
      q.context + '\n' + q.stem + '\n' + q.options.map((o) => o.text).join('\n'),
    )
  )
    issues.push(
      '阅读材料、题干或选项内可能含有答案标记，请核对并移出答案内容，避免提前显示。',
    );
  return unique(issues);
}
export function parseExam(
  blocks: Block[],
  filename: string,
  inputWarnings: string[] = [],
): Exam {
  const questions: Question[] = [];
  const entries: {
    section: string;
    number: string;
    answer: string;
    source: string;
    range?: boolean;
  }[] = [];
  const warnings = [...inputWarnings];
  let mode: 'questions' | 'answers' = 'questions',
    section = '',
    answerSection = '',
    current: Question | null = null,
    context = '',
    collectContext = false,
    skipExplanation = false,
    title = '';
  let contextImages: Question['images'] = [],
    contextIssues: string[] = [];
  let contextVisuals:Question['images']=[];
  let numberRow: string[] | null = null;
  let columnPairs: { n: number; a: number }[] = [];
  function flush() {
    if (current) {
      questions.push(current);
      current = null;
    }
    skipExplanation = false;
  }
  function addAnswer(
    number: string,
    answer: string,
    source: string,
    range = false,
  ) {
    if (answer)
      entries.push({ number, answer, section: answerSection, source, range });
  }
  function answerTable(block: Block) {
    const cells = block.cells!.map((s) => compact(s));
    if (block.warnings?.length) {
      warnings.push(...block.warnings);
      return;
    }
    const numberHeader =
      /^(?:题号|序号|number|question(?:\s*(?:no\.?|number))?|q\.?|no\.?)(?:\s*[/／]\s*(?:题号|序号|number|question(?:\s*(?:no\.?|number))?|q\.?|no\.?))?$/i;
    const ansHeader = /^(?:答案|参考答案|answers?|key)(?:\s*[/／]\s*(?:答案|参考答案|answers?|key))?$/i;
    const headerPairs: { n: number; a: number }[] = [];
    for (let i = 0; i < cells.length - 1; i++)
      if (numberHeader.test(cells[i]) && ansHeader.test(cells[i + 1]))
        headerPairs.push({ n: i, a: i + 1 });
    if (headerPairs.length) {
      columnPairs = headerPairs;
      numberRow = null;
      return;
    }
    if (
      (numberHeader.test(cells[0]) &&
        cells.slice(1).some((c) => /^\d+(?:\.\d+)*$/.test(c))) ||
      (cells.length > 1 && cells.every((c) => /^\d+(?:\.\d+)*$/.test(c)))
    ) {
      numberRow = cells;
      columnPairs = [];
      return;
    }
    if (numberRow) {
      if (numberRow.length !== cells.length) {
        warnings.push('答案表格两行的单元格数量不同，未按位置猜测答案。');
        numberRow = null;
        return;
      }
      for (let i = 0; i < cells.length; i++)
        if (/^\d+(?:\.\d+)*$/.test(numberRow[i]))
          addAnswer(numberRow[i], answerValue(cells[i]), block.source);
      numberRow = null;
      return;
    }
    if (columnPairs.length) {
      for (const pair of columnPairs) {
        if (/^\d+(?:\.\d+)*$/.test(cells[pair.n] || ''))
          addAnswer(
            cells[pair.n],
            answerValue(cells[pair.a] || ''),
            block.source,
          );
      }
      return;
    }
    let handled = false;
    for (let i = 0; i < cells.length - 1; i++)
      if (
        /^\d+(?:\.\d+)*$/.test(cells[i]) &&
        (answerValue(cells[i + 1]) || cells[i + 1] === '')
      ) {
        addAnswer(cells[i], answerValue(cells[i + 1]), block.source);
        i++;
        handled = true;
      }
    if (!handled)
      for (const cell of cells) {
        for (const p of answerPairs(cell).pairs)
          addAnswer(p.number, p.answer, block.source);
      }
  }
  for (const block of blocks) {
    if (block.cells && mode === 'answers') {
      answerTable(block);
      continue;
    }
    const lines = collapseMathLines(block.cells ? block.cells.join('\n') : block.text).split(
      /\r?\n/,
    );
    let mediaAttached = false;
    const members = new Set<Question>();
    const ambiguousMedia =
      lines.filter((line) => questionStart(line)).length > 1 &&
      !!(block.images?.length || block.warnings?.length);
    const ambiguousVisuals=!!block.visuals?.length&&lines.reduce((n,line)=>n+Number(!!questionStart(line))+splitOptions(line).options.length,0)>1;
    const attachContext = () => {
      if (!mediaAttached) {
        contextImages.push(...(block.images || []));
        if(!ambiguousVisuals)contextVisuals.push(...(block.visuals||[]));
        contextIssues.push(...(block.warnings || []));
        mediaAttached = true;
      }
    };
    const attachQuestion = () => {
      if (current && !mediaAttached) {
        if (!ambiguousMedia) current.images.push(...(block.images || []));
        if(block.visuals?.length){
          if(ambiguousVisuals)current.issues.push('原图涉及多个题干或选项，请分别框选对应区域后确认。');
          else if(current.options.length){const option=current.options.at(-1)!;option.visuals=[...(option.visuals||[]),...block.visuals];}
          else current.stemVisuals=[...(current.stemVisuals||[]),...block.visuals];
        }
        current.issues.push(...(block.warnings || []));
        if (block.images?.length && current.options.length)
          current.issues.push(
            '图片可能属于选项，请对照原Word核对图片位置与内容。',
          );
        mediaAttached = true;
      }
    };
    for (const rawLine of lines) {
      const text = rawLine.trim();
      if (!text) {
        continue;
      }
      if (isAnswerHeading(text)) {
        flush();
        mode = 'answers';
        answerSection = '';
        numberRow = null;
        columnPairs = [];
        collectContext = false;
        continue;
      }
      if (mode === 'answers') {
        if (isSection(text, block.heading)) {
          answerSection = text;
          numberRow = null;
          columnPairs = [];
          continue;
        }
        const start = questionStart(text);
        const parsedAnswers = answerPairs(text);
        const pureAnswerList =
          parsedAnswers.pairs.length > 0 &&
          /^[\dA-Ha-h\s.．、:：()（）;；,，/&—–~～至题第-]+$/.test(
            compact(text),
          );
        const answerWithExplanation =
          /^[A-Ha-h](?:[\s,，、/&]*[A-Ha-h])*\s*[.。;；]?\s*(?:解析|explanation\b|analysis\b|because\b)/i.test(
            compact(start?.stem || ''),
          );
        if (
          start &&
          !answerValue(start.stem) &&
          !answerWithExplanation &&
          !pureAnswerList
        ) {
          mode = 'questions';
          section = answerSection;
        } else {
          const parsed = answerPairs(text);
          if (parsed.range && !parsed.pairs.length)
            warnings.push(`答案范围与数量不一致：${text}`);
          for (const p of parsed.pairs)
            addAnswer(p.number, p.answer, block.source, parsed.range);
          continue;
        }
      }
      if (isSection(text, block.heading)) {
        flush();
        section = text;
        context = '';
        contextImages = [];
        contextVisuals=[];
        contextIssues = [];
        collectContext = false;
        continue;
      }
      if (
        /^(?:阅读材料|阅读短文|材料(?:\s*\d+)?|reading\s+passage|passage(?:\s+[A-Z\d]+)?|read\s+the\s+(?:following\s+)?(?:passage|text))\s*[:：.\s]/i.test(
          text,
        )
      ) {
        flush();
        context = text;
        contextImages = [];
        contextVisuals=[];
        contextIssues = [];
        collectContext = true;
        attachContext();
        continue;
      }
      const inline = inlineAnswer(text);
      if (inline && current) {
        if (inline.value) {
          entries.push({
            section: current.section,
            number: current.number,
            answer: inline.value,
            source: block.source,
          });
        } else {
          current.issues.push('题后答案格式不明确，请核对。');
        }
        skipExplanation = true;
        continue;
      }
      const start = questionStart(text);
      if (start) {
        flush();
        collectContext = false;
        const split = splitOptions(start.stem);
        current = {
          id: `q-${questions.length + 1}`,
          order: questions.length,
          number: start.number,
          section,
          stem: split.prefix,
          options: split.options,
          answer: '',
          issues: [...contextIssues],
          images: [],
          context,
          contextImages: [...contextImages],
          contextVisuals:[...contextVisuals],
          source: block.source,
          kind: /多选|多项选择|select\s+all|choose\s+all|all\s+that\s+apply/i.test(
            section + ' ' + start.stem,
          )
            ? 'multiple'
            : 'single',
        };
        members.add(current);
      } else if (collectContext) {
        context += '\n' + text;
        attachContext();
      } else if (current) {
        if (
          skipExplanation ||
          /^(?:解析|说明|explanation|analysis|solution)\s*[/／:：]/i.test(text)
        ) {
          skipExplanation = true;
          continue;
        }
        const split = splitOptions(text);
        if (split.options.length) {
          if (split.prefix) {
            if (current.options.length)
              current.options[current.options.length - 1].text +=
                '\n' + split.prefix;
            else current.stem += '\n' + split.prefix;
          }
          current.options.push(...split.options);
        } else if (current.options.length) {
          current.options[current.options.length - 1].text += '\n' + text;
        } else current.stem += '\n' + text;
      } else if (!title && !/示例.*测试|合成示例/.test(text)) {
        title = text;
      }
      if (current) members.add(current);
      attachQuestion();
    }
    if (collectContext && !mediaAttached) attachContext();
    if (current && !mediaAttached) {
      members.add(current);
      attachQuestion();
    } else if (!current && block.warnings?.length)
      warnings.push(...block.warnings);
    if (ambiguousMedia||ambiguousVisuals)
      for (const q of members)
        q.issues.push(
          '同一段落或表格行含多题及图文内容，图片归属与完整性需逐题核对。',
          ...(block.warnings || []),
        );
  }
  flush();
  const counts = new Map<string, number>(),
    globalCounts = new Map<string, number>();
  for (const q of questions) {
    const key = sectionKey(q.section) + '::' + q.number;
    counts.set(key, (counts.get(key) || 0) + 1);
    globalCounts.set(q.number, (globalCounts.get(q.number) || 0) + 1);
  }
  const used = new Set<number>();
  for (const q of questions) {
    const scoped = entries
      .map((e, i) => ({ ...e, index: i }))
      .filter(
        (e) =>
          e.number === q.number &&
          sectionKey(e.section) === sectionKey(q.section),
      );
    const unscoped = entries
      .map((e, i) => ({ ...e, index: i }))
      .filter((e) => e.number === q.number && !e.section);
    let matches = scoped;
    if (globalCounts.get(q.number) === 1)
      matches = unique(
        [...matches, ...unscoped].map((e) => String(e.index)),
      ).map((i) => ({ ...entries[Number(i)], index: Number(i) }));
    if (!matches.length && unscoped.length && globalCounts.get(q.number) !== 1)
      q.issues.push('题号在不同大题中重复，答案未注明所属大题，不能自动对应。');
    const answers = unique(matches.map((e) => e.answer));
    for (const m of matches) used.add(m.index);
    if (answers.length === 1) q.answer = answers[0];
    if (answers.length > 1)
      q.issues.push(
        '同一道题存在冲突答案：' + answers.join(' / ') + '，请对照原Word确认。',
      );
    if (counts.get(sectionKey(q.section) + '::' + q.number)! > 1)
      q.issues.push('同一大题内题号重复，需要确认题目边界和答案对应。');
    if (matches.some((e) => e.range) && q.kind === 'multiple')
      q.issues.push('多选题不能按连写单字母答案范围展开。');
    q.issues = validateQuestion(q, q.issues);
    q.source +=
      '\n' +
      blocks
        .filter((b) => b.source === q.source)
        .map((b) => b.text)
        .join('\n');
  }
  const extra = entries.filter((_, i) => !used.has(i));
  if (extra.length)
    warnings.push(
      `有${extra.length}条答案未能唯一对应题目，请在原文中核对（题号：${unique(
        extra.map((e) => e.number),
      )
        .slice(0, 20)
        .join('、')}）。`,
    );
  if (!questions.length)
    warnings.push(
      '未找到明确题号与选项结构。请检查原文，或在核对中使用完整文字重新识别。',
    );
  return {
    title: title.slice(0, 100) || filename.replace(/\.(docx|doc|pdf)$/i, ''),
    filename,
    questions,
    warnings: unique(warnings),
    sourceText: blocks.map((b) => b.text).join('\n'),
  };
}
