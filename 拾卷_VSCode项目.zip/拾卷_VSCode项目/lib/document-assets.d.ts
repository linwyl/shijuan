declare module 'virtual:document-assets' {
  const assets:{cMapUrl:Record<string,string>;standardFontDataUrl:Record<string,string>;wasmUrl:Record<string,string>;languages:Record<string,string>};
  export default assets;
}
declare module 'pdfjs-dist/legacy/build/pdf.worker.mjs';
declare module 'tesseract.js/src/worker-script/index.js' {
  const engine:{setAdapter(adapter:Record<string,unknown>):void;dispatchHandlers(packet:{workerId:string;jobId:string;action:string;payload:unknown},send:(packet:{status:string;data:unknown})=>void):void};
  export default engine;
}
declare module 'tesseract.js-core/tesseract-core-lstm.wasm.js' {
  const factory:(options:Record<string,unknown>)=>Promise<unknown>;
  export default factory;
}
