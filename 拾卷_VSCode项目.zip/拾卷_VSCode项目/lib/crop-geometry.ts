export type SelectionBox={x:number;y:number;width:number;height:number};
const clamp=(n:number)=>Math.min(1,Math.max(0,Number.isFinite(n)?n:0));
export function normalizeBox(box:SelectionBox):SelectionBox{
  const x=clamp(box.x),y=clamp(box.y);
  return{x,y,width:Math.min(1-x,clamp(box.width)),height:Math.min(1-y,clamp(box.height))};
}
export function boxFromPoints(a:{x:number;y:number},b:{x:number;y:number}):SelectionBox{
  const x=Math.min(clamp(a.x),clamp(b.x)),y=Math.min(clamp(a.y),clamp(b.y));
  return normalizeBox({x,y,width:Math.abs(clamp(a.x)-clamp(b.x)),height:Math.abs(clamp(a.y)-clamp(b.y))});
}
export function pixelBox(box:SelectionBox,width:number,height:number){
  const b=normalizeBox(box),x=Math.floor(b.x*width),y=Math.floor(b.y*height);
  return{x,y,width:Math.min(width-x,Math.ceil(b.width*width)),height:Math.min(height-y,Math.ceil(b.height*height))};
}
