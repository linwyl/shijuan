import katex from 'katex';
import {mathParts} from './math-text';
export function renderFormula(latex:string,display=false):{html?:string;error?:string}{
  if(latex.length>12000)return{error:'公式内容过长，请拆分公式。'};
  try{return{html:katex.renderToString(latex,{output:'mathml',displayMode:display,throwOnError:true,trust:false,strict:'ignore',maxExpand:1000,maxSize:30})};}
  catch{return{error:'公式无法完整排版，请检查命令、括号和上下标。'};}
}
export function mathIssues(text:string){
  const issues=mathParts(text).flatMap(p=>p.latex===undefined?[]:renderFormula(p.latex,p.display).error||[]);
  const outside=maskOutside(text);
  if(/\\[()[\]]/.test(outside))issues.push('公式标记未闭合，请成对使用 \\(…\\) 或 \\[…\\]。');
  return [...new Set(issues)];
}
function maskOutside(text:string){return mathParts(text).map(p=>p.latex===undefined?p.text:'').join('');}
