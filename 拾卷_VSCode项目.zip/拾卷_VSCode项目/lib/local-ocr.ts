// The pinned Tesseract worker handlers run inside our existing parsing Worker.
// Language loading and initialization are separate to pass bytes without any URL.
import engine from 'tesseract.js/src/worker-script/index.js';
import coreFactory from 'tesseract.js-core/tesseract-core-lstm.wasm.js';
import assets from 'virtual:document-assets';

export function decodeAsset(encoded:string){const raw=atob(encoded);return Uint8Array.from(raw,c=>c.charCodeAt(0));}
export type ImportProgress={message:string;page?:number;pages?:number;percent?:number};
export type OcrLine={text:string;confidence:number;bbox:{x0:number;y0:number;x1:number;y1:number}};
type OcrBlock={paragraphs?:{lines?:OcrLine[]}[]};
export type OcrResult={text:string;confidence:number;lines:OcrLine[]};
let initialized=false;
let sequence=0;
async function loadLanguages(){
  if(typeof DecompressionStream==='undefined')throw new Error('当前浏览器不支持本地OCR模型解压，请更新Edge或Chrome后重试。');
  return Promise.all(['chi_sim','eng'].map(async code=>{
    // Tesseract's default gzip adapter depends on Node Buffer. Decompress with
    // the browser API first and pass ordinary bytes to its language loader.
    const compressed=Uint8Array.from(decodeAsset(assets.languages[code]));
    const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('gzip'));
    const data=new Uint8Array(await new Response(stream).arrayBuffer());
    return {code,data};
  }));
}
function job<T>(action:string,payload:unknown,onProgress?:(progress:number)=>void):Promise<T>{
  return new Promise((resolve,reject)=>{
    engine.dispatchHandlers({workerId:'local-ocr',jobId:String(++sequence),action,payload},packet=>{
      if(packet.status==='resolve')resolve(packet.data as T);
      else if(packet.status==='reject')reject(new Error(String(packet.data)));
      else if(packet.status==='progress')onProgress?.((packet.data as {progress?:number}).progress||0);
    });
  });
}
export async function recognizePage(image:Uint8Array,onProgress:(progress:number)=>void):Promise<OcrResult>{
  if(!initialized){
    const langs=await loadLanguages();
    engine.setAdapter({getCore:async()=>coreFactory,readCache:async()=>{throw new Error('Persistent cache is disabled');},writeCache:async()=>{},deleteCache:async()=>{}});
    await job('load',{options:{lstmOnly:true,logging:false}},onProgress);
    await job('loadLanguage',{langs,options:{cacheMethod:'none',gzip:false,lstmOnly:true}},onProgress);
    await job('initialize',{langs:'chi_sim+eng',oem:1,config:{preserve_interword_spaces:'1'}},onProgress);
    initialized=true;
  }
  // Keep coordinates in the original page raster. Automatic rotation would
  // make the returned bounding boxes disagree with the source used for crops.
  const result=await job<{text:string;confidence:number;blocks?:OcrBlock[]}>('recognize',{image,options:{rotateAuto:false},output:{text:true,blocks:true}},onProgress);
  return {text:result.text,confidence:result.confidence,lines:(result.blocks||[]).flatMap(block=>(block.paragraphs||[]).flatMap(paragraph=>paragraph.lines||[]))};
}
