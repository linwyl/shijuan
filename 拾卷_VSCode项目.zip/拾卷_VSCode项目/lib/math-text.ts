export type MathPart={text:string;latex?:string;display?:boolean;start:number;end:number};
export function mathParts(text:string):MathPart[]{
  const result:MathPart[]=[];let position=0;
  const re=/\\\(([\s\S]*?)\\\)|\\\[([\s\S]*?)\\\]/g;
  for(const match of text.matchAll(re)){
    const start=match.index!,end=start+match[0].length;
    if(start>position)result.push({text:text.slice(position,start),start:position,end:start});
    result.push({text:match[0],latex:match[1]??match[2],display:match[2]!==undefined,start,end});position=end;
  }
  if(position<text.length)result.push({text:text.slice(position),start:position,end:text.length});
  return result;
}
// Preserve offsets, so A. and (B) inside a formula are never option labels.
export function maskMath(text:string){return mathParts(text).map(p=>p.latex===undefined?p.text:'¤'.repeat(p.text.length)).join('');}
export function collapseMathLines(text:string){return mathParts(text).map(p=>p.latex===undefined?p.text:p.text.replace(/[\r\n]+/g,' ')).join('');}
