import type {Picture} from './types';

/** Coordinates are PDF viewport points, with the origin at the upper left. */
export type VisualLine={text:string;x:number;top:number;bottom:number;right:number;y:number;height:number;source:string;visuals?:Picture[];coordinateMode?:'box'|'baseline'};
export type VisualState={active:boolean;answers:boolean;option:string};
export type VisualRegion={anchor:number;left:number;top:number;right:number;bottom:number;role:'stem'|'option'|'continuation'};
export type VisualPlan={regions:VisualRegion[];state:VisualState;unsafe?:string};
const normalize=(text:string)=>text.replace(/[０-９Ａ-Ｚａ-ｚ]/g,c=>String.fromCharCode(c.charCodeAt(0)-0xfee0)).trim();
const optionPattern=/(^|[\s\u3000])(?:[（(]([A-Ha-h])[）)]|([A-Ha-h])[.．、:：)）])\s*/g;
const questionPattern=/^(?:(?:第\s*\d+(?:\.\d+)*\s*题)|(?:(?:question|q)\s*\d+(?=\s|[.．、:：)）]|$))|(?:[（(]\d+[)）])|(?:\d+[.．、:：)）](?!\d)))\s*[.．、:：]?\s*/i;
function answerBoundary(text:string){
  return /^(?:参考答案|标准答案|正确答案|答案(?:与解析|及解析|解析)?|answers?|answer\s*key|reference\s+answers?|correct\s+answer|solutions?|解析|explanation|analysis)\s*(?:[:：/／]|(?:is\s+)?[A-H](?:\b|$)|$)/i.test(text);
}
function sectionBoundary(text:string){return /^(?:section|part)\s+[A-Z\dIVX]+\b|^[一二三四五六七八九十]+[、．.]|^(?:阅读材料|阅读短文|reading\s+passage|passage)\b/i.test(text);}
function numberedAnswers(text:string){return /^(?:\d+[.．、:：)）]?\s*[A-H](?:[\s,，、/&]*[A-H])*[\s;；,，]*)+$/i.test(text);}

/**
 * Plan only whole, vertically separated fields. No answer row or following
 * question can be included in a region. Ambiguous pages are rejected instead
 * of guessing how a horizontal row, answer annotation or column should split.
 */
export function planPdfVisualRegions(lines:VisualLine[],width:number,height:number,initial:VisualState={active:false,answers:false,option:''}):VisualPlan{
  const state={...initial};const regions:VisualRegion[]=[];
  let current:{anchor:number;top:number;role:VisualRegion['role']}|undefined;
  let unsafe:string|undefined;
  const pageLeft=Math.max(0,Math.min(...lines.map(line=>line.x),width*.08)-8);
  const pageRight=Math.min(width,Math.max(...lines.map(line=>line.right),width*.9)+8);
  const cutTop=(line:VisualLine)=>Math.max(0,line.top-(line.coordinateMode==='box'?3:Math.max(3,line.height*.85)));
  const finish=(bottom:number)=>{
    if(!current)return;
    if(bottom-current.top<5){unsafe='题干或选项区域过密，无法保证公式完整。';current=undefined;return;}
    regions.push({...current,left:pageLeft,right:pageRight,bottom:Math.min(height,bottom)});current=undefined;
  };
  for(let i=0;i<lines.length;i++){
    const line=lines[i];const text=normalize(line.text);if(!text)continue;
    const options=[...text.matchAll(optionPattern)];const question=questionPattern.exec(text);
    const boundary=answerBoundary(text);
    if(/(?:答案|answer(?:\s*key)?|solution|解析|explanation)\s*[:：]|(?:答案|answer)\s+(?:is\s+)?[A-H](?:\b|$)/i.test(text)&&!boundary){unsafe='同一行包含题目与答案，不能自动裁图。';break;}
    if(options.length>1||question&&options.length){unsafe='同一行含多个题干或选项边界，需手动框选原文。';break;}
    if(boundary||sectionBoundary(text)||(state.answers||state.option)&&numberedAnswers(text)){
      finish(cutTop(line));state.active=false;state.option='';state.answers=boundary||numberedAnswers(text)||state.answers;continue;
    }
    if(question&&!numberedAnswers(text)){
      finish(cutTop(line));current={anchor:i,top:cutTop(line),role:'stem'};state.active=true;state.answers=false;state.option='';continue;
    }
    if(state.answers)continue;
    if(options.length&&options[0].index===0&&state.active){
      const key=(options[0][2]||options[0][3]).toUpperCase();
      const expected=state.option?String.fromCharCode(state.option.charCodeAt(0)+1):'A';
      if(key!==expected){unsafe='选项标签缺失或次序不明确，不能保证原图的归属。';break;}
      finish(cutTop(line));current={anchor:i,top:cutTop(line),role:'option'};state.option=key;continue;
    }
    if(state.active&&!current)current={anchor:i,top:Math.max(0,line.top-4),role:'continuation'};
    // A bare OCR label is evidence of an uncertain split, not an option that
    // can safely be folded into the previous option's image.
    if(state.option&&new RegExp('^'+String.fromCharCode(state.option.charCodeAt(0)+1)+'\\s+\\S').test(text)&&!question&&!options.length){unsafe='OCR选项标签缺少分隔符，请先手动确认边界。';break;}
  }
  if(!unsafe){
    const last=lines.at(-1);finish(last?Math.min(height,last.bottom+Math.max(8,last.height)):height);
    for(let i=1;i<regions.length;i++){
      const previous=lines[regions[i-1].anchor],next=lines[regions[i].anchor];
      if(next.coordinateMode==='box'?next.top-previous.bottom<2:next.y-previous.y<Math.max(previous.height,next.height)*1.65){unsafe='相邻题目或选项排版过密，原图边界需人工核对。';break;}
    }
  }
  return{regions:unsafe?[]:regions,state,unsafe};
}

function dataUrl(bytes:Uint8Array){let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));return 'data:image/png;base64,'+btoa(raw);}
export async function cropPdfRegion(canvas:OffscreenCanvas,region:VisualRegion,scale:number,page:number):Promise<Picture>{
  const left=Math.max(0,Math.floor(region.left*scale)),top=Math.max(0,Math.floor(region.top*scale));
  const right=Math.min(canvas.width,Math.ceil(region.right*scale)),bottom=Math.min(canvas.height,Math.ceil(region.bottom*scale));
  if(right<=left||bottom<=top)throw new Error('原文区域为空，请手动框选。');
  const target=new OffscreenCanvas(right-left,bottom-top);const context=target.getContext('2d');if(!context)throw new Error('无法创建公式原图。');
  try{context.drawImage(canvas,left,top,right-left,bottom-top,0,0,right-left,bottom-top);const bytes=new Uint8Array(await(await target.convertToBlob({type:'image/png'})).arrayBuffer());return{src:dataUrl(bytes),alt:`PDF第${page}页${region.role==='option'?'选项':region.role==='continuation'?'续行':'题干'}原文（保留数学排版）`};}finally{target.width=target.height=0;}
}
