import 'pdfjs-dist/legacy/build/pdf.worker.mjs';
import {getDocument,OPS} from 'pdfjs-dist/legacy/build/pdf.mjs';
import type {PDFPageProxy,TextItem} from 'pdfjs-dist/types/src/display/api';
import assets from 'virtual:document-assets';
import {decodeAsset,recognizePage,type ImportProgress} from './local-ocr';
import type {Block,SourcePage} from './types';
import {cropPdfRegion,planPdfVisualRegions,type VisualLine,type VisualState,type VisualPlan} from './pdf-visuals';

class LocalBinaryDataFactory{
  async fetch({kind,filename}:{kind:'cMapUrl'|'standardFontDataUrl'|'wasmUrl';filename:string}){
    const value=assets[kind]?.[filename];if(!value)throw new Error('PDF内置字体或解码资源缺失：'+filename);return decodeAsset(value);
  }
}
class LocalCanvasFactory{
  create(width:number,height:number){const canvas=new OffscreenCanvas(Math.ceil(width),Math.ceil(height));const context=canvas.getContext('2d');if(!context)throw new Error('当前浏览器不支持扫描PDF所需的画布。');return{canvas,context};}
  reset(target:{canvas:OffscreenCanvas},width:number,height:number){target.canvas.width=Math.ceil(width);target.canvas.height=Math.ceil(height);}
  destroy(target:{canvas:OffscreenCanvas|null;context:OffscreenCanvasRenderingContext2D|null}){if(target.canvas){target.canvas.width=0;target.canvas.height=0;}target.canvas=null;target.context=null;}
}
let filterFallbackUsed=false;
class LocalFilterFactory{
  fallback(){filterFallbackUsed=true;return 'none';}
  addFilter(){return this.fallback();}addHCMFilter(){return this.fallback();}addAlphaFilter(){return this.fallback();}addLuminosityFilter(){return this.fallback();}addKnockoutFilter(){return this.fallback();}addHighlightHCMFilter(){return this.fallback();}addSelectionHCMFilter(){return this.fallback();}addSelectionFilter(){return this.fallback();}destroy(){}
}
type Positioned={text:string;x:number;y:number;width:number;height:number};
type PdfLine=VisualLine&{cells?:string[];page:number;warnings?:string[]};
function lineText(items:Positioned[]){
  const cells:string[]=[];let text='',previous:Positioned|undefined;
  for(const item of items.sort((a,b)=>a.x-b.x)){
    const gap=previous?item.x-previous.x-previous.width:0;
    if(previous&&gap>Math.max(16,item.height*1.5)){cells.push(text.trim());text='';}
    else if(previous&&gap>Math.max(1,item.height*.12)&&!/[\s]$/.test(text)&&!/^\s/.test(item.text))text+=' ';
    text+=item.text;previous=item;
  }
  if(text.trim())cells.push(text.trim());
  return {text:cells.join('\t'),cells:cells.length>1?cells:undefined};
}
function readLines(items:Positioned[],page:number):PdfLine[]{
  const rows:{y:number;items:Positioned[]}[]=[];
  for(const item of items.sort((a,b)=>a.y-b.y||a.x-b.x)){
    const row=rows.at(-1);if(row&&Math.abs(row.y-item.y)<Math.max(2,item.height*.3))row.items.push(item);else rows.push({y:item.y,items:[item]});
  }
  return rows.map((row,i)=>({...lineText(row.items),y:row.y,x:Math.min(...row.items.map(item=>item.x)),right:Math.max(...row.items.map(item=>item.x+item.width)),top:Math.min(...row.items.map(item=>item.y-item.height)),bottom:Math.max(...row.items.map(item=>item.y+item.height*.22)),height:Math.max(...row.items.map(item=>item.height)),page,source:`PDF第${page}页 · 第${i+1}行`})).filter(line=>line.text.trim());
}
function hasParallelQuestions(lines:PdfLine[]){return lines.some(line=>line.cells&&line.cells.filter(cell=>{const match=/^\s*(?:(?:Question|Q)\s*)?[（(]?\d+[.．、:：)）]\s*(\S.*)/i.exec(cell);return match&&!/^[A-Ha-h\s,，、/&]+$/.test(match[1]);}).length>1);}
export function normalizeOcrLine(text:string){
  let line=text.trim().replace(/^(\d+)[,，]\s*(?=\S)/,'$1. ');
  const heading=line.split(/[/／]/).map(part=>part.trim()).find(part=>/^(?:参考答案|答案|answer\s*key|reference\s+answers?)$/i.test(part));
  if(heading&&line.length<65&&line.split(/[/／]/).length>1&&!/\d/.test(line))line=heading;
  return line;
}
function dataUrl(bytes:Uint8Array,mime:string){let raw='';for(let i=0;i<bytes.length;i+=8192)raw+=String.fromCharCode(...bytes.subarray(i,i+8192));return `data:${mime};base64,${btoa(raw)}`;}
async function rasterPage(page:PDFPageProxy){
  if(typeof OffscreenCanvas==='undefined')throw new Error('扫描PDF需要支持OffscreenCanvas的现代浏览器，请更新Edge或Chrome后重试。');
  const original=page.getViewport({scale:1});const scale=Math.min(2.8,3200/Math.max(original.width,original.height));const viewport=page.getViewport({scale});
  const canvas=new OffscreenCanvas(Math.ceil(viewport.width),Math.ceil(viewport.height));const context=canvas.getContext('2d');if(!context)throw new Error('无法创建扫描页画布。');
  await page.render({canvas:canvas as unknown as HTMLCanvasElement,canvasContext:context as unknown as CanvasRenderingContext2D,viewport,background:'#ffffff'}).promise;
  const png=new Uint8Array(await(await canvas.convertToBlob({type:'image/png'})).arrayBuffer());
  const thumbScale=Math.min(1,2000/canvas.width);const thumbnail=new OffscreenCanvas(Math.ceil(canvas.width*thumbScale),Math.ceil(canvas.height*thumbScale));thumbnail.getContext('2d')!.drawImage(canvas,0,0,thumbnail.width,thumbnail.height);
  const jpeg=new Uint8Array(await(await thumbnail.convertToBlob({type:'image/jpeg',quality:.8})).arrayBuffer());
  thumbnail.width=thumbnail.height=0;
  return{png,preview:dataUrl(jpeg,'image/jpeg'),canvas,scale,dispose(){canvas.width=canvas.height=0;}};
}
function hasMathLayout(items:Positioned[],text:string){
  if(/[×÷√∫∑∞≤≥≠±^²³⁰ⁱ₀-₉]/.test(text)||/\d\s*[/−-]\s*\d/.test(text))return true;
  // Superscripts and subscripts are often separate text objects, without any
  // mathematical character in the extracted string.
  return items.some((item,index)=>items.slice(Math.max(0,index-3),index+4).some(other=>other!==item&&item.height<other.height*.8&&Math.abs(item.y-other.y)>other.height*.18&&Math.abs(item.y-other.y)<other.height&&Math.abs(item.x-(other.x+other.width))<other.height*1.5));
}
export async function readPdf(bytes:ArrayBuffer,onProgress:(progress:ImportProgress)=>void=()=>{}){
  filterFallbackUsed=false;
  if(bytes.byteLength>20*1024*1024)throw new Error('文件超过20 MB，请拆分PDF后导入。');
  const header=new TextDecoder('ascii').decode(new Uint8Array(bytes,0,Math.min(bytes.byteLength,1024)));
  if(!/%PDF-\d\.\d/.test(header))throw new Error('文件内容与PDF格式不符，不能只修改后缀。');
  const task=getDocument({data:new Uint8Array(bytes),useWorkerFetch:false,BinaryDataFactory:LocalBinaryDataFactory,CanvasFactory:LocalCanvasFactory,FilterFactory:LocalFilterFactory,disableFontFace:true,useSystemFonts:false,enableXfa:false,isImageDecoderSupported:false,isOffscreenCanvasSupported:false,maxImageSize:25_000_000,stopAtErrors:true,verbosity:0});
  const blocks:Block[]=[];const warnings:string[]=[];const sourcePages:SourcePage[]=[];let requiresReview=false;let ocrPages=0;
  try{
    const document=await task.promise;if(document.numPages>100)throw new Error('PDF超过100页，请拆分后导入；一次最多识别20个扫描页。');
    const pageLines:{page:number;height:number;width:number;lines:PdfLine[];columns:boolean;ocr:boolean;hasCoordinates:boolean}[]=[];
    let visualDocument=false;
    for(let n=1;n<=document.numPages;n++){
      onProgress({message:`正在读取PDF第${n}/${document.numPages}页`,page:n,pages:document.numPages});
      const page=await document.getPage(n);const viewport=page.getViewport({scale:1});const content=await page.getTextContent();
      const items=content.items.filter((item):item is TextItem=>'str'in item&&!!item.str.trim()).map(item=>{const[x,y]=viewport.convertToViewportPoint(item.transform[4],item.transform[5]);return{text:item.str,x,y,width:Math.abs(item.width),height:Math.max(1,Math.abs(item.height))};});
      const text=items.map(item=>item.text).join(' ');const operators=await page.getOperatorList();
      const imageOps=new Set([OPS.paintImageXObject,OPS.paintInlineImageXObject,OPS.paintInlineImageXObjectGroup,OPS.paintImageXObjectRepeat,OPS.paintImageMaskXObject,OPS.paintImageMaskXObjectGroup,OPS.paintImageMaskXObjectRepeat]);
      const hasDrawings=operators.fnArray.includes(OPS.constructPath);
      const hasImages=operators.fnArray.some(op=>imageOps.has(op));const needsOcr=hasImages||text.replace(/\s/g,'').length<25||/[\uFFFD\uE000-\uF8FF]/.test(text);
      visualDocument ||= hasImages||hasDrawings||hasMathLayout(items,text);
      if(needsOcr){
        if(++ocrPages>20)throw new Error('本次PDF需要OCR的页面超过20页，请拆分后导入。');
        onProgress({message:`正在转换扫描页 ${n}/${document.numPages}`,page:n,pages:document.numPages});
        const raster=await rasterPage(page);
        try{
          const result=await recognizePage(raster.png,percent=>onProgress({message:`中英文OCR：第${n}/${document.numPages}页 · ${Math.round(percent*100)}%`,page:n,pages:document.numPages,percent}));
          requiresReview=true;visualDocument=true;
          sourcePages.push({page:n,image:{src:raster.preview,alt:`PDF第${n}页原页（含答案，仅供核对）`},method:'ocr',confidence:result.confidence});
          const positioned=result.lines.filter(line=>line.text.trim()&&line.bbox&&Object.values(line.bbox).every(Number.isFinite));
          const lines:PdfLine[]=positioned.length?positioned.map((line,i)=>({text:normalizeOcrLine(line.text),x:line.bbox.x0/raster.scale,right:line.bbox.x1/raster.scale,top:line.bbox.y0/raster.scale,bottom:line.bbox.y1/raster.scale,y:line.bbox.y1/raster.scale,height:(line.bbox.y1-line.bbox.y0)/raster.scale,coordinateMode:'box',page:n,source:`PDF第${n}页 · OCR第${i+1}行`,warnings:['OCR识别内容需对照原页逐题确认，不能视为已准确识别。']})):result.text.replace(/\r/g,'').split('\n').map((text,i)=>({text:normalizeOcrLine(text),x:0,right:viewport.width,top:i,bottom:i+1,y:i,height:1,page:n,source:`PDF第${n}页 · OCR第${i+1}行`,warnings:['OCR未提供可靠的行坐标，请手动框选公式原文。']})).filter(line=>line.text);
          if(!lines.length)warnings.push(`第${n}页未识别到文字，请在原页中核对。`);
          const outOfOrder=lines.some((line,index)=>index>0&&line.top<lines[index-1].top-Math.max(5,line.height));
          pageLines.push({page:n,height:viewport.height,width:viewport.width,lines,columns:outOfOrder,ocr:true,hasCoordinates:positioned.length>0});
        }finally{raster.dispose();}
      }else{
        let lines=readLines(items,n);const hasColumns=hasParallelQuestions(lines)||viewport.rotation%360!==0;
        if(hasColumns){
          requiresReview=true;warnings.push(`第${n}页疑似分栏，暂按左栏后右栏整理，请对照原页核对阅读顺序。`);
          const starts=items.filter(item=>/^\d+[.．、)）]\s*\S/.test(item.text));const rightStart=starts.find(item=>item.x>viewport.width*.4);
          if(rightStart){const leftStart=Math.min(...starts.map(item=>item.x));const split=(leftStart+rightStart.x)/2;lines=[...readLines(items.filter(item=>item.x<split),n),...readLines(items.filter(item=>item.x>=split),n)];}
        }
        if(hasDrawings){requiresReview=true;warnings.push(`第${n}页包含PDF矢量图形、表格线或公式排版，请对照原页确认题干与图文完整性。`);}
        if(hasColumns||hasDrawings){const raster=await rasterPage(page);try{sourcePages.push({page:n,image:{src:raster.preview,alt:`PDF第${n}页原页（含答案，仅供核对）`},method:'review'});}finally{raster.dispose();}}
        pageLines.push({page:n,height:viewport.height,width:viewport.width,lines,columns:hasColumns,ocr:false,hasCoordinates:true});
      }
      page.cleanup();
    }
    const repeatedMargins=new Map<string,Set<number>>();
    for(const page of pageLines)if(page.height)for(const line of page.lines)if(line.y<45||line.y>page.height-35){const found=repeatedMargins.get(line.text)||new Set<number>();found.add(page.page);repeatedMargins.set(line.text,found);}
    for(const page of pageLines)page.lines=page.lines.filter(line=>{
      const atMargin=page.height&&(line.y<45||line.y>page.height-35);
      const structural=/^(?:[\d０-９]+|[（(][\d０-９]+|(?:question|q)\s*\d+|[（(]?[A-Ha-hＡ-Ｈａ-ｈ][.．、:：)）]|答案|参考答案|answers?|answer\s*key)/i.test(line.text);
      const explicitPage=/^(?:第\s*\d+\s*页(?:\s*共\s*\d+\s*页)?|page\s+\d+(?:\s+of\s+\d+)?|\d+\s*\/\s*\d+)$/i.test(line.text);
      return !(atMargin&&(explicitPage||!structural&&(repeatedMargins.get(line.text)?.size||0)>1));
    });
    if(visualDocument){
      requiresReview=true;
      const plans:VisualPlan[]=[];let state:VisualState={active:false,answers:false,option:''};let unsafe='';let count=0;
      for(const page of pageLines){
        const plan=planPdfVisualRegions(page.lines,page.width,page.height,state);state=plan.state;plans.push(plan);count+=plan.regions.length;
        if(page.columns||!page.hasCoordinates||plan.unsafe)unsafe ||= `第${page.page}页：${page.columns?'分栏或阅读顺序不明确':!page.hasCoordinates?'缺少可靠的文字坐标':plan.unsafe}`;
      }
      if(count>600)unsafe='全卷自动原文片段超过600个，请拆分PDF或手动框选。';
      if(unsafe)warnings.push(`数学原文保真：${unsafe}。为避免用不完整图片替代跨页内容，本卷暂不自动挂图；请在核对界面从原页框选完整题干和选项。`);
      else warnings.push('已按题干和独立选项保留PDF原文图片，分式、上下标、根号等以原图为准。请逐题确认裁图完整且不含答案后再练习。');
      for(let index=0;index<pageLines.length;index++){
        const record=pageLines[index];onProgress({message:`正在保留数学原文：第${record.page}/${document.numPages}页`,page:record.page,pages:document.numPages});
        const page=await document.getPage(record.page);const raster=await rasterPage(page);
        try{
          if(!sourcePages.some(source=>source.page===record.page))sourcePages.push({page:record.page,image:{src:raster.preview,alt:`PDF第${record.page}页原页（含答案，仅供核对）`},method:'review'});
          if(!unsafe)for(const region of plans[index].regions){
            const line=record.lines[region.anchor];line.visuals=[await cropPdfRegion(raster.canvas,region,raster.scale,record.page)];
            line.warnings=[...(line.warnings||[]),'数学原文图片须核对完整性及题答边界后确认。'];
          }
        }finally{raster.dispose();page.cleanup();}
      }
      sourcePages.sort((a,b)=>a.page-b.page);
    }
    for(const page of pageLines)for(const line of page.lines)blocks.push({text:line.text,cells:line.cells,source:line.source,page:line.page,warnings:line.warnings,...(line.visuals?.length?{visuals:line.visuals}:{})});
    if(ocrPages)warnings.unshift(`已对${ocrPages}页执行本地中英文OCR。OCR可能存在错字、漏字或题答错误；本份试卷的全部题目须逐题核对后才能练习。`);
    if(filterFallbackUsed){requiresReview=true;warnings.push('部分PDF使用特殊色彩或透明滤镜，原页预览可能有差异，请与原PDF核对。');}
    if(!blocks.length)throw new Error('PDF中没有可识别内容，请检查页面是否为空或扫描是否清晰。');
    return {blocks,warnings,sourcePages,requiresReview};
  }catch(error){if(error instanceof Error&&error.name==='PasswordException')throw new Error('PDF有密码保护，请先解锁并保存副本后导入。');throw error;}finally{await task.destroy();}
}
