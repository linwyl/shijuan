declare module '*.cjs' { type LegacySections = {body:string;textboxes?:string;model?:{body?:{runs?:{image?:unknown;tbxRef?:unknown}[]}[]}}; const value:{sections(bytes:Uint8Array):LegacySections|null}; export default value; }
declare module '*?worker&inline' { const WorkerConstructor: { new():Worker }; export default WorkerConstructor; }
